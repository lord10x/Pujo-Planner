import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, '../data');
const DB_FILE = path.resolve(DATA_DIR, 'pujo_planner.sqlite');

let dbInstance: Database | null = null;
let saveDebounceTimer: NodeJS.Timeout | null = null;

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      dbInstance = new SQL.Database(fileBuffer);
      console.log('[DB] Loaded existing database from', DB_FILE);
    } catch (err) {
      console.error('[DB] Error loading DB file, creating fresh:', err);
      dbInstance = new SQL.Database();
    }
  } else {
    console.log('[DB] Initializing new database');
    dbInstance = new SQL.Database();
  }

  initSchema(dbInstance);
  persistDb();
  return dbInstance;
}

export function persistDb() {
  if (!dbInstance) return;
  if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    try {
      const data = dbInstance!.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_FILE, buffer);
    } catch (e) {
      console.error('[DB] Failed to save DB to disk:', e);
    }
  }, 100);
}

function initSchema(db: Database) {
  db.run(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS areas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      region TEXT NOT NULL,
      description TEXT,
      banner_image TEXT,
      pandal_count INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS pandals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      official_name TEXT,
      slug TEXT UNIQUE NOT NULL,
      area_id INTEGER,
      neighbourhood TEXT,
      address TEXT,
      latitude REAL,
      longitude REAL,
      theme TEXT,
      theme_description TEXT,
      description TEXT,
      history TEXT,
      highlights TEXT,
      committee_name TEXT,
      established_year INTEGER,
      status TEXT DEFAULT 'Active',
      active_year INTEGER DEFAULT 2026,
      last_active_year INTEGER DEFAULT 2026,
      opening_time TEXT,
      closing_time TEXT,
      best_time TEXT,
      estimated_visit_duration INTEGER DEFAULT 30,
      crowd_level TEXT DEFAULT 'Moderate',
      rating REAL DEFAULT 4.5,
      rating_count INTEGER DEFAULT 0,
      nearest_metro TEXT,
      nearest_railway TEXT,
      parking_available INTEGER DEFAULT 0,
      wheelchair_access INTEGER DEFAULT 0,
      elder_friendly INTEGER DEFAULT 1,
      family_friendly INTEGER DEFAULT 1,
      official_website TEXT,
      official_social TEXT,
      category TEXT DEFAULT 'Major public Durga Puja',
      alternate_name TEXT,
      verification_status TEXT DEFAULT 'VERIFIED',
      source_name TEXT,
      source_url TEXT,
      verified_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(area_id) REFERENCES areas(id)
    );

    CREATE TABLE IF NOT EXISTS pandal_years (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_id INTEGER NOT NULL,
      year INTEGER NOT NULL,
      theme TEXT,
      theme_description TEXT,
      idol_artist TEXT,
      pandal_artist TEXT,
      lighting_artist TEXT,
      highlights TEXT,
      budget_category TEXT,
      awards TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS themes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      slug TEXT NOT NULL,
      description TEXT,
      category TEXT
    );

    CREATE TABLE IF NOT EXISTS images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_id INTEGER NOT NULL,
      year INTEGER,
      url TEXT NOT NULL,
      caption TEXT,
      photographer TEXT,
      is_cover INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_id INTEGER NOT NULL,
      user_name TEXT NOT NULL,
      rating REAL NOT NULL,
      comment TEXT NOT NULL,
      visit_date TEXT,
      crowd_observed TEXT,
      status TEXT DEFAULT 'approved',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS crowd_reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_id INTEGER NOT NULL,
      crowd_level TEXT NOT NULL,
      wait_time_minutes INTEGER DEFAULT 15,
      report_source TEXT DEFAULT 'Community report',
      reported_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS routes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      duration_category TEXT,
      estimated_hours REAL DEFAULT 3.0,
      is_preset INTEGER DEFAULT 0,
      category TEXT,
      created_by TEXT DEFAULT 'Curator',
      stops_count INTEGER DEFAULT 0,
      total_distance_km REAL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS route_stops (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      route_id INTEGER NOT NULL,
      pandal_id INTEGER NOT NULL,
      stop_order INTEGER NOT NULL,
      estimated_duration_mins INTEGER DEFAULT 30,
      notes TEXT,
      FOREIGN KEY(route_id) REFERENCES routes(id),
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_name TEXT NOT NULL,
      area_id INTEGER,
      neighbourhood TEXT,
      address TEXT,
      latitude REAL,
      longitude REAL,
      theme TEXT,
      description TEXT,
      committee_name TEXT,
      established_year INTEGER,
      nearest_metro TEXT,
      nearest_railway TEXT,
      opening_time TEXT,
      closing_time TEXT,
      wheelchair_access INTEGER DEFAULT 0,
      parking_available INTEGER DEFAULT 0,
      photos TEXT,
      submitter_name TEXT,
      submitter_email TEXT,
      source_reference TEXT,
      additional_info TEXT,
      category TEXT DEFAULT 'Community puja',
      alternate_name TEXT,
      status TEXT DEFAULT 'COMMUNITY SUBMITTED',
      admin_notes TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(area_id) REFERENCES areas(id)
    );

    CREATE TABLE IF NOT EXISTS verification_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      previous_status TEXT,
      new_status TEXT,
      admin_user TEXT,
      notes TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS report_issues (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pandal_id INTEGER NOT NULL,
      issue_type TEXT NOT NULL,
      details TEXT NOT NULL,
      reporter_contact TEXT,
      status TEXT DEFAULT 'pending',
      resolved_notes TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    CREATE TABLE IF NOT EXISTS saved_pandals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_token TEXT NOT NULL,
      pandal_id INTEGER NOT NULL,
      is_visited INTEGER DEFAULT 0,
      notes TEXT,
      visited_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_token, pandal_id),
      FOREIGN KEY(pandal_id) REFERENCES pandals(id)
    );

    -- Performance indexes
    CREATE INDEX IF NOT EXISTS idx_pandals_name ON pandals(name);
    CREATE INDEX IF NOT EXISTS idx_pandals_slug ON pandals(slug);
    CREATE INDEX IF NOT EXISTS idx_pandals_area ON pandals(area_id);
    CREATE INDEX IF NOT EXISTS idx_pandals_category ON pandals(category);
    CREATE INDEX IF NOT EXISTS idx_pandals_verification ON pandals(verification_status);
    CREATE INDEX IF NOT EXISTS idx_pandals_lat_lng ON pandals(latitude, longitude);
    CREATE INDEX IF NOT EXISTS idx_pandals_rating ON pandals(rating);
    CREATE INDEX IF NOT EXISTS idx_pandals_status ON pandals(status);
    CREATE INDEX IF NOT EXISTS idx_pandal_years_pandal ON pandal_years(pandal_id, year);
    CREATE INDEX IF NOT EXISTS idx_reviews_pandal ON reviews(pandal_id);
    CREATE INDEX IF NOT EXISTS idx_crowd_pandal ON crowd_reports(pandal_id);
    CREATE INDEX IF NOT EXISTS idx_saved_user ON saved_pandals(user_token);
  `);

  try { db.run("ALTER TABLE pandals ADD COLUMN category TEXT DEFAULT 'Major public Durga Puja';"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN alternate_name TEXT;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN nearby_restaurants TEXT;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN water_counter_info TEXT;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN toilets_available INTEGER DEFAULT 1;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN medical_aid_info TEXT;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN police_booth TEXT;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN metro_walk_time TEXT;"); } catch {}
  try { db.run("ALTER TABLE pandals ADD COLUMN entry_approach_tip TEXT;"); } catch {}
  try { db.run("ALTER TABLE submissions ADD COLUMN category TEXT DEFAULT 'Community puja';"); } catch {}
  try { db.run("ALTER TABLE submissions ADD COLUMN alternate_name TEXT;"); } catch {}
}

// Helpers for executing SQL with clean objects
export function queryAll<T = any>(db: Database, sql: string, params: any[] = []): T[] {
  const stmt = db.prepare(sql);
  if (params.length > 0) {
    stmt.bind(params);
  }
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as unknown as T);
  }
  stmt.free();
  return results;
}

export function queryOne<T = any>(db: Database, sql: string, params: any[] = []): T | null {
  const results = queryAll<T>(db, sql, params);
  return results.length > 0 ? results[0] : null;
}

export function executeRun(db: Database, sql: string, params: any[] = []): { lastInsertRowid: number; changes: number } {
  db.run(sql, params);
  const info = queryOne<{ id: number; changes: number }>(
    db,
    'SELECT last_insert_rowid() as id, changes() as changes'
  );
  persistDb();
  return {
    lastInsertRowid: info?.id || 0,
    changes: info?.changes || 0,
  };
}
