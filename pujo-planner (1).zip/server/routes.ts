import { Router, Request, Response } from 'express';
import { Database } from 'sql.js';
import { queryAll, queryOne, executeRun, persistDb } from './db.js';

export function createApiRouter(db: Database): Router {
  const router = Router();

  // 1. DYNAMIC STATISTICS
  router.get('/stats', (req: Request, res: Response) => {
    try {
      const total = queryOne<{ count: number }>(db, 'SELECT COUNT(*) as count FROM pandals')?.count || 0;
      const verified = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM pandals WHERE verification_status = 'VERIFIED'")?.count || 0;
      const community = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM pandals WHERE verification_status = 'COMMUNITY SUBMITTED'")?.count || 0;
      const pendingVerification = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM pandals WHERE verification_status = 'NEEDS VERIFICATION'")?.count || 0;
      const active = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM pandals WHERE status = 'Active'")?.count || 0;
      const areasCount = queryOne<{ count: number }>(db, 'SELECT COUNT(*) as count FROM areas')?.count || 0;
      const crowdReportsCount = queryOne<{ count: number }>(db, 'SELECT COUNT(*) as count FROM crowd_reports')?.count || 0;
      const submissionsPending = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM submissions WHERE status = 'COMMUNITY SUBMITTED'")?.count || 0;

      res.json({
        total_pandals: total,
        verified_pandals: verified,
        community_submitted: community,
        pending_verification: pendingVerification,
        active_pandals: active,
        areas_covered: areasCount,
        crowd_reports_count: crowdReportsCount,
        submissions_pending: submissionsPending,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. GET AREAS
  router.get('/areas', (req: Request, res: Response) => {
    try {
      const areas = queryAll(db, `
        SELECT a.*, 
               (SELECT COUNT(*) FROM pandals p WHERE p.area_id = a.id) as pandal_count,
               (SELECT COUNT(*) FROM pandals p WHERE p.area_id = a.id AND p.verification_status = 'VERIFIED') as verified_count
        FROM areas a 
        ORDER BY a.sort_order ASC
      `);
      res.json(areas);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3. GET THEMES
  router.get('/themes', (req: Request, res: Response) => {
    try {
      const themes = queryAll(db, `
        SELECT DISTINCT theme FROM pandals WHERE theme IS NOT NULL AND theme != ''
      `);
      res.json(themes.map(t => t.theme));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3b. GET PUJA CATEGORIES
  router.get('/categories', (req: Request, res: Response) => {
    try {
      const categories = [
        'Major public Durga Puja',
        'Local para puja',
        'Small neighbourhood puja',
        'Club-organised puja',
        'Community puja',
        'Housing-complex / Society puja',
        'Family / Bonedi Bari puja',
        'Traditional / Heritage puja',
        'Newly established puja',
        'Institutional / College puja',
      ];
      res.json(categories);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. GET PANDALS (WITH FILTERS, SEARCH, SORTING, PAGINATION)
  router.get('/pandals', (req: Request, res: Response) => {
    try {
      const {
        search = '',
        area,
        area_slug,
        category,
        theme,
        crowd,
        rating,
        metro,
        wheelchair,
        elder_friendly,
        parking,
        verification,
        status = 'Active',
        year,
        sort = 'recommended',
        page = '1',
        limit = '24',
        lat,
        lng,
        max_distance_km
      } = req.query as Record<string, string>;

      const pageNum = Math.max(1, parseInt(page) || 1);
      const limitNum = Math.max(1, Math.min(100, parseInt(limit) || 24));
      const offset = (pageNum - 1) * limitNum;

      const whereClauses: string[] = [];
      const params: any[] = [];

      if (status && status !== 'ALL') {
        whereClauses.push('p.status = ?');
        params.push(status);
      }

      if (category && category !== 'ALL') {
        whereClauses.push('p.category = ?');
        params.push(category);
      }

      if (search.trim()) {
        const term = `%${search.trim().toLowerCase()}%`;
        whereClauses.push(`(
          LOWER(p.name) LIKE ? OR
          LOWER(COALESCE(p.official_name, '')) LIKE ? OR
          LOWER(COALESCE(p.alternate_name, '')) LIKE ? OR
          LOWER(p.neighbourhood) LIKE ? OR
          LOWER(p.theme) LIKE ? OR
          LOWER(p.address) LIKE ? OR
          LOWER(p.nearest_metro) LIKE ? OR
          LOWER(COALESCE(p.category, '')) LIKE ? OR
          LOWER(p.committee_name) LIKE ?
        )`);
        params.push(term, term, term, term, term, term, term, term, term);
      }

      if (area) {
        whereClauses.push('p.area_id = ?');
        params.push(parseInt(area));
      } else if (area_slug) {
        whereClauses.push('a.slug = ?');
        params.push(area_slug);
      }

      if (theme) {
        whereClauses.push('LOWER(p.theme) LIKE ?');
        params.push(`%${theme.toLowerCase()}%`);
      }

      if (crowd) {
        whereClauses.push('p.crowd_level = ?');
        params.push(crowd);
      }

      if (rating) {
        whereClauses.push('p.rating >= ?');
        params.push(parseFloat(rating));
      }

      if (wheelchair === '1') {
        whereClauses.push('p.wheelchair_access = 1');
      }

      if (elder_friendly === '1') {
        whereClauses.push('p.elder_friendly = 1');
      }

      if (parking === '1') {
        whereClauses.push('p.parking_available = 1');
      }

      if (metro) {
        whereClauses.push('p.nearest_metro IS NOT NULL AND p.nearest_metro != ""');
      }

      if (verification && verification !== 'ALL') {
        whereClauses.push('p.verification_status = ?');
        params.push(verification);
      }

      if (year) {
        whereClauses.push('p.active_year = ?');
        params.push(parseInt(year));
      }

      const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

      // Count query
      const countSql = `
        SELECT COUNT(*) as total
        FROM pandals p
        LEFT JOIN areas a ON p.area_id = a.id
        ${whereSql}
      `;
      const countResult = queryOne<{ total: number }>(db, countSql, params);
      const total = countResult ? countResult.total : 0;

      // Sorting
      let orderBy = 'p.rating DESC, p.rating_count DESC';
      if (sort === 'rating') {
        orderBy = 'p.rating DESC';
      } else if (sort === 'popular') {
        orderBy = 'p.rating_count DESC, p.rating DESC';
      } else if (sort === 'name') {
        orderBy = 'p.name ASC';
      } else if (sort === 'crowd_asc') {
        orderBy = `CASE p.crowd_level 
          WHEN 'Low' THEN 1 
          WHEN 'Moderate' THEN 2 
          WHEN 'High' THEN 3 
          WHEN 'Very High' THEN 4 
          ELSE 5 END ASC`;
      } else if (sort === 'recent_verified') {
        orderBy = 'p.verified_at DESC NULLS LAST, p.id DESC';
      } else if (sort === 'recent_added') {
        orderBy = 'p.id DESC';
      } else if (sort === 'established_asc') {
        orderBy = 'p.established_year ASC NULLS LAST';
      }

      const dataSql = `
        SELECT p.*, a.name as area_name, a.slug as area_slug,
               (SELECT url FROM images WHERE pandal_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
        FROM pandals p
        LEFT JOIN areas a ON p.area_id = a.id
        ${whereSql}
        ORDER BY ${orderBy}
        LIMIT ? OFFSET ?
      `;

      const listParams = [...params, limitNum, offset];
      let pandals = queryAll(db, dataSql, listParams);

      // Distance calculation if lat/lng passed
      if (lat && lng) {
        const uLat = parseFloat(lat);
        const uLng = parseFloat(lng);
        pandals = pandals.map(p => {
          if (p.latitude && p.longitude) {
            const d = getDistanceFromLatLonInKm(uLat, uLng, p.latitude, p.longitude);
            return { ...p, distance_km: Math.round(d * 10) / 10 };
          }
          return { ...p, distance_km: null };
        });

        if (sort === 'distance') {
          pandals.sort((a, b) => (a.distance_km ?? 9999) - (b.distance_km ?? 9999));
        }

        if (max_distance_km) {
          const maxD = parseFloat(max_distance_km);
          pandals = pandals.filter(p => p.distance_km !== null && p.distance_km <= maxD);
        }
      }

      res.json({
        data: pandals,
        pagination: {
          total,
          page: pageNum,
          limit: limitNum,
          total_pages: Math.ceil(total / limitNum) || 1,
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 5. GET ALL PANDALS FOR MAP (LIGHTWEIGHT WITH CLUSTERING/COORDINATES)
  router.get('/pandals-map', (req: Request, res: Response) => {
    try {
      const { area_slug, crowd, status = 'Active' } = req.query as Record<string, string>;
      const where: string[] = ['p.latitude IS NOT NULL', 'p.longitude IS NOT NULL'];
      const params: any[] = [];

      if (status && status !== 'ALL') {
        where.push('p.status = ?');
        params.push(status);
      }
      if (area_slug) {
        where.push('a.slug = ?');
        params.push(area_slug);
      }
      if (crowd) {
        where.push('p.crowd_level = ?');
        params.push(crowd);
      }

      const sql = `
        SELECT p.id, p.name, p.slug, p.latitude, p.longitude, p.area_id, p.neighbourhood,
               p.theme, p.crowd_level, p.rating, p.rating_count, p.nearest_metro,
               p.verification_status, a.name as area_name,
               (SELECT url FROM images WHERE pandal_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
        FROM pandals p
        LEFT JOIN areas a ON p.area_id = a.id
        WHERE ${where.join(' AND ')}
      `;

      const points = queryAll(db, sql, params);
      res.json(points);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. GLOBAL QUICK SEARCH WITH SUGGESTIONS
  router.get('/pandals/search', (req: Request, res: Response) => {
    try {
      const q = (req.query.q as string || '').trim().toLowerCase();
      if (!q) {
        return res.json({ pandals: [], areas: [], themes: [] });
      }

      const term = `%${q}%`;
      const pandals = queryAll(db, `
        SELECT p.id, p.name, p.slug, p.neighbourhood, p.theme, p.rating, p.verification_status,
               a.name as area_name
        FROM pandals p
        LEFT JOIN areas a ON p.area_id = a.id
        WHERE LOWER(p.name) LIKE ? OR LOWER(p.neighbourhood) LIKE ? OR LOWER(p.theme) LIKE ? OR LOWER(p.nearest_metro) LIKE ?
        LIMIT 6
      `, [term, term, term, term]);

      const areas = queryAll(db, `
        SELECT id, name, slug, region FROM areas WHERE LOWER(name) LIKE ? LIMIT 3
      `, [term]);

      res.json({ pandals, areas });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 7. GET SINGLE PANDAL BY SLUG
  router.get('/pandals/:slug', (req: Request, res: Response) => {
    try {
      const slug = req.params.slug;
      const pandal = queryOne(db, `
        SELECT p.*, a.name as area_name, a.slug as area_slug
        FROM pandals p
        LEFT JOIN areas a ON p.area_id = a.id
        WHERE p.slug = ?
      `, [slug]);

      if (!pandal) {
        return res.status(404).json({ error: 'Pandal not found' });
      }

      const images = queryAll(db, 'SELECT * FROM images WHERE pandal_id = ? ORDER BY is_cover DESC, sort_order ASC', [pandal.id]);
      const yearlyHistory = queryAll(db, 'SELECT * FROM pandal_years WHERE pandal_id = ? ORDER BY year DESC', [pandal.id]);
      const reviews = queryAll(db, "SELECT * FROM reviews WHERE pandal_id = ? AND status = 'approved' ORDER BY id DESC LIMIT 20", [pandal.id]);
      const crowdReports = queryAll(db, 'SELECT * FROM crowd_reports WHERE pandal_id = ? ORDER BY id DESC LIMIT 10', [pandal.id]);

      // Nearby pandals
      let nearby: any[] = [];
      if (pandal.latitude && pandal.longitude) {
        nearby = queryAll(db, `
          SELECT p.id, p.name, p.slug, p.neighbourhood, p.theme, p.rating, p.crowd_level,
                 p.latitude, p.longitude, p.nearest_metro,
                 (SELECT url FROM images WHERE pandal_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
          FROM pandals p
          WHERE p.id != ? AND p.latitude IS NOT NULL AND p.longitude IS NOT NULL
          LIMIT 12
        `, [pandal.id]);

        nearby = nearby.map(np => ({
          ...np,
          distance_km: Math.round(getDistanceFromLatLonInKm(pandal.latitude, pandal.longitude, np.latitude, np.longitude) * 10) / 10
        })).sort((a, b) => a.distance_km - b.distance_km).slice(0, 4);
      }

      res.json({
        ...pandal,
        images,
        yearly_history: yearlyHistory,
        reviews,
        crowd_reports: crowdReports,
        nearby
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 8. ROUTES (PRESETS & USER ROUTES)
  router.get('/routes', (req: Request, res: Response) => {
    try {
      const routes = queryAll(db, `
        SELECT r.*
        FROM routes r
        ORDER BY r.is_preset DESC, r.id ASC
      `);

      const enriched = routes.map(r => {
        const stops = queryAll(db, `
          SELECT rs.*, p.name as pandal_name, p.slug as pandal_slug, p.neighbourhood, p.latitude, p.longitude, p.crowd_level,
                 (SELECT url FROM images WHERE pandal_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
          FROM route_stops rs
          JOIN pandals p ON rs.pandal_id = p.id
          WHERE rs.route_id = ?
          ORDER BY rs.stop_order ASC
        `, [r.id]);
        return { ...r, stops };
      });

      res.json(enriched);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  router.get('/routes/:slug', (req: Request, res: Response) => {
    try {
      const route = queryOne(db, 'SELECT * FROM routes WHERE slug = ?', [req.params.slug]);
      if (!route) return res.status(404).json({ error: 'Route not found' });

      const stops = queryAll(db, `
        SELECT rs.*, p.name as pandal_name, p.slug as pandal_slug, p.neighbourhood, p.address,
               p.latitude, p.longitude, p.crowd_level, p.rating, p.nearest_metro,
               (SELECT url FROM images WHERE pandal_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
        FROM route_stops rs
        JOIN pandals p ON rs.pandal_id = p.id
        WHERE rs.route_id = ?
        ORDER BY rs.stop_order ASC
      `, [route.id]);

      res.json({ ...route, stops });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 9. SUBMIT MISSING PANDAL (COMMUNITY SUBMITTED)
  router.post('/submissions', (req: Request, res: Response) => {
    try {
      const {
        pandal_name,
        alternate_name,
        area_id,
        category,
        neighbourhood,
        address,
        latitude,
        longitude,
        theme,
        description,
        committee_name,
        established_year,
        nearest_metro,
        submitter_name,
        submitter_email,
        source_reference,
        additional_info
      } = req.body;

      if (!pandal_name || !pandal_name.trim()) {
        return res.status(400).json({ error: 'Pandal name is required.' });
      }

      // Check duplicates
      const existing = queryOne(db, 'SELECT id, name FROM pandals WHERE LOWER(name) = ? OR (alternate_name IS NOT NULL AND LOWER(alternate_name) = ?)', [pandal_name.trim().toLowerCase(), pandal_name.trim().toLowerCase()]);
      if (existing) {
        return res.status(409).json({ error: `A puja named "${existing.name}" is already in our directory!`, pandal_id: existing.id });
      }

      const result = executeRun(db, `
        INSERT INTO submissions (
          pandal_name, alternate_name, area_id, category, neighbourhood, address, latitude, longitude,
          theme, description, committee_name, established_year, nearest_metro,
          submitter_name, submitter_email, source_reference, additional_info, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMMUNITY SUBMITTED')
      `, [
        pandal_name.trim(),
        alternate_name ? alternate_name.trim() : null,
        area_id ? parseInt(area_id) : null,
        category || 'Community puja',
        neighbourhood || '',
        address || '',
        latitude ? parseFloat(latitude) : null,
        longitude ? parseFloat(longitude) : null,
        theme || '',
        description || '',
        committee_name || '',
        established_year ? parseInt(established_year) : null,
        nearest_metro || '',
        submitter_name || 'Anonymous Devotee',
        submitter_email || '',
        source_reference || '',
        additional_info || ''
      ]);

      // Also create unverified/community submitted record in pandals so it is immediately searchable with clear badge
      const slug = generateSlug(pandal_name.trim()) + '-' + Date.now().toString().slice(-4);
      executeRun(db, `
        INSERT INTO pandals (
          name, alternate_name, slug, area_id, category, neighbourhood, address, latitude, longitude,
          theme, description, committee_name, established_year, nearest_metro,
          verification_status, source_name, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMMUNITY SUBMITTED', 'Community submission', 'Active')
      `, [
        pandal_name.trim(),
        alternate_name ? alternate_name.trim() : null,
        slug,
        area_id ? parseInt(area_id) : 1,
        category || 'Community puja',
        neighbourhood || '',
        address || '',
        latitude ? parseFloat(latitude) : null,
        longitude ? parseFloat(longitude) : null,
        theme || '',
        description || 'Community submitted pandal awaiting editorial verification.',
        committee_name || '',
        established_year ? parseInt(established_year) : null,
        nearest_metro || '',
      ]);

      res.status(201).json({
        success: true,
        message: 'Pandal submitted successfully! It has been listed with "Community Submitted" status awaiting verification.',
        submission_id: result.lastInsertRowid
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 10. SUBMIT REVIEW
  router.post('/reviews', (req: Request, res: Response) => {
    try {
      const { pandal_id, user_name, rating, comment, visit_date, crowd_observed } = req.body;
      if (!pandal_id || !rating || !comment) {
        return res.status(400).json({ error: 'Pandal, rating and review text are required.' });
      }

      executeRun(db, `
        INSERT INTO reviews (pandal_id, user_name, rating, comment, visit_date, crowd_observed, status)
        VALUES (?, ?, ?, ?, ?, ?, 'approved')
      `, [pandal_id, user_name || 'Puja Hopper', parseFloat(rating), comment, visit_date || new Date().toISOString().slice(0, 10), crowd_observed || 'Moderate']);

      // Recalculate pandal rating
      const stats = queryOne<{ avg_rating: number; cnt: number }>(db, `
        SELECT AVG(rating) as avg_rating, COUNT(*) as cnt FROM reviews WHERE pandal_id = ? AND status = 'approved'
      `, [pandal_id]);

      if (stats) {
        executeRun(db, 'UPDATE pandals SET rating = ?, rating_count = ? WHERE id = ?',
          [Math.round(stats.avg_rating * 10) / 10, stats.cnt, pandal_id]);
      }

      res.status(201).json({ success: true, message: 'Review recorded.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 11. SUBMIT CROWD REPORT
  router.post('/crowd-reports', (req: Request, res: Response) => {
    try {
      const { pandal_id, crowd_level, wait_time_minutes } = req.body;
      if (!pandal_id || !crowd_level) {
        return res.status(400).json({ error: 'Pandal and crowd level are required.' });
      }

      executeRun(db, `
        INSERT INTO crowd_reports (pandal_id, crowd_level, wait_time_minutes, report_source, reported_at)
        VALUES (?, ?, ?, 'Community live report', ?)
      `, [pandal_id, crowd_level, wait_time_minutes ? parseInt(wait_time_minutes) : 15, new Date().toISOString()]);

      // Update current pandal crowd level
      executeRun(db, 'UPDATE pandals SET crowd_level = ? WHERE id = ?', [crowd_level, pandal_id]);

      res.status(201).json({ success: true, message: 'Live crowd report recorded.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 12. REPORT INCORRECT INFORMATION
  router.post('/report-issue', (req: Request, res: Response) => {
    try {
      const { pandal_id, issue_type, details, reporter_contact } = req.body;
      if (!pandal_id || !issue_type || !details) {
        return res.status(400).json({ error: 'Missing required report fields.' });
      }

      executeRun(db, `
        INSERT INTO report_issues (pandal_id, issue_type, details, reporter_contact)
        VALUES (?, ?, ?, ?)
      `, [pandal_id, issue_type, details, reporter_contact || '']);

      res.status(201).json({ success: true, message: 'Thank you for helping keep Kolkata Durga Puja data accurate!' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 13. USER SAVED PANDALS & VISITED STATUS
  router.get('/saved', (req: Request, res: Response) => {
    try {
      const token = req.query.token as string;
      if (!token) return res.json([]);

      const list = queryAll(db, `
        SELECT s.id as save_id, s.is_visited, s.notes, s.visited_at,
               p.*, a.name as area_name,
               (SELECT url FROM images WHERE pandal_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
        FROM saved_pandals s
        JOIN pandals p ON s.pandal_id = p.id
        LEFT JOIN areas a ON p.area_id = a.id
        WHERE s.user_token = ?
        ORDER BY s.id DESC
      `, [token]);

      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/saved/toggle', (req: Request, res: Response) => {
    try {
      const { user_token, pandal_id } = req.body;
      if (!user_token || !pandal_id) return res.status(400).json({ error: 'Missing token or pandal_id' });

      const existing = queryOne(db, 'SELECT id FROM saved_pandals WHERE user_token = ? AND pandal_id = ?', [user_token, pandal_id]);
      if (existing) {
        executeRun(db, 'DELETE FROM saved_pandals WHERE id = ?', [existing.id]);
        return res.json({ saved: false });
      } else {
        executeRun(db, 'INSERT INTO saved_pandals (user_token, pandal_id) VALUES (?, ?)', [user_token, pandal_id]);
        return res.json({ saved: true });
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/saved/visit', (req: Request, res: Response) => {
    try {
      const { user_token, pandal_id, is_visited } = req.body;
      const visitedVal = is_visited ? 1 : 0;
      const timeVal = is_visited ? new Date().toISOString() : null;

      const existing = queryOne(db, 'SELECT id FROM saved_pandals WHERE user_token = ? AND pandal_id = ?', [user_token, pandal_id]);
      if (existing) {
        executeRun(db, 'UPDATE saved_pandals SET is_visited = ?, visited_at = ? WHERE id = ?', [visitedVal, timeVal, existing.id]);
      } else {
        executeRun(db, 'INSERT INTO saved_pandals (user_token, pandal_id, is_visited, visited_at) VALUES (?, ?, ?, ?)', [user_token, pandal_id, visitedVal, timeVal]);
      }
      res.json({ success: true, is_visited: !!visitedVal });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 14. ADMIN: DATABASE HEALTH & SUMMARY
  router.get('/admin/health', (req: Request, res: Response) => {
    try {
      const total = queryOne<{ c: number }>(db, 'SELECT COUNT(*) as c FROM pandals')?.c || 0;
      const verified = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM pandals WHERE verification_status = 'VERIFIED'")?.c || 0;
      const community = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM pandals WHERE verification_status = 'COMMUNITY SUBMITTED'")?.c || 0;
      const needsVerif = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM pandals WHERE verification_status = 'NEEDS VERIFICATION'")?.c || 0;
      const demoCount = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM pandals WHERE verification_status = 'DEMO'")?.c || 0;

      const missingCoords = queryOne<{ c: number }>(db, 'SELECT COUNT(*) as c FROM pandals WHERE latitude IS NULL OR longitude IS NULL')?.c || 0;
      const missingImages = queryOne<{ c: number }>(db, 'SELECT COUNT(*) as c FROM pandals WHERE id NOT IN (SELECT pandal_id FROM images)')?.c || 0;
      const missingAddress = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM pandals WHERE address IS NULL OR address = ''")?.c || 0;
      const pendingSubmissions = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM submissions WHERE status = 'COMMUNITY SUBMITTED'")?.c || 0;
      const reportedIssues = queryOne<{ c: number }>(db, "SELECT COUNT(*) as c FROM report_issues WHERE status = 'pending'")?.c || 0;

      const areaBreakdown = queryAll(db, `
        SELECT a.id, a.name, a.region,
               COUNT(p.id) as total,
               SUM(CASE WHEN p.verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as verified,
               SUM(CASE WHEN p.verification_status = 'COMMUNITY SUBMITTED' THEN 1 ELSE 0 END) as community,
               SUM(CASE WHEN p.latitude IS NULL OR p.longitude IS NULL THEN 1 ELSE 0 END) as missing_coords
        FROM areas a
        LEFT JOIN pandals p ON p.area_id = a.id
        GROUP BY a.id, a.name, a.region
        ORDER BY a.sort_order ASC
      `);

      res.json({
        overview: {
          total,
          verified,
          community,
          needs_verification: needsVerif,
          demo_records: demoCount,
          missing_coords: missingCoords,
          missing_images: missingImages,
          missing_address: missingAddress,
          pending_submissions: pendingSubmissions,
          reported_issues: reportedIssues,
        },
        area_breakdown: areaBreakdown
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 15. ADMIN: SUBMISSIONS & VERIFICATION
  router.get('/admin/submissions', (req: Request, res: Response) => {
    try {
      const submissions = queryAll(db, `
        SELECT s.*, a.name as area_name
        FROM submissions s
        LEFT JOIN areas a ON s.area_id = a.id
        ORDER BY s.id DESC
      `);
      res.json(submissions);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/admin/submissions/:id/action', (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { action, admin_notes, edited_data } = req.body; // action: 'approve' | 'reject' | 'mark_duplicate'

      const sub = queryOne(db, 'SELECT * FROM submissions WHERE id = ?', [id]);
      if (!sub) return res.status(404).json({ error: 'Submission not found' });

      if (action === 'approve') {
        executeRun(db, `
          UPDATE pandals SET 
            verification_status = 'VERIFIED',
            verified_at = ?
          WHERE name = ?
        `, [new Date().toISOString().slice(0, 10), sub.pandal_name]);

        executeRun(db, "UPDATE submissions SET status = 'VERIFIED', admin_notes = ? WHERE id = ?", [admin_notes || 'Approved by editorial admin', id]);
      } else if (action === 'reject') {
        executeRun(db, "UPDATE submissions SET status = 'REJECTED', admin_notes = ? WHERE id = ?", [admin_notes || 'Rejected', id]);
      } else if (action === 'mark_duplicate') {
        executeRun(db, "UPDATE submissions SET status = 'DUPLICATE', admin_notes = ? WHERE id = ?", [admin_notes || 'Marked as duplicate', id]);
      }

      res.json({ success: true, message: `Submission ${action} completed.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 16. ADMIN: VERIFY / UPDATE PANDAL STATUS
  router.post('/admin/verify/:id', (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status = 'VERIFIED', notes = '' } = req.body;

      const p = queryOne(db, 'SELECT * FROM pandals WHERE id = ?', [id]);
      if (!p) return res.status(404).json({ error: 'Pandal not found' });

      executeRun(db, `
        UPDATE pandals SET verification_status = ?, verified_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
      `, [status, new Date().toISOString().slice(0, 10), id]);

      executeRun(db, `
        INSERT INTO verification_logs (pandal_id, action, previous_status, new_status, admin_user, notes)
        VALUES (?, 'STATUS_UPDATE', ?, ?, 'Admin', ?)
      `, [id, p.verification_status, status, notes]);

      res.json({ success: true, message: `Pandal marked as ${status}` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 17. ADMIN: DUPLICATE DETECTION CHECK
  router.post('/admin/duplicates/check', (req: Request, res: Response) => {
    try {
      const { name, lat, lng } = req.body;
      const candidates = queryAll(db, 'SELECT id, name, slug, address, latitude, longitude, area_id FROM pandals');
      const duplicates: any[] = [];

      for (const c of candidates) {
        let matchScore = 0;
        let reasons: string[] = [];

        if (name && c.name) {
          const sim = stringSimilarity(name.toLowerCase(), c.name.toLowerCase());
          if (sim > 0.65) {
            matchScore += Math.round(sim * 60);
            reasons.push(`High name similarity (${Math.round(sim * 100)}%)`);
          }
        }

        if (lat && lng && c.latitude && c.longitude) {
          const dist = getDistanceFromLatLonInKm(parseFloat(lat), parseFloat(lng), c.latitude, c.longitude);
          if (dist < 0.2) {
            matchScore += 40;
            reasons.push(`Close proximity (${Math.round(dist * 1000)} meters away)`);
          }
        }

        if (matchScore >= 40) {
          duplicates.push({ ...c, match_score: matchScore, reasons });
        }
      }

      duplicates.sort((a, b) => b.match_score - a.match_score);
      res.json({ possible_duplicates: duplicates });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 18. ADMIN: CREATE & UPDATE PANDAL DIRECTLY
  router.post('/admin/pandals', (req: Request, res: Response) => {
    try {
      const p = req.body;
      if (!p.name) return res.status(400).json({ error: 'Name is required' });
      const slug = p.slug || (generateSlug(p.name) + '-' + Date.now().toString().slice(-4));

      const result = executeRun(db, `
        INSERT INTO pandals (
          name, official_name, slug, area_id, neighbourhood, address,
          latitude, longitude, theme, theme_description, description, history,
          highlights, committee_name, established_year, status, active_year,
          opening_time, closing_time, best_time, estimated_visit_duration,
          crowd_level, rating, nearest_metro, parking_available, wheelchair_access,
          elder_friendly, family_friendly, verification_status, source_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        p.name, p.official_name || p.name, slug, p.area_id || 1, p.neighbourhood || '', p.address || '',
        p.latitude ? parseFloat(p.latitude) : null, p.longitude ? parseFloat(p.longitude) : null,
        p.theme || '', p.theme_description || '', p.description || '', p.history || '',
        p.highlights || '', p.committee_name || '', p.established_year ? parseInt(p.established_year) : null,
        p.status || 'Active', p.active_year ? parseInt(p.active_year) : 2026,
        p.opening_time || '10:00', p.closing_time || '03:00', p.best_time || '',
        p.estimated_visit_duration ? parseInt(p.estimated_visit_duration) : 30,
        p.crowd_level || 'Moderate', p.rating ? parseFloat(p.rating) : 4.5,
        p.nearest_metro || '', p.parking_available ? 1 : 0, p.wheelchair_access ? 1 : 0,
        p.elder_friendly ? 1 : 0, p.family_friendly ? 1 : 0, p.verification_status || 'VERIFIED',
        p.source_name || 'Admin entry'
      ]);

      if (p.cover_image) {
        executeRun(db, 'INSERT INTO images (pandal_id, year, url, caption, is_cover) VALUES (?, 2026, ?, ?, 1)',
          [result.lastInsertRowid, p.cover_image, p.name]);
      }

      res.status(201).json({ success: true, pandal_id: result.lastInsertRowid, slug });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  router.put('/admin/pandals/:id', (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const p = req.body;

      executeRun(db, `
        UPDATE pandals SET
          name = COALESCE(?, name),
          official_name = COALESCE(?, official_name),
          area_id = COALESCE(?, area_id),
          neighbourhood = COALESCE(?, neighbourhood),
          address = COALESCE(?, address),
          latitude = COALESCE(?, latitude),
          longitude = COALESCE(?, longitude),
          theme = COALESCE(?, theme),
          theme_description = COALESCE(?, theme_description),
          description = COALESCE(?, description),
          history = COALESCE(?, history),
          highlights = COALESCE(?, highlights),
          committee_name = COALESCE(?, committee_name),
          established_year = COALESCE(?, established_year),
          status = COALESCE(?, status),
          opening_time = COALESCE(?, opening_time),
          closing_time = COALESCE(?, closing_time),
          crowd_level = COALESCE(?, crowd_level),
          nearest_metro = COALESCE(?, nearest_metro),
          verification_status = COALESCE(?, verification_status),
          parking_available = COALESCE(?, parking_available),
          wheelchair_access = COALESCE(?, wheelchair_access),
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [
        p.name, p.official_name, p.area_id, p.neighbourhood, p.address,
        p.latitude, p.longitude, p.theme, p.theme_description, p.description,
        p.history, p.highlights, p.committee_name, p.established_year, p.status,
        p.opening_time, p.closing_time, p.crowd_level, p.nearest_metro,
        p.verification_status, p.parking_available, p.wheelchair_access,
        id
      ]);

      res.json({ success: true, message: 'Pandal updated.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  router.delete('/admin/pandals/:id', (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      executeRun(db, 'DELETE FROM images WHERE pandal_id = ?', [id]);
      executeRun(db, 'DELETE FROM pandal_years WHERE pandal_id = ?', [id]);
      executeRun(db, 'DELETE FROM reviews WHERE pandal_id = ?', [id]);
      executeRun(db, 'DELETE FROM crowd_reports WHERE pandal_id = ?', [id]);
      executeRun(db, 'DELETE FROM saved_pandals WHERE pandal_id = ?', [id]);
      executeRun(db, 'DELETE FROM pandals WHERE id = ?', [id]);
      res.json({ success: true, message: 'Pandal and related records removed.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 19. ADMIN: BULK EXPORT (JSON / CSV / SUPABASE POSTGRES SQL)
  router.get('/admin/export', (req: Request, res: Response) => {
    try {
      const format = (req.query.format as string) || 'json';
      const pandals = queryAll(db, `
        SELECT p.*, a.name as area_name
        FROM pandals p
        LEFT JOIN areas a ON p.area_id = a.id
        ORDER BY p.id ASC
      `);

      if (format === 'csv') {
        const headers = ['id', 'name', 'area_name', 'neighbourhood', 'address', 'latitude', 'longitude', 'theme', 'established_year', 'nearest_metro', 'crowd_level', 'verification_status', 'status'];
        const rows = pandals.map(p => headers.map(h => `"${(p[h] ?? '').toString().replace(/"/g, '""')}"`).join(','));
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="pujo_planner_pandals.csv"');
        return res.send([headers.join(','), ...rows].join('\n'));
      }

      if (format === 'postgres_sql') {
        // Generate ready-to-run PostgreSQL / Supabase SQL statements
        let sqlDump = `-- PUJO PLANNER POSTGRESQL / SUPABASE DUMP\n-- Generated: ${new Date().toISOString()}\n\n`;
        sqlDump += `CREATE TABLE IF NOT EXISTS areas (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  region VARCHAR(100),
  description TEXT,
  banner_image TEXT,
  sort_order INT DEFAULT 0
);\n\n`;
        sqlDump += `CREATE TABLE IF NOT EXISTS pandals (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  official_name VARCHAR(255),
  slug VARCHAR(255) UNIQUE NOT NULL,
  area_id INT REFERENCES areas(id),
  neighbourhood VARCHAR(255),
  address TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  theme TEXT,
  theme_description TEXT,
  description TEXT,
  history TEXT,
  highlights TEXT,
  committee_name VARCHAR(255),
  established_year INT,
  status VARCHAR(50) DEFAULT 'Active',
  active_year INT DEFAULT 2026,
  opening_time VARCHAR(50),
  closing_time VARCHAR(50),
  crowd_level VARCHAR(50) DEFAULT 'Moderate',
  rating NUMERIC(3,2) DEFAULT 4.5,
  rating_count INT DEFAULT 0,
  nearest_metro VARCHAR(255),
  parking_available INT DEFAULT 0,
  wheelchair_access INT DEFAULT 0,
  elder_friendly INT DEFAULT 1,
  family_friendly INT DEFAULT 1,
  verification_status VARCHAR(50) DEFAULT 'VERIFIED',
  source_name VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);\n\n`;

        pandals.forEach(p => {
          const esc = (val: any) => val ? `'${val.toString().replace(/'/g, "''")}'` : 'NULL';
          sqlDump += `INSERT INTO pandals (name, slug, area_id, neighbourhood, address, latitude, longitude, theme, established_year, nearest_metro, crowd_level, verification_status, status) VALUES (${esc(p.name)}, ${esc(p.slug)}, ${p.area_id || 1}, ${esc(p.neighbourhood)}, ${esc(p.address)}, ${p.latitude || 'NULL'}, ${p.longitude || 'NULL'}, ${esc(p.theme)}, ${p.established_year || 'NULL'}, ${esc(p.nearest_metro)}, ${esc(p.crowd_level)}, ${esc(p.verification_status)}, ${esc(p.status)});\n`;
        });

        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', 'attachment; filename="pujo_planner_supabase.sql"');
        return res.send(sqlDump);
      }

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="pujo_planner_pandals.json"');
      res.json(pandals);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 20. ADMIN: BULK IMPORT (CSV or JSON with PREVIEW & VALIDATION)
  router.post('/admin/import', (req: Request, res: Response) => {
    try {
      const { items, commit = false } = req.body;
      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Import items must be a non-empty array' });
      }

      let validCount = 0;
      let duplicateCount = 0;
      let missingCoordsCount = 0;
      const previewRows: any[] = [];

      for (const item of items) {
        const name = (item.name || item.pandal_name || '').trim();
        if (!name) continue;

        const hasCoords = Boolean(item.latitude && item.longitude);
        if (!hasCoords) missingCoordsCount++;

        const isDup = queryOne(db, 'SELECT id FROM pandals WHERE LOWER(name) = ?', [name.toLowerCase()]);
        if (isDup) {
          duplicateCount++;
        } else {
          validCount++;
        }

        previewRows.push({
          name,
          area: item.area || item.area_name || 'North Kolkata',
          address: item.address || 'Address unverified',
          latitude: item.latitude || null,
          longitude: item.longitude || null,
          is_duplicate: !!isDup,
          missing_coords: !hasCoords,
        });

        if (commit && !isDup) {
          const slug = generateSlug(name) + '-' + Date.now().toString().slice(-4);
          executeRun(db, `
            INSERT INTO pandals (name, slug, area_id, neighbourhood, address, latitude, longitude, theme, verification_status, status)
            VALUES (?, ?, 1, ?, ?, ?, ?, ?, 'NEEDS VERIFICATION', 'Active')
          `, [
            name,
            slug,
            item.neighbourhood || '',
            item.address || '',
            item.latitude ? parseFloat(item.latitude) : null,
            item.longitude ? parseFloat(item.longitude) : null,
            item.theme || 'Traditional'
          ]);
        }
      }

      res.json({
        total_detected: items.length,
        valid: validCount,
        duplicates: duplicateCount,
        missing_coordinates: missingCoordsCount,
        committed: commit,
        preview_samples: previewRows.slice(0, 10),
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 21. ADMIN: GENERATE PERFORMANCE TEST DATA (1000 - 10000 records, labeled DEMO DATA)
  router.post('/admin/generate-perf-records', (req: Request, res: Response) => {
    try {
      const count = Math.min(5000, parseInt(req.body.count) || 1000);
      const kolkataCenterLat = 22.5726;
      const kolkataCenterLng = 88.3639;

      for (let i = 1; i <= count; i++) {
        // Random offset within ~15km radius of Kolkata
        const rLat = kolkataCenterLat + (Math.random() - 0.5) * 0.18;
        const rLng = kolkataCenterLng + (Math.random() - 0.5) * 0.16;
        const pName = `[DEMO DATA] Test Pandal #${i}`;
        const pSlug = `demo-pandal-${i}-${Date.now().toString().slice(-4)}`;

        executeRun(db, `
          INSERT INTO pandals (
            name, slug, area_id, neighbourhood, address, latitude, longitude,
            theme, crowd_level, rating, rating_count, verification_status, status, description
          ) VALUES (?, ?, 1, 'Kolkata Test Grid', 'Performance Stress Testing Record', ?, ?, 'Demo Scale Testing', 'Moderate', 4.2, 10, 'DEMO', 'Active', 'Temporary load testing record. Labelled DEMO DATA as per policy.')
        `, [pName, pSlug, rLat, rLng]);
      }

      persistDb();
      res.json({ success: true, message: `Generated ${count} test performance records clearly labeled DEMO DATA.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 22. ADMIN: CLEAR PERFORMANCE TEST DATA
  router.post('/admin/clear-perf-records', (req: Request, res: Response) => {
    try {
      const resCount = executeRun(db, "DELETE FROM pandals WHERE verification_status = 'DEMO'");
      persistDb();
      res.json({ success: true, message: `Deleted ${resCount.changes} temporary test performance records.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
}

// Distance helper (Haversine formula in kilometers)
function getDistanceFromLatLonInKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function stringSimilarity(s1: string, s2: string): number {
  const longer = s1.length > s2.length ? s1 : s2;
  const shorter = s1.length > s2.length ? s2 : s1;
  if (longer.length === 0) return 1.0;
  return (longer.length - editDistance(longer, shorter)) / longer.length;
}

function editDistance(s1: string, s2: string): number {
  const costs: number[] = [];
  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i;
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) costs[j] = j;
      else {
        if (j > 0) {
          let newValue = costs[j - 1];
          if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
            newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
          }
          costs[j - 1] = lastValue;
          lastValue = newValue;
        }
      }
    }
    if (i > 0) costs[s2.length] = lastValue;
  }
  return costs[s2.length];
}
