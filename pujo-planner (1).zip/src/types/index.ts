export type VerificationStatus = 'VERIFIED' | 'PARTIALLY VERIFIED' | 'COMMUNITY SUBMITTED' | 'NEEDS VERIFICATION' | 'DEMO';
export type CrowdLevel = 'Low' | 'Moderate' | 'High' | 'Very High';
export type PandalStatus = 'Active' | 'Seasonal' | 'Temporarily inactive' | 'Historical' | 'Permanently inactive' | 'Unknown';

export interface RestaurantRecommendation {
  name: string;
  cuisine: string;
  famous_for: string;
  distance: string;
  price_range?: string;
}

export interface EmergencyContact {
  id: string;
  title: string;
  number: string;
  category: 'Police' | 'Medical' | 'Helpline' | 'Utility' | 'Transport';
  description: string;
}

export interface Pandal {
  id: number;
  name: string;
  official_name?: string;
  alternate_name?: string;
  category?: string;
  slug: string;
  area_id: number;
  area_name?: string;
  area_slug?: string;
  neighbourhood?: string;
  address?: string;
  latitude: number | null;
  longitude: number | null;
  theme?: string;
  theme_description?: string;
  description?: string;
  history?: string;
  highlights?: string;
  committee_name?: string;
  established_year?: number;
  status: PandalStatus;
  active_year: number;
  last_active_year?: number;
  opening_time?: string;
  closing_time?: string;
  best_time?: string;
  estimated_visit_duration: number;
  crowd_level: CrowdLevel;
  rating: number;
  rating_count: number;
  nearest_metro?: string;
  metro_walk_time?: string;
  nearest_railway?: string;
  parking_available: number | boolean;
  wheelchair_access: number | boolean;
  elder_friendly: number | boolean;
  family_friendly: number | boolean;
  official_website?: string;
  official_social?: string;
  verification_status: VerificationStatus;
  source_name?: string;
  source_url?: string;
  verified_at?: string;
  created_at?: string;
  cover_image?: string;
  distance_km?: number | null;
  nearby_restaurants?: string;
  water_counter_info?: string;
  toilets_available?: number | boolean;
  medical_aid_info?: string;
  police_booth?: string;
  entry_approach_tip?: string;
}

export interface PandalDetail extends Pandal {
  images: Array<{
    id: number;
    url: string;
    caption?: string;
    photographer?: string;
    is_cover: number;
    sort_order: number;
  }>;
  yearly_history: Array<{
    id: number;
    year: number;
    theme?: string;
    theme_description?: string;
    idol_artist?: string;
    pandal_artist?: string;
    lighting_artist?: string;
    highlights?: string;
    awards?: string;
  }>;
  reviews: Array<{
    id: number;
    user_name: string;
    rating: number;
    comment: string;
    visit_date?: string;
    crowd_observed?: string;
    created_at?: string;
  }>;
  crowd_reports: Array<{
    id: number;
    crowd_level: CrowdLevel;
    wait_time_minutes: number;
    report_source: string;
    reported_at: string;
  }>;
  nearby: Array<{
    id: number;
    name: string;
    slug: string;
    neighbourhood?: string;
    theme?: string;
    rating: number;
    crowd_level: CrowdLevel;
    latitude: number;
    longitude: number;
    distance_km: number;
    nearest_metro?: string;
  }>;
}

export interface Area {
  id: number;
  name: string;
  slug: string;
  region: string;
  description?: string;
  banner_image?: string;
  pandal_count: number;
  sort_order: number;
}

export interface RouteStop {
  id: number;
  pandal_id: number;
  pandal_name: string;
  pandal_slug: string;
  neighbourhood?: string;
  address?: string;
  latitude: number | null;
  longitude: number | null;
  nearest_metro?: string;
  crowd_level?: CrowdLevel;
  rating?: number;
  cover_image?: string;
  stop_order: number;
  estimated_duration_mins: number;
  notes?: string;
}

export interface RoutePlan {
  id: number;
  title: string;
  slug: string;
  description: string;
  duration_category: string;
  estimated_hours: number;
  is_preset: number;
  category: string;
  created_by: string;
  stops_count: number;
  total_distance_km: number;
  stops?: RouteStop[];
}

export interface StatsData {
  total_pandals: number;
  verified_count: number;
  pending_verification: number;
  areas_count: number;
  historical_count: number;
  active_this_year: number;
}

export interface DatabaseHealth {
  database_type: string;
  total_pandals: number;
  verified_count: number;
  community_count: number;
  missing_coordinates_count: number;
  areas_coverage: Array<{
    name: string;
    region: string;
    count: number;
  }>;
  recent_submissions_count: number;
  pending_issues_count: number;
  duplicate_clusters_count: number;
  integrity_status: string;
}
