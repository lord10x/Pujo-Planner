import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { Pandal } from '../types';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function useUserStore() {
  const [token, setToken] = useState<string>(() => {
    let t = localStorage.getItem('pujo_user_token');
    if (!t) {
      t = 'usr_' + Math.random().toString(36).substring(2, 12) + Date.now().toString(36);
      localStorage.setItem('pujo_user_token', t);
    }
    return t;
  });

  const [savedIds, setSavedIds] = useState<Set<number>>(new Set());
  const [visitedIds, setVisitedIds] = useState<Set<number>>(new Set());
  const [savedPandals, setSavedPandals] = useState<any[]>([]);
  const [routePandals, setRoutePandals] = useState<Pandal[]>(() => {
    try {
      const stored = localStorage.getItem('pujo_my_route');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((
    message: string,
    type: 'success' | 'error' | 'info' = 'success',
    action?: { label: string; onClick: () => void }
  ) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type, action }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  }, []);

  const refreshSaved = useCallback(async () => {
    if (!token) return;
    try {
      const data = await api.getSaved(token);
      setSavedPandals(data);
      setSavedIds(new Set(data.map(item => item.id)));
      setVisitedIds(new Set(data.filter(item => item.is_visited === 1).map(item => item.id)));
    } catch (e) {
      console.error('Error refreshing saved pandals:', e);
    }
  }, [token]);

  useEffect(() => {
    refreshSaved();
  }, [refreshSaved]);

  const toggleSave = useCallback(async (pandal: Pandal) => {
    try {
      const res = await api.toggleSave(token, pandal.id);
      if (res.saved) {
        setSavedIds(prev => new Set([...prev, pandal.id]));
        addToast(`Saved "${pandal.name}" to My Puja!`, 'success');
      } else {
        setSavedIds(prev => {
          const next = new Set(prev);
          next.delete(pandal.id);
          return next;
        });
        addToast(`Removed "${pandal.name}" from saved list.`, 'info');
      }
      refreshSaved();
    } catch (e) {
      addToast('Failed to update saved list.', 'error');
    }
  }, [token, addToast, refreshSaved]);

  const toggleVisited = useCallback(async (pandalId: number, isVisited: boolean) => {
    try {
      await api.toggleVisited(token, pandalId, isVisited);
      if (isVisited) {
        setVisitedIds(prev => new Set([...prev, pandalId]));
        addToast('Marked as visited! Subho Sharodiyo!', 'success');
      } else {
        setVisitedIds(prev => {
          const next = new Set(prev);
          next.delete(pandalId);
          return next;
        });
      }
      refreshSaved();
    } catch {
      addToast('Failed to update visited status.', 'error');
    }
  }, [token, addToast, refreshSaved]);

  const toggleRoute = useCallback((pandal: Pandal, onGoToRoute?: () => void) => {
    setRoutePandals(prev => {
      const exists = prev.some(p => 
        (p.id !== undefined && pandal.id !== undefined && String(p.id) === String(pandal.id)) ||
        (p.slug && pandal.slug && p.slug === pandal.slug)
      );
      let updated: Pandal[];
      if (exists) {
        updated = prev.filter(p => 
          !(
            (p.id !== undefined && pandal.id !== undefined && String(p.id) === String(pandal.id)) ||
            (p.slug && pandal.slug && p.slug === pandal.slug)
          )
        );
        localStorage.setItem('pujo_my_route', JSON.stringify(updated));
        addToast(`Cancelled and removed "${pandal.name}" from route.`, 'info');
        return updated;
      } else {
        updated = [...prev, pandal];
        localStorage.setItem('pujo_my_route', JSON.stringify(updated));
        addToast(
          `Added "${pandal.name}" to your route (${updated.length} ${updated.length === 1 ? 'stop' : 'stops'})!`,
          'success',
          onGoToRoute ? { label: 'Go to Route →', onClick: onGoToRoute } : undefined
        );
        return updated;
      }
    });
  }, [addToast]);

  const addToRoute = toggleRoute;

  const removeFromRoute = useCallback((pandalIdOrSlug: number | string) => {
    setRoutePandals(prev => {
      const target = prev.find(p => String(p.id) === String(pandalIdOrSlug) || p.slug === String(pandalIdOrSlug));
      const updated = prev.filter(p => String(p.id) !== String(pandalIdOrSlug) && p.slug !== String(pandalIdOrSlug));
      localStorage.setItem('pujo_my_route', JSON.stringify(updated));
      addToast(target ? `Removed "${target.name}" from route.` : 'Removed stop from route.', 'info');
      return updated;
    });
  }, [addToast]);

  const clearRoute = useCallback(() => {
    setRoutePandals([]);
    localStorage.removeItem('pujo_my_route');
    addToast('Puja route cleared.', 'info');
  }, [addToast]);

  const isPandalInRoute = useCallback((pandalOrId: Pandal | number | string) => {
    if (typeof pandalOrId === 'object' && pandalOrId !== null) {
      return routePandals.some(p => 
        (p.id !== undefined && pandalOrId.id !== undefined && String(p.id) === String(pandalOrId.id)) ||
        (p.slug && pandalOrId.slug && p.slug === pandalOrId.slug)
      );
    }
    return routePandals.some(p => String(p.id) === String(pandalOrId) || p.slug === String(pandalOrId));
  }, [routePandals]);

  const reorderRoute = useCallback((newOrder: Pandal[]) => {
    setRoutePandals(newOrder);
    localStorage.setItem('pujo_my_route', JSON.stringify(newOrder));
  }, []);

  const requestLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser.');
      addToast('Geolocation not supported.', 'error');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocationError(null);
        addToast('Location updated! Finding pandals near you.', 'success');
      },
      (err) => {
        setLocationError(err.message);
        addToast('Location access denied. You can still explore all pandals normally.', 'info');
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  }, [addToast]);

  return {
    token,
    savedIds,
    visitedIds,
    savedPandals,
    routePandals,
    userLocation,
    locationError,
    toasts,
    addToast,
    toggleSave,
    toggleVisited,
    addToRoute,
    removeFromRoute,
    clearRoute,
    isPandalInRoute,
    reorderRoute,
    requestLocation,
    refreshSaved,
  };
}
