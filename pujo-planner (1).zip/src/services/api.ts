import { Pandal, PandalDetail, Area, RoutePlan, StatsData, DatabaseHealth } from '../types';

export const api = {
  async getStats(): Promise<StatsData> {
    const res = await fetch('/api/stats');
    if (!res.ok) throw new Error('Failed to fetch stats');
    return res.json();
  },

  async getAreas(): Promise<Area[]> {
    const res = await fetch('/api/areas');
    if (!res.ok) throw new Error('Failed to fetch areas');
    return res.json();
  },

  async getThemes(): Promise<string[]> {
    const res = await fetch('/api/themes');
    if (!res.ok) throw new Error('Failed to fetch themes');
    return res.json();
  },

  async getCategories(): Promise<string[]> {
    const res = await fetch('/api/categories');
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  async getPandals(params: Record<string, any> = {}): Promise<{ data: Pandal[]; pagination: { total: number; page: number; limit: number; total_pages: number } }> {
    const cleanParams = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') {
        cleanParams.append(k, String(v));
      }
    });
    const res = await fetch(`/api/pandals?${cleanParams.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch pandals');
    return res.json();
  },

  async getMapPandals(params: Record<string, any> = {}): Promise<Pandal[]> {
    const cleanParams = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') {
        cleanParams.append(k, String(v));
      }
    });
    const res = await fetch(`/api/pandals-map?${cleanParams.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch map pandals');
    return res.json();
  },

  async quickSearch(q: string): Promise<{ pandals: any[]; areas: any[] }> {
    if (!q.trim()) return { pandals: [], areas: [] };
    const res = await fetch(`/api/pandals/search?q=${encodeURIComponent(q.trim())}`);
    if (!res.ok) throw new Error('Search failed');
    return res.json();
  },

  async getPandal(slug: string): Promise<PandalDetail> {
    const res = await fetch(`/api/pandals/${encodeURIComponent(slug)}`);
    if (!res.ok) throw new Error('Pandal not found');
    return res.json();
  },

  async getRoutes(): Promise<RoutePlan[]> {
    const res = await fetch('/api/routes');
    if (!res.ok) throw new Error('Failed to fetch routes');
    return res.json();
  },

  async getRoute(slug: string): Promise<RoutePlan> {
    const res = await fetch(`/api/routes/${encodeURIComponent(slug)}`);
    if (!res.ok) throw new Error('Route not found');
    return res.json();
  },

  async submitMissingPandal(payload: any) {
    const res = await fetch('/api/submissions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Submission failed');
    return data;
  },

  async submitReview(payload: { pandal_id: number; user_name: string; rating: number; comment: string; visit_date?: string; crowd_observed?: string }) {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Review failed');
    return data;
  },

  async submitCrowdReport(payload: { pandal_id: number; crowd_level: string; wait_time_minutes?: number }) {
    const res = await fetch('/api/crowd-reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Crowd report failed');
    return data;
  },

  async reportIssue(payload: { pandal_id: number; issue_type: string; details: string; reporter_contact?: string }) {
    const res = await fetch('/api/report-issue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Report issue failed');
    return data;
  },

  async getSaved(token: string): Promise<any[]> {
    const res = await fetch(`/api/saved?token=${encodeURIComponent(token)}`);
    if (!res.ok) return [];
    return res.json();
  },

  async toggleSave(token: string, pandal_id: number): Promise<{ saved: boolean }> {
    const res = await fetch('/api/saved/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_token: token, pandal_id }),
    });
    return res.json();
  },

  async toggleVisited(token: string, pandal_id: number, is_visited: boolean) {
    const res = await fetch('/api/saved/visit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_token: token, pandal_id, is_visited }),
    });
    return res.json();
  },

  // Admin APIs
  async getAdminHealth(): Promise<DatabaseHealth> {
    const res = await fetch('/api/admin/health');
    if (!res.ok) throw new Error('Failed to fetch admin health');
    return res.json();
  },

  async getAdminSubmissions(): Promise<any[]> {
    const res = await fetch('/api/admin/submissions');
    if (!res.ok) throw new Error('Failed to fetch submissions');
    return res.json();
  },

  async handleSubmissionAction(id: number, action: string, admin_notes?: string) {
    const res = await fetch(`/api/admin/submissions/${id}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, admin_notes }),
    });
    return res.json();
  },

  async verifyPandal(id: number, status: string, notes?: string) {
    const res = await fetch(`/api/admin/verify/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, notes }),
    });
    return res.json();
  },

  async saveAdminPandal(data: any, id?: number) {
    const url = id ? `/api/admin/pandals/${id}` : '/api/admin/pandals';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },

  async deleteAdminPandal(id: number) {
    const res = await fetch(`/api/admin/pandals/${id}`, { method: 'DELETE' });
    return res.json();
  },

  async checkDuplicates(name: string, lat?: number, lng?: number) {
    const res = await fetch('/api/admin/duplicates/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, lat, lng }),
    });
    return res.json();
  },

  async importRecords(items: any[], commit = false) {
    const res = await fetch('/api/admin/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items, commit }),
    });
    return res.json();
  },

  async generatePerfRecords(count = 1000) {
    const res = await fetch('/api/admin/generate-perf-records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count }),
    });
    return res.json();
  },

  async clearPerfRecords() {
    const res = await fetch('/api/admin/clear-perf-records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    return res.json();
  }
};
