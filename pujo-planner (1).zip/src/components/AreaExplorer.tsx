import React from 'react';
import { Area } from '../types';
import { MapPin, ShieldCheck, Flame, ArrowRight } from 'lucide-react';

interface AreaExplorerProps {
  areas: Area[];
  onSelectArea: (areaSlug: string) => void;
  onOpenMapArea: (areaSlug: string) => void;
}

export const AreaExplorer: React.FC<AreaExplorerProps> = ({
  areas,
  onSelectArea,
  onOpenMapArea,
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      <div className="border-b border-stone-200 dark:border-stone-800 pb-6">
        <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
          REGIONAL DISCOVERY & HERITAGE CIRCUITS
        </span>
        <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
          Explore Kolkata by Area
        </h1>
        <p className="text-xs sm:text-sm text-stone-500 mt-1 max-w-2xl">
          From North Kolkata’s centuried Bonedi Bari aristocratic courtyards to South Kolkata’s majestic art installations and Salt Lake’s grand township parks.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {areas.map((area) => (
          <div
            key={area.id}
            className="group rounded-2xl overflow-hidden bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 shadow-sm hover:shadow-md hover:border-[#D4AF37]/50 transition-all flex flex-col justify-between"
          >
            <div>
              {/* Banner Image */}
              <div className="relative h-44 w-full overflow-hidden bg-stone-900">
                <img
                  src={area.banner_image || 'https://images.unsplash.com/photo-1579618218290-24a26f63a728?auto=format&fit=crop&w=800&q=80'}
                  alt={area.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                <div className="absolute top-3 left-3">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-black/60 backdrop-blur-xs text-[#D4AF37] border border-[#D4AF37]/30">
                    {area.region} Zone
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <h3 className="font-heading font-bold text-lg text-white">
                    {area.name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-stone-300 mt-0.5">
                    <span>{area.pandal_count} Pandals listed</span>
                    <span>·</span>
                    <span className="text-[#D4AF37] flex items-center gap-0.5 font-medium">
                      <ShieldCheck className="w-3 h-3" /> {area.verified_count} verified
                    </span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="p-4">
                <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed line-clamp-3">
                  {area.description}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 pt-0 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between mt-2">
              <button
                onClick={() => onOpenMapArea(area.slug)}
                className="text-xs font-semibold text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 cursor-pointer"
              >
                View on Map
              </button>
              <button
                onClick={() => onSelectArea(area.slug)}
                className="flex items-center gap-1 text-xs font-bold text-[#800020] dark:text-[#E5C158] hover:underline cursor-pointer"
              >
                <span>Browse {area.pandal_count} Pandals</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
