import React, { useState, useEffect } from 'react';
import {
  X, MapPin, Calendar, Clock, Users, Train, Car, Accessibility,
  ShieldCheck, AlertCircle, Heart, Share2, Navigation, Plus, Check,
  Star, MessageSquare, Flame, ExternalLink, Flag, Info, Route, Droplets, Utensils, Footprints
} from 'lucide-react';
import { PandalDetail, Pandal } from '../types';
import { api } from '../services/api';

interface PandalDetailViewProps {
  slug: string;
  onClose: () => void;
  isSaved?: boolean;
  onToggleSave: (pandal: Pandal) => void;
  onAddToRoute: (pandal: Pandal) => void;
  isInRoute?: boolean;
  onSelectPandal: (pandal: Pandal) => void;
  onOpenReportIssue: (pandal: Pandal) => void;
  onOpenRoute?: () => void;
  onOpenDirections?: (pandal: Pandal) => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const PandalDetailView: React.FC<PandalDetailViewProps> = ({
  slug,
  onClose,
  isSaved = false,
  onToggleSave,
  onAddToRoute,
  isInRoute = false,
  onSelectPandal,
  onOpenReportIssue,
  onOpenRoute,
  onOpenDirections,
  addToast,
}) => {
  const [pandal, setPandal] = useState<PandalDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'reviews' | 'crowd'>('overview');

  // Review Form state
  const [reviewerName, setReviewerName] = useState('');
  const [ratingVal, setRatingVal] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  // Crowd Report state
  const [crowdReportLevel, setCrowdReportLevel] = useState<'Low' | 'Moderate' | 'High' | 'Very High'>('Moderate');
  const [waitTimeMins, setWaitTimeMins] = useState(20);
  const [submittingCrowd, setSubmittingCrowd] = useState(false);

  const fetchDetails = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getPandal(slug);
      setPandal(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load pandal information.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDetails();
  }, [slug]);

  const handleShare = async () => {
    if (!pandal) return;
    const shareData = {
      title: `${pandal.name} — Pujo Planner`,
      text: `Check out ${pandal.name} on Pujo Planner! Theme: ${pandal.theme || 'Traditional'}`,
      url: window.location.href,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {}
    } else {
      navigator.clipboard.writeText(window.location.href);
      addToast('Pandal link copied to clipboard!', 'info');
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pandal || !reviewComment.trim()) return;
    try {
      setSubmittingReview(true);
      await api.submitReview({
        pandal_id: pandal.id,
        user_name: reviewerName.trim() || 'Puja Hopper',
        rating: ratingVal,
        comment: reviewComment.trim(),
      });
      addToast('Review submitted successfully! Thank you for sharing your experience.', 'success');
      setReviewComment('');
      fetchDetails();
    } catch (err: any) {
      addToast(err.message || 'Failed to post review', 'error');
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleCrowdSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pandal) return;
    try {
      setSubmittingCrowd(true);
      await api.submitCrowdReport({
        pandal_id: pandal.id,
        crowd_level: crowdReportLevel,
        wait_time_minutes: waitTimeMins,
      });
      addToast('Live crowd observation submitted! Helping fellow devotees.', 'success');
      fetchDetails();
    } catch (err: any) {
      addToast(err.message || 'Failed to submit crowd update', 'error');
    } finally {
      setSubmittingCrowd(false);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="bg-white dark:bg-[#1C1517] p-8 rounded-2xl max-w-md w-full text-center border border-stone-200 dark:border-stone-800">
          <div className="w-12 h-12 border-4 border-[#800020] border-t-transparent rounded-full animate-spin mx-auto" />
          <h4 className="mt-4 font-heading font-bold text-lg text-stone-900 dark:text-stone-100">
            Opening Pandal Sanctuary
          </h4>
          <p className="text-xs text-stone-500 mt-1">Retrieving verified archives and live crowd data...</p>
        </div>
      </div>
    );
  }

  if (error || !pandal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="bg-white dark:bg-[#1C1517] p-6 rounded-2xl max-w-md w-full text-center border border-stone-200 dark:border-stone-800">
          <AlertCircle className="w-10 h-10 text-rose-600 mx-auto" />
          <h4 className="mt-2 font-heading font-bold text-lg text-stone-900 dark:text-stone-100">
            Information Unavailable
          </h4>
          <p className="text-xs text-stone-500 mt-1">{error || 'Pandal could not be found.'}</p>
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded-md cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  const directionsUrl =
    pandal.latitude && pandal.longitude
      ? `https://www.google.com/maps/dir/?api=1&destination=${pandal.latitude},${pandal.longitude}&destination_place_id=${encodeURIComponent(pandal.name + ' Kolkata')}`
      : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(pandal.name + ' ' + (pandal.address || 'Kolkata'))}`;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="w-full max-w-3xl h-full bg-[#FAF7F2] dark:bg-[#161012] overflow-y-auto flex flex-col shadow-2xl border-l border-[#D4AF37]/30">
        {/* Sticky Header Bar */}
        <div className="sticky top-0 z-20 bg-[#FAF7F2]/95 dark:bg-[#161012]/95 backdrop-blur-md px-6 py-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-widest text-[#800020] dark:text-[#D4AF37]">
              {pandal.area_name || 'Kolkata'}
            </span>
            <span className="text-stone-400">·</span>
            <span className="text-xs text-stone-500 dark:text-stone-400">Est. {pandal.established_year || 'Historic'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              aria-label="Share pandal"
              className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-200 transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onToggleSave(pandal)}
              aria-label={isSaved ? 'Remove from saved' : 'Save pandal'}
              className={`p-2 rounded-lg transition-colors cursor-pointer ${
                isSaved ? 'bg-[#800020] text-white' : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-200 hover:bg-stone-200'
              }`}
            >
              <Heart className={`w-4 h-4 ${isSaved ? 'fill-current text-[#D4AF37]' : ''}`} />
            </button>
            <button
              onClick={onClose}
              aria-label="Close dialog"
              className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Hero Image Section */}
        <div className="relative h-64 sm:h-80 w-full bg-stone-900 shrink-0">
          <img
            src={pandal.images?.[0]?.url || pandal.cover_image || 'https://images.unsplash.com/photo-1579618218290-24a26f63a728?auto=format&fit=crop&w=1200&q=80'}
            alt={pandal.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />

          {/* Hero Content Overlay */}
          <div className="absolute bottom-6 left-6 right-6 text-white">
            <div className="flex items-center gap-2 mb-2">
              {pandal.verification_status === 'VERIFIED' ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold bg-[#800020] border border-[#D4AF37]/50 text-white shadow">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" /> VERIFIED ARCHIVE
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-600 text-white">
                  <AlertCircle className="w-3.5 h-3.5" /> COMMUNITY SUBMITTED
                </span>
              )}
              {pandal.verified_at && (
                <span className="text-[11px] text-stone-300">Verified on {pandal.verified_at}</span>
              )}
            </div>

            <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-white">
              {pandal.name}
            </h1>
            {pandal.official_name && pandal.official_name !== pandal.name && (
              <p className="text-xs text-stone-300 italic mt-0.5">{pandal.official_name}</p>
            )}

            <div className="flex items-center flex-wrap gap-x-4 gap-y-1 text-xs text-stone-200 mt-2">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                {pandal.neighbourhood || pandal.address || 'Kolkata'}
              </span>
              <span className="flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
                {pandal.rating.toFixed(1)} ({pandal.rating_count} reviews)
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-stone-300" />
                Crowd: <strong className="text-white">{pandal.crowd_level}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Primary Call to Action Strip */}
        <div className="p-4 sm:p-6 bg-white dark:bg-[#1E1719] border-b border-stone-200 dark:border-stone-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (onOpenDirections && pandal) {
                  onOpenDirections(pandal);
                } else {
                  window.open(directionsUrl, '_blank');
                }
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#800020] text-white hover:bg-[#660018] text-xs font-bold uppercase tracking-wider transition-colors shadow-sm cursor-pointer"
            >
              <Navigation className="w-4 h-4 text-[#D4AF37]" />
              <span>Get Directions</span>
            </button>

            {isInRoute ? (
              <>
                <button
                  onClick={() => pandal && onAddToRoute(pandal)}
                  title="Remove this pandal from your route plan"
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs active:scale-95"
                >
                  <X className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  <span>Cancel / Remove from Route</span>
                </button>

                <button
                  onClick={() => {
                    onClose();
                    if (onOpenRoute) onOpenRoute();
                  }}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-gradient-to-r from-[#800020] to-[#A51D24] text-white hover:from-[#660018] hover:to-[#800020] text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm border border-[#D4AF37]/50 active:scale-95"
                >
                  <Route className="w-4 h-4 text-[#D4AF37]" />
                  <span>Go to Route Plan →</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => pandal && onAddToRoute(pandal)}
                title="Add to route planner"
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-700 border border-stone-300 dark:border-stone-700 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs active:scale-95"
              >
                <Plus className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
                <span>+ Add to Route</span>
              </button>
            )}
          </div>

          <button
            onClick={() => onOpenReportIssue(pandal)}
            className="flex items-center gap-1.5 text-xs text-stone-500 hover:text-rose-600 transition-colors"
          >
            <Flag className="w-3.5 h-3.5" />
            <span>Report issue</span>
          </button>
        </div>

        {/* Content Navigation Tabs */}
        <div className="px-6 border-b border-stone-200 dark:border-stone-800 flex gap-6 text-sm font-medium">
          {(['overview', 'history', 'reviews', 'crowd'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-3 capitalize border-b-2 transition-colors cursor-pointer ${
                activeTab === tab
                  ? 'border-[#800020] dark:border-[#D4AF37] text-[#800020] dark:text-[#D4AF37] font-bold'
                  : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-300'
              }`}
            >
              {tab === 'crowd' ? 'Live Crowd' : tab}
            </button>
          ))}
        </div>

        {/* Tab Content Panes */}
        <div className="p-6 flex-1 space-y-6">
          {activeTab === 'overview' && (
            <>
              {/* This Year's Theme */}
              {pandal.theme && (
                <div className="bg-[#FAF7F2] dark:bg-[#20181A] p-5 rounded-xl border border-[#D4AF37]/30">
                  <h3 className="font-heading font-bold text-lg text-[#800020] dark:text-[#E5C158] flex items-center gap-2">
                    <Flame className="w-5 h-5" />
                    2026 Theme: {pandal.theme}
                  </h3>
                  {pandal.theme_description && (
                    <p className="mt-2 text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
                      {pandal.theme_description}
                    </p>
                  )}
                </div>
              )}

              {/* About & Description */}
              <div>
                <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
                  About the Pandal
                </h3>
                <p className="mt-2 text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
                  {pandal.description || 'Information not yet fully documented. Submissions and additions welcome.'}
                </p>
              </div>

              {/* Highlights */}
              {pandal.highlights && (
                <div>
                  <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
                    Artistic & Spiritual Highlights
                  </h3>
                  <p className="mt-2 text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
                    {pandal.highlights}
                  </p>
                </div>
              )}

              {/* Practical Visiting Information Grid */}
              {/* Essential Facilities & Amenities */}
              <div>
                <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 mb-3 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Essential Facilities & Darshan Amenities</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-emerald-950 dark:text-emerald-200">
                      <Droplets className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <span>Drinking Water Counter</span>
                    </div>
                    <p className="text-emerald-800 dark:text-emerald-300 text-[11px] leading-relaxed">
                      {pandal.water_counter_info || 'Free KMC drinking water kiosk located near the main queue barricade.'}
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/60 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-purple-950 dark:text-purple-200">
                      <ShieldCheck className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span>Police & First Aid Standby</span>
                    </div>
                    <p className="text-purple-800 dark:text-purple-300 text-[11px] leading-relaxed">
                      {pandal.police_booth || pandal.medical_aid_info || 'Kolkata Police assistance kiosk & medical volunteers on standby.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Nearby Famous Food Joints & Restaurants */}
              {pandal.nearby_restaurants && (
                <div className="p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-amber-950 dark:text-amber-200 text-sm">
                    <Utensils className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span>Nearby Famous Restaurants & Street Food</span>
                  </div>
                  <p className="text-amber-900 dark:text-amber-200 text-xs leading-relaxed">
                    {pandal.nearby_restaurants}
                  </p>
                </div>
              )}

              {/* Visiting & Transport Guide */}
              <div>
                <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 mb-3 flex items-center gap-2">
                  <Train className="w-4 h-4 text-blue-600" />
                  <span>Transit, Metro & Arrival Guide</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/60 space-y-1">
                    <span className="text-blue-900 dark:text-blue-300 font-bold flex items-center gap-1">
                      <Train className="w-3.5 h-3.5" /> Nearest Metro Station
                    </span>
                    <p className="text-blue-950 dark:text-blue-100 font-extrabold text-sm mt-0.5">
                      {pandal.nearest_metro || 'Nearest station listed in route planner'}
                    </p>
                    {pandal.metro_walk_time && (
                      <p className="text-blue-800 dark:text-blue-300 text-[11px] flex items-center gap-1 mt-1">
                        <Footprints className="w-3.5 h-3.5" />
                        <span>{pandal.metro_walk_time}</span>
                      </p>
                    )}
                  </div>

                  <div className="p-3.5 rounded-lg bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 space-y-1">
                    <span className="text-stone-400 font-medium">Timings & Best Time</span>
                    <p className="text-stone-800 dark:text-stone-200 font-bold mt-0.5">
                      {pandal.opening_time || '10:00 AM'} — {pandal.closing_time || '03:00 AM'}
                    </p>
                    <p className="text-stone-500 text-[11px]">Best time to visit: {pandal.best_time || 'Early morning or late afternoon'}</p>
                  </div>

                  <div className="p-3.5 rounded-lg bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 space-y-1">
                    <span className="text-stone-400 font-medium">Special Darshan & Accessibility</span>
                    <p className="text-stone-700 dark:text-stone-300">
                      Wheelchair Lane: <strong>{pandal.wheelchair_access ? 'Yes (Priority Entry)' : 'Limited Steps'}</strong>
                    </p>
                    <p className="text-stone-700 dark:text-stone-300">
                      Elderly & Family Friendly: <strong>{pandal.elder_friendly ? 'Designated queue lane' : 'High crowd congestion'}</strong>
                    </p>
                  </div>

                  <div className="p-3.5 rounded-lg bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 space-y-1">
                    <span className="text-stone-400 font-medium">Parking & Entry Route</span>
                    <p className="text-stone-800 dark:text-stone-200 font-semibold">
                      {pandal.parking_available ? 'Designated parking zone nearby' : 'No street parking; public transit strongly recommended'}
                    </p>
                    {pandal.entry_approach_tip && (
                      <p className="text-stone-600 dark:text-stone-400 text-[11px] mt-1 italic">
                        Tip: {pandal.entry_approach_tip}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Photo Showcase Gallery */}
              {pandal.images && pandal.images.length > 0 && (
                <div>
                  <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 mb-3">
                    Pandal Showcase Photos
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {pandal.images.map((img) => (
                      <div key={img.id} className="relative h-32 rounded-xl overflow-hidden group/img bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-2xs">
                        <img src={img.url} alt={img.caption || pandal.name} className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-300" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-2">
                          <span className="text-white text-[10px] font-semibold truncate">{img.caption || pandal.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Data Transparency & Source */}
              <div className="p-4 rounded-lg bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-400">
                <div className="flex items-center gap-1.5 font-bold text-stone-800 dark:text-stone-200 mb-1">
                  <Info className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
                  <span>Data Provenance & Source</span>
                </div>
                <p>
                  Source: <strong>{pandal.source_name || 'Community contribution via Pujo Planner'}</strong>
                </p>
                <p className="mt-0.5">
                  Verification status: <strong>{pandal.verification_status}</strong>
                  {pandal.verified_at && ` (Last reviewed: ${pandal.verified_at})`}
                </p>
              </div>

              {/* Nearby Pandals */}
              {pandal.nearby && pandal.nearby.length > 0 && (
                <div>
                  <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 mb-3">
                    Nearby Pandals in This Circuit
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {pandal.nearby.map((np) => (
                      <div
                        key={np.id}
                        onClick={() => onSelectPandal(np as any)}
                        className="p-3 rounded-lg bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 hover:border-[#D4AF37] transition-colors cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <h4 className="font-bold text-xs text-stone-900 dark:text-stone-100 line-clamp-1">{np.name}</h4>
                          <p className="text-[11px] text-stone-500 mt-0.5">{np.neighbourhood || 'Kolkata'}</p>
                        </div>
                        <span className="text-xs font-semibold text-[#800020] dark:text-[#D4AF37] shrink-0 ml-2">
                          {np.distance_km} km
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
                  Heritage & Historical Background
                </h3>
                <p className="mt-2 text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
                  {pandal.history || 'Historical documentation for this pandal is currently being compiled from municipal and committee archives.'}
                </p>
              </div>

              <div className="pt-4 border-t border-stone-200 dark:border-stone-800">
                <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 mb-3">
                  Yearly Puja Archives & Retrospectives
                </h3>

                {pandal.yearly_history && pandal.yearly_history.length > 0 ? (
                  <div className="space-y-3">
                    {pandal.yearly_history.map((yh) => (
                      <div key={yh.id} className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-sm text-[#800020] dark:text-[#E5C158]">
                            Year {yh.year}
                          </span>
                          {yh.awards && <span className="text-xs text-[#B8860B] font-medium">{yh.awards}</span>}
                        </div>
                        <h4 className="font-semibold text-sm text-stone-800 dark:text-stone-200 mt-1">
                          {yh.theme || 'Archived Theme'}
                        </h4>
                        {yh.theme_description && (
                          <p className="text-xs text-stone-600 dark:text-stone-400 mt-1">{yh.theme_description}</p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-stone-500">No prior years recorded yet for this entry.</p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {/* Review Submission Form */}
              <form onSubmit={handleReviewSubmit} className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 space-y-3">
                <h4 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100">
                  Leave a Devotee Review
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Your Name (e.g. Joydeep Ghosh)"
                    value={reviewerName}
                    onChange={(e) => setReviewerName(e.target.value)}
                    className="p-2 text-xs rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                  />
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-stone-500">Rating:</span>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRatingVal(star)}
                        className={`p-1 ${ratingVal >= star ? 'text-[#D4AF37]' : 'text-stone-300'}`}
                      >
                        <Star className="w-4 h-4 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>
                <textarea
                  placeholder="Share details about the idol, crowd management, illumination or queue times..."
                  rows={3}
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  required
                  className="w-full p-2.5 text-xs rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                />
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded cursor-pointer disabled:opacity-50"
                >
                  {submittingReview ? 'Submitting...' : 'Post Review'}
                </button>
              </form>

              {/* Reviews List */}
              <div className="space-y-3">
                {pandal.reviews && pandal.reviews.length > 0 ? (
                  pandal.reviews.map((rev) => (
                    <div key={rev.id} className="p-3.5 rounded-lg bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-xs text-stone-900 dark:text-stone-100">{rev.user_name}</span>
                        <div className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
                          <span className="font-bold text-xs">{rev.rating}</span>
                        </div>
                      </div>
                      <p className="text-xs text-stone-600 dark:text-stone-300 mt-2 leading-relaxed">{rev.comment}</p>
                      {rev.visit_date && (
                        <p className="text-[10px] text-stone-400 mt-1">Visited {rev.visit_date}</p>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-stone-500">No reviews yet. Be the first to review this pandal!</p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'crowd' && (
            <div className="space-y-6">
              {/* Current Crowd Status */}
              <div className="p-5 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
                <span className="text-xs text-stone-400 uppercase tracking-widest font-bold">Current Observation</span>
                <div className="flex items-center justify-between mt-2">
                  <h3 className="font-heading font-extrabold text-2xl text-[#800020] dark:text-[#E5C158]">
                    {pandal.crowd_level} Crowd
                  </h3>
                  <span className="text-xs text-stone-500">Est. wait: ~{pandal.estimated_visit_duration} mins</span>
                </div>
              </div>

              {/* Community Live Report Form */}
              <form onSubmit={handleCrowdSubmit} className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 space-y-3">
                <h4 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100">
                  Are you at {pandal.name} right now?
                </h4>
                <p className="text-xs text-stone-500">Help the community by submitting real-time queue observations.</p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['Low', 'Moderate', 'High', 'Very High'] as const).map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setCrowdReportLevel(level)}
                      className={`py-2 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
                        crowdReportLevel === level
                          ? 'bg-[#800020] text-white border-[#800020]'
                          : 'bg-stone-50 dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-3 text-xs">
                  <span className="text-stone-500">Approx wait time (mins):</span>
                  <input
                    type="number"
                    min={0}
                    max={180}
                    value={waitTimeMins}
                    onChange={(e) => setWaitTimeMins(parseInt(e.target.value) || 0)}
                    className="w-20 p-1.5 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900 text-center font-bold"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submittingCrowd}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded cursor-pointer disabled:opacity-50"
                >
                  {submittingCrowd ? 'Updating...' : 'Submit Crowd Update'}
                </button>
              </form>

              {/* Historical Recent Crowd Logs */}
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-stone-400 mb-2">
                  Recent Community Logs
                </h4>
                <div className="space-y-2">
                  {pandal.crowd_reports && pandal.crowd_reports.length > 0 ? (
                    pandal.crowd_reports.map((cr) => (
                      <div key={cr.id} className="p-2.5 rounded bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex items-center justify-between text-xs">
                        <span className="font-semibold text-stone-800 dark:text-stone-200">{cr.crowd_level} Crowd</span>
                        <span className="text-stone-500 text-[11px]">{new Date(cr.reported_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-stone-500">No crowd logs recorded today yet.</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
