import React, { useState, useEffect } from 'react';
import { Search, Compass, Map, Route, Sparkles, ShieldCheck, Flame, ChevronRight } from 'lucide-react';
import { StatsData } from '../types';

interface HeroSectionProps {
  stats: StatsData | null;
  onSearchSubmit: (q: string) => void;
  onNavigate: (tab: string) => void;
  onSelectSuggestion?: (item: any) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  stats,
  onSearchSubmit,
  onNavigate,
  onSelectSuggestion,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<any[]>([]);

  // Puja 2026 Countdown calculation (Maha Shashti October 16, 2026)
  const targetPujaDate = new Date('2026-10-16T00:00:00+05:30').getTime();
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; mins: number; secs: number }>({
    days: 0,
    hours: 0,
    mins: 0,
    secs: 0,
  });

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date().getTime();
      const diff = Math.max(0, targetPujaDate - now);
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        mins: Math.floor((diff / 1000 / 60) % 60),
        secs: Math.floor((diff / 1000) % 60),
      });
    };
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearchSubmit(searchTerm.trim());
    }
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-[#FAF7F2] via-[#F5EFE6] to-[#FAF7F2] dark:from-[#130E10] dark:via-[#1A1215] dark:to-[#130E10] border-b border-[#D4AF37]/20 alpana-pattern py-12 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto space-y-6">
          {/* Festive Kicker & Countdown Pill */}
          <div className="inline-flex items-center gap-2 sm:gap-3 px-3.5 py-1.5 rounded-full bg-white/80 dark:bg-stone-900/80 border border-[#D4AF37]/40 shadow-xs text-xs">
            <span className="font-bold text-[#800020] dark:text-[#E5C158] flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
              DURGA PUJA 2026
            </span>
            <span className="text-stone-300 dark:text-stone-700">|</span>
            <div className="font-mono text-[11px] text-stone-700 dark:text-stone-300 font-semibold flex items-center gap-1.5">
              <span>{timeLeft.days}d</span>
              <span>{timeLeft.hours}h</span>
              <span>{timeLeft.mins}m</span>
              <span>{timeLeft.secs}s</span>
            </div>
          </div>

          {/* Main Headline */}
          <h1 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-[#1C1917] dark:text-[#FBF7F0] tracking-tight leading-tight">
            YOUR ULTIMATE <span className="text-[#800020] dark:text-[#E5C158]">KOLKATA PUJA</span> GUIDE
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Discover pandals. Plan your route. Avoid the crowds. Experience Durga Puja your way.
          </p>

          {/* Search Box */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto relative pt-2">
            <div className="relative flex items-center shadow-lg rounded-2xl overflow-hidden bg-white dark:bg-[#1E1719] border-2 border-[#D4AF37]/50 focus-within:border-[#800020] transition-colors">
              <Search className="w-5 h-5 text-stone-400 ml-4 shrink-0" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search pandals, areas, themes, metro stations or landmarks..."
                className="w-full py-4 px-3 text-sm sm:text-base text-stone-900 dark:text-stone-100 bg-transparent focus:outline-hidden"
              />
              <button
                type="submit"
                className="px-6 py-4 bg-gradient-to-r from-[#800020] to-[#A51D24] text-white text-xs sm:text-sm font-bold uppercase tracking-wider hover:from-[#6B001B] transition-colors cursor-pointer shrink-0"
              >
                Search
              </button>
            </div>
          </form>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
            <button
              onClick={() => onNavigate('explore')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#800020] text-white hover:bg-[#660018] text-xs uppercase tracking-wider font-bold shadow-md hover:shadow-lg transition-all cursor-pointer"
            >
              <Compass className="w-4 h-4 text-[#D4AF37]" />
              <span>Explore Pandals</span>
            </button>

            <button
              onClick={() => onNavigate('map')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white dark:bg-stone-800 text-stone-800 dark:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 border border-stone-300 dark:border-stone-700 text-xs uppercase tracking-wider font-bold shadow-xs transition-all cursor-pointer"
            >
              <Map className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
              <span>Explore Map</span>
            </button>

            <button
              onClick={() => onNavigate('routes')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white dark:bg-stone-800 text-stone-800 dark:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 border border-stone-300 dark:border-stone-700 text-xs uppercase tracking-wider font-bold shadow-xs transition-all cursor-pointer"
            >
              <Route className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
              <span>Plan My Puja</span>
            </button>
          </div>
        </div>

        {/* Dynamic Statistics Strip (Never Hardcoded, from Database) */}
        {stats && (
          <div className="mt-14 max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 text-center">
            <div className="p-4 rounded-xl bg-white/70 dark:bg-stone-900/70 backdrop-blur-xs border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-stone-400">Total Pandals Listed</span>
              <p className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
                {stats.total_pandals.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/70 dark:bg-stone-900/70 backdrop-blur-xs border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-emerald-600 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Verified Pandals
              </span>
              <p className="font-heading font-extrabold text-2xl sm:text-3xl text-emerald-600 mt-1">
                {stats.verified_pandals.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/70 dark:bg-stone-900/70 backdrop-blur-xs border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-stone-400">Areas Covered</span>
              <p className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
                {stats.areas_covered} Zones
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/70 dark:bg-stone-900/70 backdrop-blur-xs border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-[#800020] dark:text-[#E5C158]">
                Currently Active
              </span>
              <p className="font-heading font-extrabold text-2xl sm:text-3xl text-[#800020] dark:text-[#E5C158] mt-1">
                {stats.active_pandals} Pandals
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
