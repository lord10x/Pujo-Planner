import React from 'react';
import { Home, Compass, Map, Route, Bookmark } from 'lucide-react';

interface MobileBottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  savedCount: number;
  routeCount?: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  setCurrentTab,
  savedCount,
  routeCount = 0,
}) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'explore', label: 'Explore', icon: Compass },
    { id: 'map', label: 'Map', icon: Map },
    { id: 'routes', label: 'Routes', icon: Route, badge: routeCount > 0 ? routeCount : null },
    { id: 'mypuja', label: 'My Puja', icon: Bookmark, badge: savedCount > 0 ? savedCount : null },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF7F2]/95 dark:bg-[#150F11]/95 backdrop-blur-md border-t border-[#D4AF37]/30 pb-safe">
      <div className="grid grid-cols-5 h-16">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className={`flex flex-col items-center justify-center gap-1 transition-colors relative cursor-pointer ${
                isActive
                  ? 'text-[#800020] dark:text-[#E5C158] font-bold'
                  : 'text-stone-500 dark:text-stone-400 hover:text-stone-800'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                {tab.badge && (
                  <span className="absolute -top-1.5 -right-2 text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-[#800020] text-white">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] tracking-tight">{tab.label}</span>
              {isActive && (
                <span className="absolute top-0 w-8 h-0.5 bg-[#800020] dark:bg-[#D4AF37] rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
