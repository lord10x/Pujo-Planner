import React, { useState, useEffect } from 'react';
import {
  Search, Filter, MapPin, SlidersHorizontal, PlusCircle, RotateCcw,
  Star, ChevronLeft, ChevronRight, Train, Check, ShieldCheck, Flame, Map
} from 'lucide-react';
import { Pandal, Area } from '../types';
import { PandalCard } from './PandalCard';
import { api } from '../services/api';

interface ExploreViewProps {
  initialSearch?: string;
  initialAreaSlug?: string;
  areas: Area[];
  themes: string[];
  userLocation: { lat: number; lng: number } | null;
  onRequestLocation: () => void;
  savedIds: Set<number>;
  onToggleSave: (pandal: Pandal) => void;
  onAddToRoute: (pandal: Pandal) => void;
  isInRoute: (pandalId: number) => boolean;
  onSelectPandal: (pandal: Pandal) => void;
  onOpenAddModal: () => void;
  onSwitchToMap: () => void;
  onOpenRoute?: () => void;
  onOpenDirections?: (pandal: Pandal) => void;
}

export const ExploreView: React.FC<ExploreViewProps> = ({
  initialSearch = '',
  initialAreaSlug = '',
  areas,
  themes,
  userLocation,
  onRequestLocation,
  savedIds,
  onToggleSave,
  onAddToRoute,
  isInRoute,
  onSelectPandal,
  onOpenAddModal,
  onSwitchToMap,
  onOpenRoute,
  onOpenDirections,
}) => {
  const [search, setSearch] = useState(initialSearch);
  const [selectedArea, setSelectedArea] = useState(initialAreaSlug);
  const [selectedTheme, setSelectedTheme] = useState('');
  const [selectedCrowd, setSelectedCrowd] = useState('');
  const [minRating, setMinRating] = useState('');
  const [onlyMetro, setOnlyMetro] = useState(false);
  const [onlyWheelchair, setOnlyWheelchair] = useState(false);
  const [onlyElderFriendly, setOnlyElderFriendly] = useState(false);
  const [onlyParking, setOnlyParking] = useState(false);
  const [verificationFilter, setVerificationFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('Active');
  const [sortBy, setSortBy] = useState('recommended');
  const [page, setPage] = useState(1);
  const [maxDistance, setMaxDistance] = useState('');

  const [pandals, setPandals] = useState<Pandal[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showFiltersDrawer, setShowFiltersDrawer] = useState(false);

  const fetchPandals = async () => {
    try {
      setLoading(true);
      const params: Record<string, any> = {
        page,
        limit: 24,
        search,
        area_slug: selectedArea,
        theme: selectedTheme,
        crowd: selectedCrowd,
        rating: minRating,
        metro: onlyMetro ? '1' : undefined,
        wheelchair: onlyWheelchair ? '1' : undefined,
        elder_friendly: onlyElderFriendly ? '1' : undefined,
        parking: onlyParking ? '1' : undefined,
        verification: verificationFilter,
        status: statusFilter,
        sort: sortBy,
      };

      if (userLocation) {
        params.lat = userLocation.lat;
        params.lng = userLocation.lng;
        if (maxDistance) params.max_distance_km = maxDistance;
      }

      const res = await api.getPandals(params);
      setPandals(res.data);
      setTotalCount(res.pagination.total);
      setTotalPages(res.pagination.total_pages);
    } catch (e) {
      console.error('Failed to load pandals:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPandals();
  }, [
    page, search, selectedArea, selectedTheme, selectedCrowd,
    minRating, onlyMetro, onlyWheelchair, onlyElderFriendly,
    onlyParking, verificationFilter, statusFilter, sortBy,
    userLocation, maxDistance
  ]);

  const resetFilters = () => {
    setSearch('');
    setSelectedArea('');
    setSelectedTheme('');
    setSelectedCrowd('');
    setMinRating('');
    setOnlyMetro(false);
    setOnlyWheelchair(false);
    setOnlyElderFriendly(false);
    setOnlyParking(false);
    setVerificationFilter('ALL');
    setStatusFilter('Active');
    setSortBy('recommended');
    setMaxDistance('');
    setPage(1);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 animate-in fade-in">
      {/* Title & Overview Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-6">
        <div>
          <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
            KOLKATA DURGA PUJA DIRECTORY
          </span>
          <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
            Explore Kolkata Pandals
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Showing <strong className="text-stone-900 dark:text-stone-100">{totalCount.toLocaleString()}</strong> pandals in current query
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onSwitchToMap}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold uppercase tracking-wider bg-white dark:bg-stone-800 text-[#800020] dark:text-[#E5C158] border border-[#D4AF37]/40 hover:bg-[#800020]/5 rounded-md shadow-xs transition-colors cursor-pointer"
          >
            <Map className="w-4 h-4" />
            <span>Map View</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white hover:bg-[#660018] rounded-md shadow-sm transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-[#D4AF37]" />
            <span>+ Add Missing Pandal</span>
          </button>
        </div>
      </div>

      {/* Search & Main Filter Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
            <input
              type="text"
              placeholder="Search by pandal name, area, theme, or metro station..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#1E1719] text-stone-900 dark:text-stone-100 shadow-xs focus:outline-hidden focus:border-[#800020]"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-3 text-xs text-stone-400 hover:text-stone-600"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick Sort Dropdown */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={sortBy}
              onChange={(e) => { setSortBy(e.target.value); setPage(1); }}
              className="py-2.5 px-3 text-xs font-semibold rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#1E1719] text-stone-800 dark:text-stone-200 shadow-xs cursor-pointer flex-1 sm:flex-none"
            >
              <option value="recommended">Sort: Recommended</option>
              <option value="rating">Sort: Highest Rated</option>
              <option value="popular">Sort: Most Popular</option>
              <option value="crowd_asc">Sort: Lowest Crowd First</option>
              {userLocation && <option value="distance">Sort: Nearest Distance</option>}
              <option value="recent_verified">Sort: Recently Verified</option>
              <option value="established_asc">Sort: Oldest Heritage</option>
              <option value="name">Sort: A-Z Alphabetical</option>
            </select>

            {/* Toggle Filters Mobile / Advanced */}
            <button
              onClick={() => setShowFiltersDrawer(!showFiltersDrawer)}
              className={`p-2.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-colors cursor-pointer ${
                showFiltersDrawer
                  ? 'bg-[#800020] text-white border-[#800020]'
                  : 'bg-white dark:bg-[#1E1719] border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="hidden sm:inline">Filters</span>
            </button>
          </div>
        </div>

        {/* Quick Area Pill Filter Row */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => { setSelectedArea(''); setPage(1); }}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer font-medium ${
              selectedArea === ''
                ? 'bg-[#800020] text-white font-bold'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
            }`}
          >
            All Kolkata Areas
          </button>
          {areas.map((a) => (
            <button
              key={a.id}
              onClick={() => { setSelectedArea(a.slug); setPage(1); }}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer font-medium ${
                selectedArea === a.slug
                  ? 'bg-[#800020] text-white font-bold'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
              }`}
            >
              {a.name} ({a.pandal_count})
            </button>
          ))}
        </div>

        {/* Advanced Filters Panel */}
        {showFiltersDrawer && (
          <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 shadow-sm space-y-4 animate-in fade-in">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              {/* Theme Filter */}
              <div>
                <label className="block font-bold text-stone-700 dark:text-stone-300 mb-1">Theme</label>
                <select
                  value={selectedTheme}
                  onChange={(e) => { setSelectedTheme(e.target.value); setPage(1); }}
                  className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                >
                  <option value="">All Themes</option>
                  {themes.slice(0, 15).map((t, idx) => (
                    <option key={idx} value={t}>
                      {t.length > 35 ? t.slice(0, 35) + '...' : t}
                    </option>
                  ))}
                </select>
              </div>

              {/* Crowd Filter */}
              <div>
                <label className="block font-bold text-stone-700 dark:text-stone-300 mb-1">Crowd Level</label>
                <select
                  value={selectedCrowd}
                  onChange={(e) => { setSelectedCrowd(e.target.value); setPage(1); }}
                  className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                >
                  <option value="">Any Crowd Level</option>
                  <option value="Low">Low Crowd Only</option>
                  <option value="Moderate">Moderate Crowd</option>
                  <option value="High">High Crowd</option>
                  <option value="Very High">Very High (Mega Pandals)</option>
                </select>
              </div>

              {/* Verification Filter */}
              <div>
                <label className="block font-bold text-stone-700 dark:text-stone-300 mb-1">Verification</label>
                <select
                  value={verificationFilter}
                  onChange={(e) => { setVerificationFilter(e.target.value); setPage(1); }}
                  className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                >
                  <option value="ALL">All Records</option>
                  <option value="VERIFIED">Verified Only</option>
                  <option value="COMMUNITY SUBMITTED">Community Submitted</option>
                </select>
              </div>

              {/* Rating Filter */}
              <div>
                <label className="block font-bold text-stone-700 dark:text-stone-300 mb-1">Minimum Rating</label>
                <select
                  value={minRating}
                  onChange={(e) => { setMinRating(e.target.value); setPage(1); }}
                  className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                >
                  <option value="">All Ratings</option>
                  <option value="4.8">★ 4.8 & Above</option>
                  <option value="4.5">★ 4.5 & Above</option>
                  <option value="4.0">★ 4.0 & Above</option>
                </select>
              </div>
            </div>

            {/* Checkbox Amenities */}
            <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-stone-100 dark:border-stone-800 text-xs">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyMetro}
                  onChange={(e) => { setOnlyMetro(e.target.checked); setPage(1); }}
                  className="rounded text-[#800020]"
                />
                <span>Near Metro Station</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyWheelchair}
                  onChange={(e) => { setOnlyWheelchair(e.target.checked); setPage(1); }}
                  className="rounded text-[#800020]"
                />
                <span>Wheelchair Accessible</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyElderFriendly}
                  onChange={(e) => { setOnlyElderFriendly(e.target.checked); setPage(1); }}
                  className="rounded text-[#800020]"
                />
                <span>Elder & Family Friendly</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyParking}
                  onChange={(e) => { setOnlyParking(e.target.checked); setPage(1); }}
                  className="rounded text-[#800020]"
                />
                <span>Parking Available</span>
              </label>

              <button
                onClick={resetFilters}
                className="ml-auto flex items-center gap-1 text-xs text-[#800020] dark:text-[#E5C158] hover:underline cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Filters</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Pandal Grid / Empty State */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-80 rounded-xl bg-stone-200 dark:bg-stone-800 animate-pulse" />
          ))}
        </div>
      ) : pandals.length === 0 ? (
        /* Empty State with "+ ADD MISSING PANDAL" callout */
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 space-y-4 max-w-xl mx-auto shadow-sm">
          <div className="w-12 h-12 rounded-full bg-[#800020]/10 text-[#800020] dark:text-[#E5C158] flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h3 className="font-heading font-extrabold text-xl text-stone-900 dark:text-stone-100">
              CAN'T FIND THIS PANDAL?
            </h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto leading-relaxed">
              We may be missing this pandal from our directory. Help thousands of fellow devotees by adding it now!
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={onOpenAddModal}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#800020] text-white hover:bg-[#660018] text-xs font-bold uppercase tracking-wider shadow cursor-pointer"
            >
              <PlusCircle className="w-4 h-4 text-[#D4AF37]" />
              <span>+ Add Missing Pandal</span>
            </button>

            <button
              onClick={resetFilters}
              className="w-full sm:w-auto px-5 py-2.5 rounded-lg border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 text-xs font-semibold cursor-pointer"
            >
              Explore Nearby Pandals
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {pandals.map((pandal) => (
              <PandalCard
                key={pandal.id}
                pandal={pandal}
                isSaved={savedIds.has(pandal.id)}
                onToggleSave={onToggleSave}
                onAddToRoute={onAddToRoute}
                isInRoute={isInRoute(pandal.id)}
                onSelect={onSelectPandal}
                onOpenRoute={onOpenRoute}
                onOpenDirections={onOpenDirections}
              />
            ))}
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between border-t border-stone-200 dark:border-stone-800 pt-6">
              <span className="text-xs text-stone-500">
                Showing {((page - 1) * 24) + 1}–{Math.min(page * 24, totalCount)} of {totalCount.toLocaleString()} pandals
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page === 1}
                  className="p-2 rounded-lg border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <span className="text-xs font-semibold px-2 text-stone-800 dark:text-stone-200">
                  Page {page} of {totalPages}
                </span>

                <button
                  onClick={() => setPage(Math.min(totalPages, page + 1))}
                  disabled={page === totalPages}
                  className="p-2 rounded-lg border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
