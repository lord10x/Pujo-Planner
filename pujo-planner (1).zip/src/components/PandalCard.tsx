import React from 'react';
import { MapPin, Train, Star, Navigation, Heart, Plus, Check, ShieldCheck, AlertCircle, Eye, X, Route, Droplets, Utensils } from 'lucide-react';
import { Pandal } from '../types';

interface PandalCardProps {
  pandal: Pandal;
  isSaved?: boolean;
  onToggleSave: (pandal: Pandal) => void;
  onAddToRoute: (pandal: Pandal) => void;
  isInRoute?: boolean;
  onSelect: (pandal: Pandal) => void;
  onOpenRoute?: () => void;
  onOpenDirections?: (pandal: Pandal) => void;
}

export const PandalCard: React.FC<PandalCardProps> = ({
  pandal,
  isSaved = false,
  onToggleSave,
  onAddToRoute,
  isInRoute = false,
  onSelect,
  onOpenRoute,
  onOpenDirections,
}) => {
  // Construct Directions URL
  const getDirectionsUrl = () => {
    if (pandal.latitude && pandal.longitude) {
      return `https://www.google.com/maps/dir/?api=1&destination=${pandal.latitude},${pandal.longitude}&destination_place_id=${encodeURIComponent(pandal.name + ' Kolkata')}`;
    }
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(pandal.name + ' ' + (pandal.address || 'Kolkata'))}`;
  };

  const crowdColors: Record<string, string> = {
    'Low': 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
    'Moderate': 'text-amber-700 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-800',
    'High': 'text-orange-700 bg-orange-50 dark:bg-orange-950/40 dark:text-orange-300 border-orange-200 dark:border-orange-800',
    'Very High': 'text-rose-700 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-800'
  };

  const isVerified = pandal.verification_status === 'VERIFIED';
  const isCommunity = pandal.verification_status === 'COMMUNITY SUBMITTED';
  const isDemo = pandal.verification_status === 'DEMO';

  const defaultImage = 'https://images.unsplash.com/photo-1579618218290-24a26f63a728?auto=format&fit=crop&w=800&q=80';

  return (
    <div className={`bg-white dark:bg-[#1E1719] border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col group ${
      isInRoute ? 'border-[#800020] dark:border-[#D4AF37]/60 ring-1 ring-[#800020]/20' : 'border-stone-200 dark:border-stone-800'
    }`}>
      {/* Cover Image Container */}
      <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-stone-100 dark:bg-stone-900 cursor-pointer" onClick={() => onSelect(pandal)}>
        <img
          src={pandal.cover_image || defaultImage}
          alt={pandal.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />

        {/* Verification Status Pill & In Route Pill */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
          <div className="flex items-center gap-1.5">
            {isVerified && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-[#800020] text-[#FAF7F2] border border-[#D4AF37]/50 shadow-sm">
                <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                VERIFIED
              </span>
            )}
            {isCommunity && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-amber-600/90 text-white shadow-sm">
                <AlertCircle className="w-3.5 h-3.5" />
                COMMUNITY SUBMITTED
              </span>
            )}
            {isDemo && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-stone-700 text-stone-200">
                DEMO DATA
              </span>
            )}
          </div>

          {isInRoute && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-600 text-white shadow-sm border border-white/20">
              <Check className="w-3 h-3 text-white" />
              IN ROUTE
            </span>
          )}
        </div>

        {/* Save Bookmark Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleSave(pandal);
          }}
          aria-label={isSaved ? 'Remove from saved' : 'Save pandal'}
          className={`absolute top-3 right-3 p-2 rounded-full transition-transform active:scale-90 ${
            isSaved
              ? 'bg-[#800020] text-white shadow'
              : 'bg-black/40 text-white/90 hover:bg-black/60 backdrop-blur-xs'
          }`}
        >
          <Heart className={`w-4 h-4 ${isSaved ? 'fill-current text-[#D4AF37]' : ''}`} />
        </button>

        {/* Bottom image overlay metadata */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
          <div className="flex items-center gap-1.5 font-medium">
            <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="truncate max-w-[180px]">{pandal.neighbourhood || pandal.area_name}</span>
            {pandal.distance_km !== null && pandal.distance_km !== undefined && (
              <>
                <span className="text-white/60">·</span>
                <span className="text-[#D4AF37] font-semibold">{pandal.distance_km} km away</span>
              </>
            )}
          </div>

          {/* Rating */}
          <div className="flex items-center gap-1 bg-black/50 px-2 py-0.5 rounded backdrop-blur-xs">
            <Star className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
            <span className="font-bold text-white">{pandal.rating.toFixed(1)}</span>
            <span className="text-stone-300 text-[10px]">({pandal.rating_count})</span>
          </div>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Title */}
          <h3 
            onClick={() => onSelect(pandal)}
            className="font-heading font-bold text-base sm:text-lg text-[#1C1917] dark:text-[#F3EFE6] hover:text-[#800020] dark:hover:text-[#D4AF37] transition-colors cursor-pointer line-clamp-1"
          >
            {pandal.name}
          </h3>

          {/* Unboxed Metadata (Zero-Pill Discipline) */}
          <div className="flex items-center flex-wrap gap-x-2 gap-y-1 text-xs text-stone-500 dark:text-stone-400 mt-1">
            <span>{pandal.area_name || 'Kolkata'}</span>
            {pandal.established_year && (
              <>
                <span aria-hidden="true">·</span>
                <span>Est. {pandal.established_year}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>{pandal.estimated_visit_duration || 30} mins visit</span>
          </div>

          {/* Theme */}
          {pandal.theme && (
            <p className="mt-2 text-xs text-stone-700 dark:text-stone-300 line-clamp-2">
              <span className="font-semibold text-[#800020] dark:text-[#D4AF37]">Theme: </span>
              {pandal.theme}
            </p>
          )}

          {/* Amenities & Food Quick Pills */}
          <div className="mt-2.5 flex items-center flex-wrap gap-1.5 text-[10px]">
            {pandal.water_counter_info && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60">
                <Droplets className="w-3 h-3 text-emerald-600" />
                <span>Water Point</span>
              </span>
            )}
            {pandal.nearby_restaurants && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60 truncate max-w-[200px]" title={pandal.nearby_restaurants}>
                <Utensils className="w-3 h-3 text-amber-600 shrink-0" />
                <span className="truncate">{pandal.nearby_restaurants.split(',')[0]}</span>
              </span>
            )}
          </div>

          {/* Crowd & Metro status bar */}
          <div className="mt-3 pt-2.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs">
            {/* Crowd indicator */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-stone-400 dark:text-stone-500">Crowd:</span>
              <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${crowdColors[pandal.crowd_level] || crowdColors['Moderate']}`}>
                {pandal.crowd_level}
              </span>
            </div>

            {/* Metro */}
            {pandal.nearest_metro && (
              <div className="flex items-center gap-1 text-[11px] text-stone-600 dark:text-stone-400 max-w-[140px] truncate" title={`${pandal.nearest_metro} ${pandal.metro_walk_time ? `(${pandal.metro_walk_time})` : ''}`}>
                <Train className="w-3 h-3 text-blue-600 dark:text-blue-400 shrink-0" />
                <span className="truncate">{pandal.nearest_metro.split('(')[0]}</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Button Row */}
        <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800">
          <div className="grid grid-cols-3 gap-2">
            {/* View Details */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelect(pandal);
              }}
              className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-md bg-stone-100 dark:bg-stone-800 hover:bg-[#800020]/10 hover:text-[#800020] dark:hover:text-[#D4AF37] text-stone-700 dark:text-stone-200 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>View</span>
            </button>

            {/* Directions Modal / Link */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (onOpenDirections) {
                  onOpenDirections(pandal);
                } else {
                  window.open(getDirectionsUrl(), '_blank');
                }
              }}
              className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-md bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5 text-[#800020] dark:text-[#D4AF37]" />
              <span>Directions</span>
            </button>

            {/* Add / Cancel Route Toggle Button */}
            {isInRoute ? (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToRoute(pandal);
                }}
                title="Click to cancel and remove from route"
                className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-md text-xs font-bold transition-all cursor-pointer bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 shadow-2xs active:scale-95"
              >
                <X className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>Cancel</span>
              </button>
            ) : (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToRoute(pandal);
                }}
                title="Add to route planner"
                className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-md text-xs font-bold transition-all cursor-pointer bg-[#800020]/10 dark:bg-[#800020]/30 text-[#800020] dark:text-[#D4AF37] hover:bg-[#800020] hover:text-white active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Route</span>
              </button>
            )}
          </div>

          {/* Go to Route Button - Prominent callout when added */}
          {isInRoute && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (onOpenRoute) onOpenRoute();
              }}
              className="mt-2.5 w-full py-2 px-3 rounded-lg bg-gradient-to-r from-[#800020] to-[#A51D24] hover:from-[#660018] hover:to-[#800020] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-[0.98] border border-[#D4AF37]/40"
            >
              <Route className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>In Route! Go to Route Plan →</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
