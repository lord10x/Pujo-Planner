import React from 'react';
import { X, Navigation, Train, Footprints, Car, MapPin, Utensils, Droplets, ShieldCheck, Route, ExternalLink } from 'lucide-react';
import { Pandal } from '../types';

interface DirectionsModalProps {
  pandal: Pandal | null;
  onClose: () => void;
  onAddToRoute: (pandal: Pandal) => void;
  isInRoute: boolean;
  onOpenRoute?: () => void;
}

export const DirectionsModal: React.FC<DirectionsModalProps> = ({
  pandal,
  onClose,
  onAddToRoute,
  isInRoute,
  onOpenRoute,
}) => {
  if (!pandal) return null;

  const lat = pandal.latitude;
  const lng = pandal.longitude;
  const queryParam = lat && lng ? `${lat},${lng}` : encodeURIComponent(`${pandal.name} ${pandal.address || 'Kolkata'}`);

  const walkingUrl = `https://www.google.com/maps/dir/?api=1&destination=${queryParam}&travelmode=walking`;
  const transitUrl = `https://www.google.com/maps/dir/?api=1&destination=${queryParam}&travelmode=transit`;
  const drivingUrl = `https://www.google.com/maps/dir/?api=1&destination=${queryParam}&travelmode=driving`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1A1215] w-full max-w-xl rounded-2xl shadow-2xl border border-[#D4AF37]/40 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#800020] via-[#940026] to-[#70001C] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-[#D4AF37] border border-[#D4AF37]/30 shrink-0">
              <Navigation className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-mono font-bold tracking-widest text-[#D4AF37] uppercase">
                Transit & Arrival Guide
              </span>
              <h3 className="font-heading font-extrabold text-lg text-white truncate">
                {pandal.name}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close directions"
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 text-xs">
          {/* Location & Address */}
          <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-stone-900 dark:text-stone-100">
              <MapPin className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
              <span>Exact Address & Locality</span>
            </div>
            <p className="text-stone-600 dark:text-stone-300 leading-relaxed pl-5">
              {pandal.address || pandal.neighbourhood || 'Kolkata, West Bengal'}
            </p>
          </div>

          {/* Nearest Metro Station */}
          <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/60 dark:bg-blue-950/30 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-blue-950 dark:text-blue-200 text-sm">
                <Train className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Nearest Metro Station</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-bold">
                Recommended
              </span>
            </div>
            <p className="text-blue-900 dark:text-blue-100 font-semibold text-xs">
              {pandal.nearest_metro || 'Nearest station listed in route planner'}
            </p>
            {pandal.metro_walk_time && (
              <p className="text-blue-800 dark:text-blue-300 text-[11px] flex items-center gap-1">
                <Footprints className="w-3.5 h-3.5" />
                <span>{pandal.metro_walk_time}</span>
              </p>
            )}
            <p className="text-blue-700 dark:text-blue-400 text-[11px]">
              Tip: During peak Puja evening hours (6 PM - 2 AM), Metro is the fastest way to avoid surface traffic blockades.
            </p>
          </div>

          {/* Approach & Entry Tip */}
          {pandal.entry_approach_tip && (
            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 space-y-1">
              <span className="font-bold text-amber-900 dark:text-amber-200 text-xs">
                Pedestrian Flow & Entry Route:
              </span>
              <p className="text-amber-800 dark:text-amber-300 text-[11px] leading-relaxed">
                {pandal.entry_approach_tip}
              </p>
            </div>
          )}

          {/* Nearby Amenities (Water & Restroom) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-emerald-900 dark:text-emerald-200 text-xs">
                <Droplets className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Drinking Water Counter</span>
              </div>
              <p className="text-emerald-800 dark:text-emerald-300 text-[11px]">
                {pandal.water_counter_info || 'Free KMC drinking water kiosk near entry gate'}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/60 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-purple-900 dark:text-purple-200 text-xs">
                <ShieldCheck className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span>Police & First Aid Desk</span>
              </div>
              <p className="text-purple-800 dark:text-purple-300 text-[11px]">
                {pandal.police_booth || pandal.medical_aid_info || 'Kolkata Police assistance kiosk at main barricade'}
              </p>
            </div>
          </div>

          {/* Nearby Famous Food Joints */}
          {pandal.nearby_restaurants && (
            <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-2">
              <div className="flex items-center gap-1.5 font-bold text-stone-900 dark:text-stone-100 text-xs">
                <Utensils className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
                <span>Legendary Food & Eateries Nearby</span>
              </div>
              <p className="text-stone-700 dark:text-stone-300 text-[11px] leading-relaxed">
                {pandal.nearby_restaurants}
              </p>
            </div>
          )}

          {/* One-Click Google Maps Nav Buttons */}
          <div className="space-y-2 pt-2">
            <span className="font-bold text-stone-700 dark:text-stone-300 text-[11px] uppercase tracking-wider block">
              Open Navigation in Google Maps:
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <a
                href={walkingUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-transform active:scale-95"
              >
                <Footprints className="w-4 h-4" />
                <span>Walking Route</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>

              <a
                href={transitUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-transform active:scale-95"
              >
                <Train className="w-4 h-4" />
                <span>Metro / Bus</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>

              <a
                href={drivingUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#800020] hover:bg-[#660018] text-white font-bold text-xs shadow-xs transition-transform active:scale-95"
              >
                <Car className="w-4 h-4 text-[#D4AF37]" />
                <span>Cab / Drive</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-stone-100 dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={() => onAddToRoute(pandal)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isInRoute
                ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800'
                : 'bg-[#800020] text-white hover:bg-[#660018] shadow-xs'
            }`}
          >
            <Route className="w-4 h-4 text-[#D4AF37]" />
            <span>{isInRoute ? 'Cancel from Route' : '+ Add to Itinerary'}</span>
          </button>

          {isInRoute && onOpenRoute && (
            <button
              onClick={() => {
                onClose();
                onOpenRoute();
              }}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-white dark:bg-stone-800 border border-[#D4AF37] text-[#800020] dark:text-[#E5C158] hover:bg-[#800020] hover:text-white text-xs font-bold transition-all cursor-pointer"
            >
              <span>View Route Plan →</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
