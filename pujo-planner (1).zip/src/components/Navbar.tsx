import React, { useState } from 'react';
import { Compass, Map, Route, Bookmark, PlusCircle, Moon, Sun, ShieldCheck, Menu, X, Flame, Phone } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenAddModal: () => void;
  onOpenSafetyModal: () => void;
  savedCount: number;
  routeCount?: number;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  deferredInstallPrompt: any;
  onInstallPwa: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenAddModal,
  onOpenSafetyModal,
  savedCount,
  routeCount = 0,
  darkMode,
  setDarkMode,
  deferredInstallPrompt,
  onInstallPwa
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'explore', label: 'Explore Pandals', icon: Compass },
    { id: 'map', label: 'Interactive Map', icon: Map },
    { id: 'routes', label: 'Plan My Puja', icon: Route, badge: routeCount > 0 ? routeCount : null },
    { id: 'areas', label: 'Area Explorer', icon: Flame },
    { id: 'mypuja', label: 'My Puja', icon: Bookmark, badge: savedCount > 0 ? savedCount : null },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/95 dark:bg-[#150F11]/95 backdrop-blur-md border-b border-[#D4AF37]/20 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Brand Logo */}
          <div 
            onClick={() => { setCurrentTab('home'); setMobileMenuOpen(false); }}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-gradient-to-br from-[#800020] via-[#A51D24] to-[#600018] flex items-center justify-center shadow-md border border-[#D4AF37]/40 group-hover:scale-105 transition-transform">
              <span className="text-xl font-serif text-[#D4AF37] font-bold">পূ</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-heading font-extrabold text-xl sm:text-2xl tracking-wider text-[#800020] dark:text-[#E5C158]">
                  PUJO PLANNER
                </span>
                <span className="hidden lg:inline text-[10px] tracking-widest uppercase font-semibold text-[#B8860B] dark:text-[#D4AF37]/80">
                  KOLKATA
                </span>
              </div>
              <p className="text-[11px] text-[#78716C] dark:text-[#A8A29E] tracking-tight">
                All Pandals · Real Directory · Interactive Map
              </p>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 text-sm font-medium transition-colors relative cursor-pointer ${
                    isActive
                      ? 'text-[#800020] dark:text-[#E5C158] font-bold'
                      : 'text-[#44403C] dark:text-[#D6D3D1] hover:text-[#800020] dark:hover:text-[#E5C158]'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#800020] dark:text-[#E5C158]' : 'text-stone-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="ml-1 text-[11px] font-bold px-1.5 py-0.2 rounded-full bg-[#800020] text-white">
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-[#800020] dark:bg-[#D4AF37]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons: Add Pandal, Theme Toggle, Install PWA */}
          <div className="hidden sm:flex items-center gap-3">
            {deferredInstallPrompt && (
              <button
                onClick={onInstallPwa}
                className="px-3 py-1.5 text-xs font-semibold rounded-md border border-[#D4AF37] text-[#800020] dark:text-[#E5C158] hover:bg-[#D4AF37]/10 transition-colors"
              >
                Install App
              </button>
            )}

            <button
              onClick={() => setDarkMode(!darkMode)}
              aria-label="Toggle theme"
              className="p-2 rounded-lg text-stone-600 dark:text-stone-300 hover:bg-stone-200/50 dark:hover:bg-stone-800 transition-colors"
            >
              {darkMode ? <Sun className="w-5 h-5 text-[#D4AF37]" /> : <Moon className="w-5 h-5 text-[#800020]" />}
            </button>

            {/* Emergency Helplines Button */}
            <button
              onClick={onOpenSafetyModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900 border border-rose-200 dark:border-rose-800 transition-transform active:scale-95 cursor-pointer shadow-2xs"
              title="Kolkata Emergency Safety Helplines (Police, Medical, Fire)"
            >
              <Phone className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
              <span className="hidden lg:inline">Safety Numbers</span>
              <span className="lg:hidden">Safety</span>
            </button>

            <button
              onClick={onOpenAddModal}
              className="flex items-center gap-1.5 px-4 py-2 text-xs uppercase tracking-wider font-bold text-white bg-gradient-to-r from-[#800020] to-[#A51D24] hover:from-[#6B001B] hover:to-[#8A161E] rounded-md shadow-sm border border-[#D4AF37]/40 hover:shadow transition-all active:scale-95 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4 text-[#D4AF37]" />
              <span>+ Add Missing Pandal</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={onOpenSafetyModal}
              className="p-2 text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 rounded-lg"
              aria-label="Open emergency safety helplines"
              title="Safety helplines"
            >
              <Phone className="w-4 h-4" />
            </button>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 text-stone-600 dark:text-stone-300"
              aria-label="Toggle theme"
            >
              {darkMode ? <Sun className="w-5 h-5 text-[#D4AF37]" /> : <Moon className="w-5 h-5 text-[#800020]" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#800020] dark:text-[#E5C158]"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#D4AF37]/20 bg-[#FAF7F2] dark:bg-[#150F11] px-4 pt-2 pb-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-[#800020]/10 text-[#800020] dark:text-[#E5C158] font-bold'
                    : 'text-[#44403C] dark:text-[#D6D3D1] hover:bg-stone-200/40 dark:hover:bg-stone-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-[#800020] text-white font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-2 space-y-2">
            <button
              onClick={() => {
                onOpenSafetyModal();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 rounded-md border border-rose-200 dark:border-rose-800"
            >
              <Phone className="w-4 h-4 text-rose-600" />
              <span>Emergency & Safety Helplines (24x7)</span>
            </button>

            <button
              onClick={() => {
                onOpenAddModal();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 text-xs uppercase tracking-wider font-bold text-white bg-gradient-to-r from-[#800020] to-[#A51D24] rounded-md shadow"
            >
              <PlusCircle className="w-4 h-4 text-[#D4AF37]" />
              <span>+ Add Missing Pandal</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
