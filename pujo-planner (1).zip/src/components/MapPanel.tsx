import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import { Pandal } from '../types';
import { Navigation, Plus, Check, Star, ShieldCheck, Crosshair, ZoomIn, ZoomOut, X, Route, Droplets, Train, Utensils } from 'lucide-react';

interface MapPanelProps {
  pandals: Pandal[];
  selectedPandal: Pandal | null;
  onSelectPandal: (pandal: Pandal) => void;
  userLocation: { lat: number; lng: number } | null;
  onRequestLocation: () => void;
  onAddToRoute: (pandal: Pandal) => void;
  routePandalIds?: number[];
  darkMode?: boolean;
  onOpenRoute?: () => void;
  onOpenDirections?: (pandal: Pandal) => void;
}

export const MapPanel: React.FC<MapPanelProps> = ({
  pandals,
  selectedPandal,
  onSelectPandal,
  userLocation,
  onRequestLocation,
  onAddToRoute,
  routePandalIds = [],
  darkMode = false,
  onOpenRoute,
  onOpenDirections,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<{ [id: number]: maplibregl.Marker }>({});
  const userMarkerRef = useRef<maplibregl.Marker | null>(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  // Kolkata central coordinates (Esplanade / BBD Bagh)
  const KOLKATA_CENTER: [number, number] = [88.3639, 22.5726];

  // Guaranteed CORS-friendly, zero-failure raster tile styles (Carto Voyager for light, Carto Dark for dark mode)
  const getRasterStyle = (isDark: boolean): maplibregl.StyleSpecification => {
    return {
      version: 8,
      sources: {
        'carto-tiles': {
          type: 'raster',
          tiles: [
            isDark
              ? 'https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png'
              : 'https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png',
          ],
          tileSize: 256,
          attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        },
      },
      layers: [
        {
          id: 'carto-basemap',
          type: 'raster',
          source: 'carto-tiles',
          minzoom: 0,
          maxzoom: 19,
        },
      ],
    };
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    try {
      const map = new maplibregl.Map({
        container: mapContainerRef.current,
        style: getRasterStyle(darkMode),
        center: selectedPandal?.longitude && selectedPandal?.latitude 
          ? [selectedPandal.longitude, selectedPandal.latitude] 
          : KOLKATA_CENTER,
        zoom: selectedPandal ? 14 : 12,
        attributionControl: false,
      });

      map.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-right');

      map.on('load', () => {
        setMapLoaded(true);
        map.resize();
      });

      // Force canvas resizing to prevent black/blank screens in flex layouts
      const resizeTimer1 = setTimeout(() => {
        if (mapRef.current) mapRef.current.resize();
      }, 100);

      const resizeTimer2 = setTimeout(() => {
        if (mapRef.current) mapRef.current.resize();
      }, 500);

      const handleResize = () => {
        if (mapRef.current) mapRef.current.resize();
      };
      window.addEventListener('resize', handleResize);

      mapRef.current = map;

      return () => {
        clearTimeout(resizeTimer1);
        clearTimeout(resizeTimer2);
        window.removeEventListener('resize', handleResize);
        if (mapRef.current) {
          mapRef.current.remove();
          mapRef.current = null;
        }
      };
    } catch (err) {
      console.error('Failed to initialize map:', err);
    }
  }, []);

  // Update style when dark mode toggles without destroying map instance
  useEffect(() => {
    if (mapRef.current && mapLoaded) {
      mapRef.current.setStyle(getRasterStyle(darkMode));
      // Re-trigger resize after style load
      setTimeout(() => {
        if (mapRef.current) mapRef.current.resize();
      }, 150);
    }
  }, [darkMode, mapLoaded]);

  // Update markers when pandals, route, or selection changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    // Clear previous markers
    Object.values(markersRef.current).forEach((m) => m.remove());
    markersRef.current = {};

    pandals.forEach((p) => {
      if (!p.latitude || !p.longitude) return;

      const isSelected = selectedPandal?.id === p.id;
      const isInRoute = routePandalIds.includes(p.id);

      const el = document.createElement('div');
      el.className = 'pandal-map-marker cursor-pointer transition-transform duration-200 select-none';
      el.style.width = isSelected ? '40px' : '32px';
      el.style.height = isSelected ? '40px' : '32px';

      const bgColor = isInRoute ? '#059669' : isSelected ? '#D4AF37' : '#800020';
      const borderColor = isSelected ? '#FFFFFF' : '#FAF7F2';
      const scale = isSelected ? 'scale(1.2)' : 'scale(1)';

      el.innerHTML = `
        <div style="
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background: ${bgColor};
          border: 2.5px solid ${borderColor};
          box-shadow: 0 4px 12px rgba(0,0,0,0.4);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: 800;
          font-size: ${isSelected ? '15px' : '13px'};
          transform: ${scale};
          transition: transform 0.2s ease, background 0.2s ease;
        ">
          ${isInRoute ? '✓' : 'পূ'}
        </div>
      `;

      el.addEventListener('click', (e) => {
        e.stopPropagation();
        onSelectPandal(p);
      });

      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([p.longitude, p.latitude])
        .addTo(map);

      markersRef.current[p.id] = marker;
    });

    // Draw route polyline if 2 or more stops in route
    const updateRouteLine = () => {
      const routePoints = pandals
        .filter((p) => routePandalIds.includes(p.id) && p.latitude && p.longitude)
        .map((p) => [p.longitude!, p.latitude!]);

      if (map.getSource('route-line')) {
        (map.getSource('route-line') as maplibregl.GeoJSONSource).setData({
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'LineString',
            coordinates: routePoints,
          },
        });
      } else if (routePoints.length >= 2) {
        map.addSource('route-line', {
          type: 'geojson',
          data: {
            type: 'Feature',
            properties: {},
            geometry: {
              type: 'LineString',
              coordinates: routePoints,
            },
          },
        });

        map.addLayer({
          id: 'route-line-layer',
          type: 'line',
          source: 'route-line',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#D4AF37',
            'line-width': 4,
            'line-dasharray': [2, 2],
          },
        });
      }
    };

    updateRouteLine();
  }, [pandals, mapLoaded, selectedPandal, routePandalIds]);

  // Pan to selected pandal smoothly
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedPandal || !selectedPandal.latitude || !selectedPandal.longitude) return;

    map.flyTo({
      center: [selectedPandal.longitude, selectedPandal.latitude],
      zoom: 15,
      essential: true,
      speed: 1.2,
    });
  }, [selectedPandal]);

  // Handle user location marker
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    if (userLocation) {
      if (!userMarkerRef.current) {
        const el = document.createElement('div');
        el.className = 'user-location-marker';
        el.innerHTML = `
          <div style="
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #2563EB;
            border: 3px solid white;
            box-shadow: 0 0 10px rgba(37, 99, 235, 0.7);
            animation: pulse 2s infinite;
          "></div>
        `;

        userMarkerRef.current = new maplibregl.Marker({ element: el })
          .setLngLat([userLocation.lng, userLocation.lat])
          .addTo(map);
      } else {
        userMarkerRef.current.setLngLat([userLocation.lng, userLocation.lat]);
      }
    }
  }, [userLocation, mapLoaded]);

  const handleZoomIn = () => mapRef.current?.zoomIn();
  const handleZoomOut = () => mapRef.current?.zoomOut();

  const handleRecenter = () => {
    if (!mapRef.current) return;
    if (userLocation) {
      mapRef.current.flyTo({ center: [userLocation.lng, userLocation.lat], zoom: 14 });
    } else {
      mapRef.current.flyTo({ center: KOLKATA_CENTER, zoom: 12 });
    }
  };

  const crowdColors: Record<string, string> = {
    'Low': 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
    'Moderate': 'text-amber-700 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-800',
    'High': 'text-orange-700 bg-orange-50 dark:bg-orange-950/40 dark:text-orange-300 border-orange-200 dark:border-orange-800',
    'Very High': 'text-rose-700 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-800',
  };

  return (
    <div className="relative w-full h-full min-h-[480px] rounded-xl overflow-hidden border border-stone-200 dark:border-stone-800 shadow-sm bg-[#F3EFE6] dark:bg-[#1A1215]">
      {/* Map Container */}
      <div ref={mapContainerRef} className="w-full h-full min-h-[480px]" />

      {/* Floating Map Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        <button
          onClick={handleZoomIn}
          aria-label="Zoom in"
          className="p-2.5 rounded-xl bg-white/95 dark:bg-stone-800/95 shadow-md text-stone-700 dark:text-stone-200 hover:bg-white dark:hover:bg-stone-800 transition-transform active:scale-95 cursor-pointer border border-stone-200 dark:border-stone-700"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={handleZoomOut}
          aria-label="Zoom out"
          className="p-2.5 rounded-xl bg-white/95 dark:bg-stone-800/95 shadow-md text-stone-700 dark:text-stone-200 hover:bg-white dark:hover:bg-stone-800 transition-transform active:scale-95 cursor-pointer border border-stone-200 dark:border-stone-700"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={() => {
            if (!userLocation) onRequestLocation();
            handleRecenter();
          }}
          title={userLocation ? 'Fly to your location' : 'Locate near me'}
          className="p-2.5 rounded-xl bg-white/95 dark:bg-stone-800/95 shadow-md text-[#800020] dark:text-[#D4AF37] hover:bg-white dark:hover:bg-stone-800 transition-transform active:scale-95 cursor-pointer border border-stone-200 dark:border-stone-700"
        >
          <Crosshair className="w-4 h-4" />
        </button>
      </div>

      {/* Map Stats Badge */}
      <div className="absolute top-4 left-4 z-10 bg-white/95 dark:bg-stone-900/95 backdrop-blur-xs px-3.5 py-1.5 rounded-xl shadow-md border border-stone-200/80 dark:border-stone-800 text-xs font-medium text-stone-700 dark:text-stone-300 flex items-center gap-2">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
        <span><strong className="text-[#800020] dark:text-[#E5C158]">{pandals.length}</strong> Pandals on Live Map</span>
      </div>

      {/* Selected Pandal Floating Bottom Card */}
      {selectedPandal && (
        <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-[420px] z-10 bg-white/95 dark:bg-[#1C1517]/95 p-4 rounded-2xl shadow-2xl border border-[#D4AF37]/40 backdrop-blur-md animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400">
                <span className="font-semibold text-stone-700 dark:text-stone-300">{selectedPandal.neighbourhood || selectedPandal.area_name}</span>
                {selectedPandal.verification_status === 'VERIFIED' && (
                  <>
                    <span>·</span>
                    <span className="text-[#800020] dark:text-[#D4AF37] font-semibold flex items-center gap-0.5">
                      <ShieldCheck className="w-3 h-3" /> Verified
                    </span>
                  </>
                )}
              </div>
              <h4 className="font-heading font-extrabold text-base sm:text-lg text-stone-900 dark:text-stone-100 line-clamp-1 mt-0.5">
                {selectedPandal.name}
              </h4>
            </div>

            <button
              onClick={() => onSelectPandal(selectedPandal)}
              className="text-xs text-[#800020] dark:text-[#D4AF37] font-bold hover:underline shrink-0"
            >
              Full Details →
            </button>
          </div>

          {selectedPandal.theme && (
            <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-1 mt-1">
              <span className="font-semibold text-[#800020] dark:text-[#D4AF37]">Theme:</span> {selectedPandal.theme}
            </p>
          )}

          {/* Quick Metro & Amenities Preview */}
          <div className="mt-2 flex items-center flex-wrap gap-2 text-[11px] text-stone-600 dark:text-stone-400">
            {selectedPandal.nearest_metro && (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                <Train className="w-3 h-3 text-blue-600 dark:text-blue-400 shrink-0" />
                <span className="truncate max-w-[150px]">{selectedPandal.nearest_metro.split('(')[0]}</span>
              </span>
            )}
            {selectedPandal.water_counter_info && (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300">
                <Droplets className="w-3 h-3 text-emerald-600" />
                <span>Water Counter</span>
              </span>
            )}
            <span className={`px-2 py-0.5 rounded-md font-semibold border ${crowdColors[selectedPandal.crowd_level] || crowdColors['Moderate']}`}>
              Crowd: {selectedPandal.crowd_level}
            </span>
          </div>

          {/* Action Button Row */}
          <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-stone-100 dark:border-stone-800 gap-2">
            {/* Directions Modal Button */}
            <button
              onClick={() => onOpenDirections && onOpenDirections(selectedPandal)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-bold transition-all cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5 text-[#800020] dark:text-[#D4AF37]" />
              <span>Directions</span>
            </button>

            {/* Cancel or Add to Route */}
            {routePandalIds.includes(selectedPandal.id) ? (
              <button
                onClick={() => onAddToRoute(selectedPandal)}
                title="Click to cancel and remove from route"
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 transition-all cursor-pointer shadow-xs active:scale-95"
              >
                <X className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>Cancel</span>
              </button>
            ) : (
              <button
                onClick={() => onAddToRoute(selectedPandal)}
                title="Add to route planner"
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#800020] text-white hover:bg-[#660018] transition-all cursor-pointer shadow-xs active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Route</span>
              </button>
            )}
          </div>

          {/* Go to Route Plan Banner */}
          {routePandalIds.includes(selectedPandal.id) && onOpenRoute && (
            <button
              onClick={onOpenRoute}
              className="mt-2.5 w-full py-2 px-3 rounded-xl bg-gradient-to-r from-[#800020] to-[#A51D24] hover:from-[#660018] hover:to-[#800020] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-[0.98] border border-[#D4AF37]/40"
            >
              <Route className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>In Route! Go to Route Plan →</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
