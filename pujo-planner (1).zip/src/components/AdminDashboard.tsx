import React, { useState, useEffect } from 'react';
import {
  Database, ShieldCheck, Layers, Upload, Download, Search, Plus,
  Trash2, Edit, CheckCircle2, XCircle, AlertTriangle, RefreshCw,
  FileText, Activity, Lock, Unlock, ArrowRight
} from 'lucide-react';
import { DatabaseHealth, Pandal } from '../types';
import { api } from '../services/api';

interface AdminDashboardProps {
  onPandalUpdated: () => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onPandalUpdated,
  addToast,
}) => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('pujo_admin_session') === 'true';
  });
  const [adminPass, setAdminPass] = useState('');
  const [activeAdminTab, setActiveAdminTab] = useState<'health' | 'pandals' | 'submissions' | 'duplicates' | 'import' | 'export' | 'performance'>('health');

  const [healthData, setHealthData] = useState<DatabaseHealth | null>(null);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [pandalsList, setPandalsList] = useState<Pandal[]>([]);
  const [adminSearch, setAdminSearch] = useState('');
  const [loading, setLoading] = useState(false);

  // Edit / Add Pandal modal in Admin
  const [editingPandal, setEditingPandal] = useState<any | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  // Import state
  const [importJsonText, setImportJsonText] = useState('');
  const [importPreview, setImportPreview] = useState<any | null>(null);
  const [importing, setImporting] = useState(false);

  // Duplicate detection state
  const [dupCandidates, setDupCandidates] = useState<any[]>([]);

  const loadHealth = async () => {
    try {
      setLoading(true);
      const data = await api.getAdminHealth();
      setHealthData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const loadSubmissions = async () => {
    try {
      const data = await api.getAdminSubmissions();
      setSubmissions(data);
    } catch (e) {
      console.error(e);
    }
  };

  const loadPandals = async () => {
    try {
      const res = await api.getPandals({ limit: 100, search: adminSearch, status: 'ALL', verification: 'ALL' });
      setPandalsList(res.data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (isAdminAuthenticated) {
      loadHealth();
      loadSubmissions();
      loadPandals();
    }
  }, [isAdminAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Default editorial admin password for development/demo (can be overridden by ADMIN_PASSWORD)
    if (adminPass === 'kolkata2026' || adminPass === 'admin') {
      setIsAdminAuthenticated(true);
      localStorage.setItem('pujo_admin_session', 'true');
      addToast('Editorial Admin session unlocked.', 'success');
    } else {
      addToast('Invalid admin credentials. Use "kolkata2026" or "admin"', 'error');
    }
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('pujo_admin_session');
    addToast('Admin logged out.', 'info');
  };

  const handleSubmissionAction = async (id: number, action: string) => {
    try {
      await api.handleSubmissionAction(id, action);
      addToast(`Submission ${action}d successfully.`, 'success');
      loadSubmissions();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Action failed', 'error');
    }
  };

  const handleVerifyPandal = async (id: number, status: string) => {
    try {
      await api.verifyPandal(id, status);
      addToast(`Status updated to ${status}`, 'success');
      loadPandals();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Verification update failed', 'error');
    }
  };

  const handleDeletePandal = async (id: number) => {
    if (!window.confirm('Are you sure you want to permanently delete this pandal record?')) return;
    try {
      await api.deleteAdminPandal(id);
      addToast('Pandal record removed.', 'info');
      loadPandals();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Delete failed', 'error');
    }
  };

  const handleSavePandal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPandal) return;
    try {
      await api.saveAdminPandal(editingPandal, editingPandal.id);
      addToast('Pandal record saved successfully!', 'success');
      setIsEditing(false);
      setEditingPandal(null);
      loadPandals();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Failed to save pandal', 'error');
    }
  };

  const handleImportPreview = async () => {
    try {
      const items = JSON.parse(importJsonText);
      const res = await api.importRecords(items, false);
      setImportPreview(res);
      addToast(`Preview ready: ${res.valid} valid records detected.`, 'info');
    } catch {
      addToast('Invalid JSON format. Please provide an array of pandal objects.', 'error');
    }
  };

  const handleCommitImport = async () => {
    try {
      setImporting(true);
      const items = JSON.parse(importJsonText);
      const res = await api.importRecords(items, true);
      addToast(`Successfully imported ${res.valid} records to database!`, 'success');
      setImportPreview(null);
      setImportJsonText('');
      loadPandals();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Import failed', 'error');
    } finally {
      setImporting(false);
    }
  };

  const handleGeneratePerfData = async (count: number) => {
    try {
      setLoading(true);
      await api.generatePerfRecords(count);
      addToast(`Generated ${count} test performance records with DEMO DATA tag.`, 'success');
      loadPandals();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Failed to generate test records', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleClearPerfData = async () => {
    try {
      setLoading(true);
      const res = await api.clearPerfRecords();
      addToast(res.message, 'success');
      loadPandals();
      loadHealth();
      onPandalUpdated();
    } catch (e: any) {
      addToast(e.message || 'Failed to clear test data', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (!isAdminAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-[#1E1719] rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xl text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-[#800020]/10 text-[#800020] dark:text-[#E5C158] flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h2 className="font-heading font-extrabold text-2xl text-stone-900 dark:text-stone-100">
          Editorial & Admin Desk
        </h2>
        <p className="text-xs text-stone-500">
          Pujo Planner Directory Management, Verification Pipeline & Database Health.
        </p>

        <form onSubmit={handleLogin} className="space-y-3 pt-2 text-left">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-stone-400 mb-1">
              Admin Access Key
            </label>
            <input
              type="password"
              placeholder="Enter admin password (hint: kolkata2026)"
              value={adminPass}
              onChange={(e) => setAdminPass(e.target.value)}
              className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2.5 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white hover:bg-[#660018] rounded-md shadow cursor-pointer"
          >
            Unlock Admin Console
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      {/* Admin Top Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#800020] text-white">
              ADMIN CONTROL PANEL
            </span>
            <span className="text-xs text-stone-400">PostgreSQL / Supabase Compatible DDL</span>
          </div>
          <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
            Pujo Planner Command Center
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => { loadHealth(); loadSubmissions(); loadPandals(); }}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-200 rounded-md transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-md transition-colors cursor-pointer"
          >
            <Unlock className="w-3.5 h-3.5" />
            <span>Lock Session</span>
          </button>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-stone-200 dark:border-stone-800 text-xs font-semibold">
        {[
          { id: 'health', label: 'Database Health', icon: Activity },
          { id: 'pandals', label: 'Pandals Management', icon: Layers },
          { id: 'submissions', label: `Community Submissions (${submissions.filter(s => s.status === 'COMMUNITY SUBMITTED').length})`, icon: ShieldCheck },
          { id: 'import', label: 'Bulk Import', icon: Upload },
          { id: 'export', label: 'Bulk Export & SQL', icon: Download },
          { id: 'performance', label: 'Scale Stress Test (1k–5k)', icon: Database },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeAdminTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'bg-[#800020] text-white shadow-xs'
                  : 'bg-white dark:bg-[#1E1719] text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. HEALTH TAB */}
      {activeAdminTab === 'health' && healthData && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 text-xs">
            <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
              <span className="text-stone-400 font-bold uppercase tracking-wider">Total Records</span>
              <p className="font-heading font-extrabold text-2xl text-stone-900 dark:text-stone-100 mt-1">
                {healthData.overview.total}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
              <span className="text-stone-400 font-bold uppercase tracking-wider">Verified Records</span>
              <p className="font-heading font-extrabold text-2xl text-emerald-600 mt-1">
                {healthData.overview.verified}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
              <span className="text-stone-400 font-bold uppercase tracking-wider">Community Submissions</span>
              <p className="font-heading font-extrabold text-2xl text-amber-600 mt-1">
                {healthData.overview.community}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
              <span className="text-stone-400 font-bold uppercase tracking-wider">Missing Coords</span>
              <p className="font-heading font-extrabold text-2xl text-rose-600 mt-1">
                {healthData.overview.missing_coords}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800">
              <span className="text-stone-400 font-bold uppercase tracking-wider">Pending Issues</span>
              <p className="font-heading font-extrabold text-2xl text-purple-600 mt-1">
                {healthData.overview.reported_issues}
              </p>
            </div>
          </div>

          {/* Area Breakdown Table */}
          <div className="bg-white dark:bg-[#1E1719] rounded-xl border border-stone-200 dark:border-stone-800 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-stone-200 dark:border-stone-800">
              <h3 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100">
                Directory Health by Area
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 dark:bg-stone-900 text-stone-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="p-3">Area Name</th>
                    <th className="p-3">Region</th>
                    <th className="p-3">Total Pandals</th>
                    <th className="p-3">Verified</th>
                    <th className="p-3">Community Submitted</th>
                    <th className="p-3">Missing Coords</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                  {healthData.area_breakdown.map((row) => (
                    <tr key={row.id} className="hover:bg-stone-50 dark:hover:bg-stone-900/50">
                      <td className="p-3 font-semibold text-stone-900 dark:text-stone-100">{row.name}</td>
                      <td className="p-3 text-stone-500">{row.region}</td>
                      <td className="p-3 font-bold">{row.total}</td>
                      <td className="p-3 text-emerald-600 font-semibold">{row.verified}</td>
                      <td className="p-3 text-amber-600">{row.community}</td>
                      <td className="p-3 text-rose-500">{row.missing_coords}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. PANDALS LIST TAB */}
      {activeAdminTab === 'pandals' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
              <input
                type="text"
                placeholder="Search pandals by name..."
                value={adminSearch}
                onChange={(e) => setAdminSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadPandals()}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>

            <button
              onClick={() => {
                setEditingPandal({
                  name: '',
                  official_name: '',
                  area_id: 1,
                  neighbourhood: '',
                  address: '',
                  latitude: 22.5726,
                  longitude: 88.3639,
                  theme: '',
                  verification_status: 'VERIFIED',
                  status: 'Active',
                });
                setIsEditing(true);
              }}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded-md cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Pandal</span>
            </button>
          </div>

          <div className="bg-white dark:bg-[#1E1719] rounded-xl border border-stone-200 dark:border-stone-800 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 dark:bg-stone-900 text-stone-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="p-3">Name</th>
                    <th className="p-3">Area</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Verification</th>
                    <th className="p-3">Rating</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                  {pandalsList.map((p) => (
                    <tr key={p.id} className="hover:bg-stone-50 dark:hover:bg-stone-900/50">
                      <td className="p-3 font-semibold text-stone-900 dark:text-stone-100">
                        {p.name}
                        {p.neighbourhood && <span className="block text-[11px] text-stone-400 font-normal">{p.neighbourhood}</span>}
                      </td>
                      <td className="p-3 text-stone-600 dark:text-stone-400">{p.area_name}</td>
                      <td className="p-3 text-stone-600">{p.status}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          p.verification_status === 'VERIFIED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                          p.verification_status === 'COMMUNITY SUBMITTED' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' :
                          'bg-stone-100 text-stone-800'
                        }`}>
                          {p.verification_status}
                        </span>
                      </td>
                      <td className="p-3 font-semibold">★ {p.rating.toFixed(1)}</td>
                      <td className="p-3 text-right space-x-1">
                        {p.verification_status !== 'VERIFIED' && (
                          <button
                            onClick={() => handleVerifyPandal(p.id, 'VERIFIED')}
                            className="px-2 py-1 text-[11px] font-bold bg-emerald-600 text-white rounded cursor-pointer"
                          >
                            Verify
                          </button>
                        )}
                        <button
                          onClick={() => {
                            setEditingPandal(p);
                            setIsEditing(true);
                          }}
                          className="p-1 hover:bg-stone-200 dark:hover:bg-stone-800 rounded text-stone-600 dark:text-stone-300"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeletePandal(p.id)}
                          className="p-1 hover:bg-rose-50 text-rose-600 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. SUBMISSIONS TAB */}
      {activeAdminTab === 'submissions' && (
        <div className="space-y-4">
          <h3 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100">
            Pending Community Submissions
          </h3>
          {submissions.length === 0 ? (
            <p className="text-xs text-stone-500">No submissions currently awaiting review.</p>
          ) : (
            <div className="space-y-3">
              {submissions.map((sub) => (
                <div
                  key={sub.id}
                  className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
                        {sub.pandal_name}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                        {sub.status}
                      </span>
                    </div>
                    <p className="text-xs text-stone-500">
                      {sub.neighbourhood} · {sub.address || 'Address unverified'}
                    </p>
                    {sub.theme && (
                      <p className="text-xs text-stone-700 dark:text-stone-300">
                        Theme: <strong>{sub.theme}</strong>
                      </p>
                    )}
                    <p className="text-[11px] text-stone-400">
                      Submitted by: {sub.submitter_name} ({sub.submitter_email || 'No email'}) on {new Date(sub.created_at).toLocaleDateString()}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleSubmissionAction(sub.id, 'approve')}
                      className="px-3 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded cursor-pointer"
                    >
                      Approve & Verify
                    </button>
                    <button
                      onClick={() => handleSubmissionAction(sub.id, 'mark_duplicate')}
                      className="px-3 py-1.5 text-xs font-semibold bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 rounded cursor-pointer"
                    >
                      Mark Duplicate
                    </button>
                    <button
                      onClick={() => handleSubmissionAction(sub.id, 'reject')}
                      className="px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded cursor-pointer"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 4. BULK IMPORT TAB */}
      {activeAdminTab === 'import' && (
        <div className="space-y-4 max-w-3xl">
          <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
            Bulk JSON / CSV Pandal Ingestion
          </h3>
          <p className="text-xs text-stone-500">
            Paste an array of pandal objects to batch-import into the database with automatic duplicate detection.
          </p>

          <textarea
            rows={8}
            placeholder={`[\n  {\n    "name": "Sample Heritage Pandal",\n    "neighbourhood": "Shyambazar",\n    "address": "12/A, Bidhan Sarani",\n    "latitude": 22.595,\n    "longitude": 88.369,\n    "theme": "Terracotta Temple"\n  }\n]`}
            value={importJsonText}
            onChange={(e) => setImportJsonText(e.target.value)}
            className="w-full p-3 font-mono text-xs rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
          />

          <div className="flex items-center gap-3">
            <button
              onClick={handleImportPreview}
              className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-stone-800 text-white rounded cursor-pointer"
            >
              Analyze & Preview
            </button>
            {importPreview && (
              <button
                onClick={handleCommitImport}
                disabled={importing}
                className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-emerald-600 text-white rounded cursor-pointer disabled:opacity-50"
              >
                {importing ? 'Importing...' : `Commit ${importPreview.valid} Records`}
              </button>
            )}
          </div>

          {importPreview && (
            <div className="p-4 rounded-xl bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-2 text-xs">
              <h4 className="font-bold text-stone-900 dark:text-stone-100">Analysis Results:</h4>
              <p>Total records detected: <strong>{importPreview.total_detected}</strong></p>
              <p className="text-emerald-600">Valid new records: <strong>{importPreview.valid}</strong></p>
              <p className="text-amber-600">Potential duplicates: <strong>{importPreview.duplicates}</strong></p>
              <p className="text-rose-600">Missing coordinates: <strong>{importPreview.missing_coordinates}</strong></p>
            </div>
          )}
        </div>
      )}

      {/* 5. BULK EXPORT TAB */}
      {activeAdminTab === 'export' && (
        <div className="space-y-4 max-w-2xl">
          <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
            Database Export & Supabase Migrations
          </h3>
          <p className="text-xs text-stone-500">
            Export all pandal records in CSV, JSON, or ready-to-run PostgreSQL / Supabase SQL schema dump.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <a
              href="/api/admin/export?format=json"
              target="_blank"
              download
              className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 hover:border-[#D4AF37] text-center space-y-1"
            >
              <FileText className="w-6 h-6 mx-auto text-[#800020] dark:text-[#D4AF37]" />
              <h4 className="font-bold text-xs">JSON Export</h4>
              <p className="text-[11px] text-stone-400">Complete raw objects</p>
            </a>

            <a
              href="/api/admin/export?format=csv"
              target="_blank"
              download
              className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 hover:border-[#D4AF37] text-center space-y-1"
            >
              <Download className="w-6 h-6 mx-auto text-emerald-600" />
              <h4 className="font-bold text-xs">CSV Spreadsheet</h4>
              <p className="text-[11px] text-stone-400">Excel / Sheets ready</p>
            </a>

            <a
              href="/api/admin/export?format=postgres_sql"
              target="_blank"
              download
              className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-[#D4AF37]/40 hover:border-[#D4AF37] text-center space-y-1 bg-gradient-to-b from-white to-[#D4AF37]/5 dark:from-[#1E1719] dark:to-[#800020]/20"
            >
              <Database className="w-6 h-6 mx-auto text-[#B8860B]" />
              <h4 className="font-bold text-xs">Supabase / Postgres SQL</h4>
              <p className="text-[11px] text-stone-400">Full DDL + INSERT statements</p>
            </a>
          </div>
        </div>
      )}

      {/* 6. PERFORMANCE STRESS TEST TAB */}
      {activeAdminTab === 'performance' && (
        <div className="space-y-4 max-w-2xl">
          <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100">
            Scale & Load Stress Testing
          </h3>
          <p className="text-xs text-stone-500 leading-relaxed">
            As required by specification, test the database and UI with 1,000 to 5,000 records. All generated test records are clearly tagged with <strong className="font-mono">DEMO DATA</strong> and can be wiped with one click.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => handleGeneratePerfData(1000)}
              disabled={loading}
              className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-stone-800 text-white rounded cursor-pointer disabled:opacity-50"
            >
              + Generate 1,000 Test Pandals
            </button>

            <button
              onClick={() => handleGeneratePerfData(2500)}
              disabled={loading}
              className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded cursor-pointer disabled:opacity-50"
            >
              + Generate 2,500 Test Pandals
            </button>

            <button
              onClick={handleClearPerfData}
              disabled={loading}
              className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-rose-600 text-white rounded cursor-pointer disabled:opacity-50"
            >
              Clear All DEMO Records
            </button>
          </div>
        </div>
      )}

      {/* Edit / Add Modal */}
      {isEditing && editingPandal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-[#1C1517] w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl p-6 space-y-4">
            <h3 className="font-heading font-bold text-lg text-stone-900 dark:text-stone-100">
              {editingPandal.id ? 'Edit Pandal Record' : 'Create Pandal Record'}
            </h3>

            <form onSubmit={handleSavePandal} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1">Pandal Name *</label>
                <input
                  type="text"
                  required
                  value={editingPandal.name || ''}
                  onChange={(e) => setEditingPandal({ ...editingPandal, name: e.target.value })}
                  className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">Neighbourhood</label>
                  <input
                    type="text"
                    value={editingPandal.neighbourhood || ''}
                    onChange={(e) => setEditingPandal({ ...editingPandal, neighbourhood: e.target.value })}
                    className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">Established Year</label>
                  <input
                    type="number"
                    value={editingPandal.established_year || ''}
                    onChange={(e) => setEditingPandal({ ...editingPandal, established_year: parseInt(e.target.value) || null })}
                    className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">Latitude</label>
                  <input
                    type="text"
                    value={editingPandal.latitude || ''}
                    onChange={(e) => setEditingPandal({ ...editingPandal, latitude: e.target.value })}
                    className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">Longitude</label>
                  <input
                    type="text"
                    value={editingPandal.longitude || ''}
                    onChange={(e) => setEditingPandal({ ...editingPandal, longitude: e.target.value })}
                    className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">Theme</label>
                <input
                  type="text"
                  value={editingPandal.theme || ''}
                  onChange={(e) => setEditingPandal({ ...editingPandal, theme: e.target.value })}
                  className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">Verification Status</label>
                  <select
                    value={editingPandal.verification_status || 'VERIFIED'}
                    onChange={(e) => setEditingPandal({ ...editingPandal, verification_status: e.target.value })}
                    className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                  >
                    <option value="VERIFIED">VERIFIED</option>
                    <option value="PARTIALLY VERIFIED">PARTIALLY VERIFIED</option>
                    <option value="COMMUNITY SUBMITTED">COMMUNITY SUBMITTED</option>
                    <option value="NEEDS VERIFICATION">NEEDS VERIFICATION</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">Crowd Level</label>
                  <select
                    value={editingPandal.crowd_level || 'Moderate'}
                    onChange={(e) => setEditingPandal({ ...editingPandal, crowd_level: e.target.value })}
                    className="w-full p-2 rounded border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900"
                  >
                    <option value="Low">Low</option>
                    <option value="Moderate">Moderate</option>
                    <option value="High">High</option>
                    <option value="Very High">Very High</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => { setIsEditing(false); setEditingPandal(null); }}
                  className="px-3 py-1.5 rounded hover:bg-stone-100 dark:hover:bg-stone-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#800020] text-white rounded font-bold uppercase"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
