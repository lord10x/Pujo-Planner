import React, { useState } from 'react';
import { Pandal } from '../types';
import { Bookmark, CheckCircle2, Heart, Navigation, Plus, Share2, Eye, MapPin, Star, Route, X } from 'lucide-react';
import confetti from 'canvas-confetti';

interface MyPujaViewProps {
  savedPandals: any[];
  visitedIds: Set<number>;
  onToggleSave: (pandal: Pandal) => void;
  onToggleVisited: (pandalId: number, isVisited: boolean) => void;
  onAddToRoute: (pandal: Pandal) => void;
  isInRoute: (pandalId: number) => boolean;
  onSelectPandal: (pandal: Pandal) => void;
  onOpenExplore: () => void;
  onOpenRoute?: () => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const MyPujaView: React.FC<MyPujaViewProps> = ({
  savedPandals,
  visitedIds,
  onToggleSave,
  onToggleVisited,
  onAddToRoute,
  isInRoute,
  onSelectPandal,
  onOpenExplore,
  onOpenRoute,
  addToast,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'unvisited' | 'visited'>('all');

  const filtered = savedPandals.filter((item) => {
    const isVis = visitedIds.has(item.id);
    if (filterMode === 'visited') return isVis;
    if (filterMode === 'unvisited') return !isVis;
    return true;
  });

  const visitedCount = savedPandals.filter(p => visitedIds.has(p.id)).length;
  const progressPercent = savedPandals.length > 0 ? Math.round((visitedCount / savedPandals.length) * 100) : 0;

  const handleVisitClick = (pandalId: number, currentlyVisited: boolean) => {
    onToggleVisited(pandalId, !currentlyVisited);
    if (!currentlyVisited) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#800020', '#D4AF37', '#E32636', '#FAF7F2']
      });
    }
  };

  const handleShareList = () => {
    const text = `My Saved Kolkata Durga Puja Pandals: ${savedPandals.map(p => p.name).join(', ')} | Planned on Pujo Planner`;
    if (navigator.share) {
      navigator.share({ title: 'My Durga Puja Wishlist', text, url: window.location.href });
    } else {
      navigator.clipboard.writeText(text);
      addToast('Puja wishlist copied to clipboard!', 'info');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-6">
        <div>
          <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
            PERSONAL PUJA DIARY & WISHLIST
          </span>
          <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
            My Puja Planner
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            Track saved pandals, mark darshan completed, and share your personal festival journey.
          </p>
        </div>

        {savedPandals.length > 0 && (
          <button
            onClick={handleShareList}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 border border-stone-300 dark:border-stone-700 hover:bg-stone-100 rounded-md shadow-xs transition-colors cursor-pointer self-start"
          >
            <Share2 className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
            <span>Share My Wishlist</span>
          </button>
        )}
      </div>

      {/* Progress & Stat Bar */}
      {savedPandals.length > 0 && (
        <div className="p-5 rounded-2xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-stone-700 dark:text-stone-300">
              Puja Darshan Progress: <strong className="text-[#800020] dark:text-[#E5C158]">{visitedCount} of {savedPandals.length} Pandals Visited</strong>
            </span>
            <span className="font-mono font-bold text-[#800020] dark:text-[#D4AF37]">{progressPercent}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-stone-100 dark:bg-stone-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#800020] to-[#D4AF37] rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 text-xs font-medium border-b border-stone-200 dark:border-stone-800 pb-3">
        {[
          { id: 'all', label: `All Saved (${savedPandals.length})` },
          { id: 'unvisited', label: `Pending Visit (${savedPandals.length - visitedCount})` },
          { id: 'visited', label: `Visited Darshan (${visitedCount})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterMode(tab.id as any)}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              filterMode === tab.id
                ? 'bg-[#800020] text-white font-bold'
                : 'text-stone-600 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-stone-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Cards Grid */}
      {filtered.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-[#1E1719] border border-dashed border-stone-300 dark:border-stone-800 space-y-3">
          <Bookmark className="w-10 h-10 text-stone-400 mx-auto" />
          <h3 className="font-heading font-bold text-base text-stone-800 dark:text-stone-200">
            {savedPandals.length === 0 ? 'No pandals saved in My Puja yet' : 'No pandals in this category'}
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            Browse the directory and tap the heart icon on any pandal card to save it here for quick access during the festival.
          </p>
          <button
            onClick={onOpenExplore}
            className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded-md shadow cursor-pointer"
          >
            <span>Explore Kolkata Pandals</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((pandal) => {
            const isVis = visitedIds.has(pandal.id);
            const inRoute = isInRoute(pandal.id);

            return (
              <div
                key={pandal.id}
                className="bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 rounded-xl overflow-hidden shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-44 w-full bg-stone-900 cursor-pointer" onClick={() => onSelectPandal(pandal)}>
                    <img
                      src={pandal.cover_image || 'https://images.unsplash.com/photo-1579618218290-24a26f63a728?auto=format&fit=crop&w=600&q=80'}
                      alt={pandal.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleSave(pandal);
                      }}
                      className="absolute top-3 right-3 p-1.5 rounded-full bg-black/50 text-rose-400 hover:text-white"
                      title="Remove from saved"
                    >
                      <Heart className="w-4 h-4 fill-current" />
                    </button>

                    <div className="absolute bottom-3 left-3 right-3 text-white flex items-center justify-between text-xs">
                      <span className="truncate max-w-[200px]">{pandal.neighbourhood || pandal.area_name}</span>
                      <span className="flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded">
                        <Star className="w-3 h-3 fill-[#D4AF37] text-[#D4AF37]" />
                        {pandal.rating.toFixed(1)}
                      </span>
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <h3
                      onClick={() => onSelectPandal(pandal)}
                      className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 hover:text-[#800020] cursor-pointer line-clamp-1"
                    >
                      {pandal.name}
                    </h3>
                    {pandal.theme && (
                      <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-2">
                        <span className="font-semibold text-[#800020] dark:text-[#D4AF37]">Theme:</span> {pandal.theme}
                      </p>
                    )}
                  </div>
                </div>

                <div className="p-4 pt-2 border-t border-stone-100 dark:border-stone-800 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    {/* Mark Visited Toggle */}
                    <button
                      onClick={() => handleVisitClick(pandal.id, isVis)}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md text-xs font-semibold transition-colors cursor-pointer border ${
                        isVis
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800'
                          : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-200 border-stone-200 hover:bg-stone-200'
                      }`}
                    >
                      <CheckCircle2 className={`w-3.5 h-3.5 ${isVis ? 'text-emerald-600' : 'text-stone-400'}`} />
                      <span>{isVis ? 'Visited' : 'Mark Visited'}</span>
                    </button>

                    {/* Add to Route / Cancel Toggle */}
                    {inRoute ? (
                      <button
                        onClick={() => onAddToRoute(pandal)}
                        title="Click to cancel and remove from route"
                        className="flex items-center justify-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-colors cursor-pointer bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 shadow-2xs active:scale-95"
                      >
                        <X className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                        <span>Cancel</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onAddToRoute(pandal)}
                        title="Add to route planner"
                        className="flex items-center justify-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-colors cursor-pointer bg-[#800020] text-white hover:bg-[#660018] shadow-2xs active:scale-95"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ Route</span>
                      </button>
                    )}
                  </div>

                  {inRoute && onOpenRoute && (
                    <button
                      onClick={onOpenRoute}
                      className="w-full py-1.5 px-2 rounded-lg bg-gradient-to-r from-[#800020] to-[#A51D24] hover:from-[#660018] hover:to-[#800020] text-white text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-[0.98] border border-[#D4AF37]/40"
                    >
                      <Route className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>In Route! Go to Route Plan →</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
