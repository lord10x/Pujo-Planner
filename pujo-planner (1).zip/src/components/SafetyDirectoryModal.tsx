import React, { useState } from 'react';
import { X, Phone, ShieldCheck, Search, AlertTriangle, HeartPulse, Bus, Zap, Copy, Check } from 'lucide-react';
import { KOLKATA_EMERGENCY_CONTACTS } from '../data/emergencyContacts';

interface SafetyDirectoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SafetyDirectoryModal: React.FC<SafetyDirectoryModalProps> = ({
  isOpen,
  onClose,
  addToast,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const categories = ['All', 'Police', 'Medical', 'Helpline', 'Transport', 'Utility'];

  const filtered = KOLKATA_EMERGENCY_CONTACTS.filter((c) => {
    const matchesCategory = selectedCategory === 'All' || c.category === selectedCategory;
    const matchesSearch =
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.number.includes(search) ||
      c.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopy = (num: string, id: string) => {
    navigator.clipboard.writeText(num);
    setCopiedId(id);
    addToast(`Copied ${num} to clipboard!`, 'info');
    setTimeout(() => setCopiedId(null), 2500);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Police':
        return <ShieldCheck className="w-4 h-4 text-sky-500" />;
      case 'Medical':
        return <HeartPulse className="w-4 h-4 text-rose-500" />;
      case 'Transport':
        return <Bus className="w-4 h-4 text-amber-500" />;
      case 'Utility':
        return <Zap className="w-4 h-4 text-emerald-500" />;
      default:
        return <Phone className="w-4 h-4 text-[#D4AF37]" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1A1215] w-full max-w-2xl rounded-2xl shadow-2xl border border-[#D4AF37]/40 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#800020] via-[#940026] to-[#70001C] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-[#D4AF37] border border-[#D4AF37]/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-heading font-extrabold text-lg text-white">
                  Kolkata Puja Emergency & Safety Directory
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/80 text-white text-[10px] font-bold uppercase tracking-wider animate-pulse">
                  24x7 Help
                </span>
              </div>
              <p className="text-xs text-stone-200">
                Official helplines for police, medical, crowd assistance & utilities during Durga Puja
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close safety directory"
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Categories Bar */}
        <div className="p-4 border-b border-stone-200 dark:border-stone-800 space-y-3 bg-stone-50 dark:bg-[#150F11] shrink-0">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search emergency helpline, hospital, police, or number..."
              className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#800020]"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-[#800020] text-white shadow-xs'
                    : 'bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300 dark:hover:bg-stone-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* List of Contacts */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-stone-400 text-xs">
              No emergency contacts match your search.
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-xl border border-stone-200 dark:border-stone-800/80 bg-white dark:bg-[#20171A] hover:border-[#D4AF37]/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
              >
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="p-1 rounded-md bg-stone-100 dark:bg-stone-800 shrink-0">
                      {getCategoryIcon(item.category)}
                    </span>
                    <h4 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100">
                      {item.title}
                    </h4>
                    <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-stone-100 dark:bg-stone-800 text-stone-500">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 dark:text-stone-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <button
                    onClick={() => handleCopy(item.number, item.id)}
                    title="Copy number"
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300 transition-colors cursor-pointer"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  <a
                    href={`tel:${item.number}`}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#800020] hover:bg-[#660018] text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95 border border-[#D4AF37]/30"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Call {item.number}</span>
                  </a>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Alert Note */}
        <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border-t border-amber-200 dark:border-amber-900/60 px-4 flex items-center gap-2 text-xs text-amber-900 dark:text-amber-200 shrink-0">
          <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
          <span>In case of severe crowd stampede or medical emergency, approach the nearest <strong>Kolkata Police 'May I Help You' Booth</strong> stationed at every major pandal entrance.</span>
        </div>
      </div>
    </div>
  );
};
