import React, { useState } from 'react';
import {
  ArrowUp, ArrowDown, Trash2, Share2, Compass, Clock, MapPin,
  Check, Flame, Navigation, AlertCircle, PlusCircle
} from 'lucide-react';
import { Pandal, RoutePlan } from '../types';

interface RoutePlannerProps {
  routePandals: Pandal[];
  onRemoveFromRoute: (pandalId: number) => void;
  onReorderRoute: (newOrder: Pandal[]) => void;
  presets: RoutePlan[];
  onLoadPreset: (route: RoutePlan) => void;
  onSelectPandal: (pandal: Pandal) => void;
  onOpenExplore: () => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const RoutePlanner: React.FC<RoutePlannerProps> = ({
  routePandals,
  onRemoveFromRoute,
  onReorderRoute,
  presets,
  onLoadPreset,
  onSelectPandal,
  onOpenExplore,
  addToast,
}) => {
  const [optimizing, setOptimizing] = useState(false);

  // Calculations
  const totalStops = routePandals.length;
  const totalVisitMins = routePandals.reduce((sum, p) => sum + (p.estimated_visit_duration || 35), 0);

  // Calculate inter-stop distances
  let totalDistanceKm = 0;
  for (let i = 0; i < routePandals.length - 1; i++) {
    const p1 = routePandals[i];
    const p2 = routePandals[i + 1];
    if (p1.latitude && p1.longitude && p2.latitude && p2.longitude) {
      totalDistanceKm += calculateDistanceKm(p1.latitude, p1.longitude, p2.latitude, p2.longitude);
    }
  }

  // Estimated travel time (averaging 15 km/h Kolkata Puja festival traffic)
  const estimatedTravelMins = Math.round((totalDistanceKm / 15) * 60) + (totalStops > 1 ? (totalStops - 1) * 10 : 0);
  const totalDurationMins = totalVisitMins + estimatedTravelMins;

  const totalHours = Math.floor(totalDurationMins / 60);
  const remainingMins = totalDurationMins % 60;

  const moveStop = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= routePandals.length) return;
    const updated = [...routePandals];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    onReorderRoute(updated);
  };

  // Real nearest-neighbor optimization
  const optimizeRoute = () => {
    if (routePandals.length < 3) {
      addToast('Add at least 3 pandals to optimize the hopping order.', 'info');
      return;
    }
    setOptimizing(true);
    setTimeout(() => {
      const stopsWithCoords = routePandals.filter(p => p.latitude && p.longitude);
      const stopsWithoutCoords = routePandals.filter(p => !p.latitude || !p.longitude);

      if (stopsWithCoords.length === 0) {
        setOptimizing(false);
        return;
      }

      const unvisited = [...stopsWithCoords];
      const ordered: Pandal[] = [unvisited.shift()!];

      while (unvisited.length > 0) {
        const current = ordered[ordered.length - 1];
        let nearestIdx = 0;
        let minD = Infinity;

        for (let j = 0; j < unvisited.length; j++) {
          const cand = unvisited[j];
          const d = calculateDistanceKm(current.latitude!, current.longitude!, cand.latitude!, cand.longitude!);
          if (d < minD) {
            minD = d;
            nearestIdx = j;
          }
        }
        ordered.push(unvisited.splice(nearestIdx, 1)[0]);
      }

      const finalOrder = [...ordered, ...stopsWithoutCoords];
      onReorderRoute(finalOrder);
      setOptimizing(false);
      addToast('Route path optimized for shortest hopping travel distance!', 'success');
    }, 400);
  };

  const handleShare = () => {
    if (routePandals.length === 0) return;
    const text = `My Kolkata Durga Puja Route Plan: ${routePandals.map((p, i) => `${i + 1}. ${p.name}`).join(' -> ')} | Planned on Pujo Planner`;
    if (navigator.share) {
      navigator.share({ title: 'My Puja Route', text, url: window.location.href });
    } else {
      navigator.clipboard.writeText(text);
      addToast('Route summary copied to clipboard!', 'info');
    }
  };

  // Construct Multi-Stop Google Maps Navigation URL
  const getGoogleMapsRouteUrl = () => {
    if (routePandals.length === 0) return '#';
    const coords = routePandals.filter(p => p.latitude && p.longitude);
    if (coords.length === 0) return '#';

    const origin = `${coords[0].latitude},${coords[0].longitude}`;
    const destination = `${coords[coords.length - 1].latitude},${coords[coords.length - 1].longitude}`;
    const waypoints = coords.slice(1, -1).map(p => `${p.latitude},${p.longitude}`).join('|');

    return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}${waypoints ? `&waypoints=${waypoints}` : ''}&travelmode=driving`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-6">
        <div>
          <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
            CUSTOM ITINERARY & PUJA HOOD TRAIL
          </span>
          <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-1">
            Plan My Puja Route
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            Organize unlimited stops, reorder your circuit, minimize crowd delays, and calculate total transit time.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {routePandals.length > 0 && (
            <>
              <button
                onClick={optimizeRoute}
                disabled={optimizing}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold uppercase tracking-wider bg-white dark:bg-stone-800 text-[#800020] dark:text-[#E5C158] border border-[#800020]/30 dark:border-[#D4AF37]/30 hover:bg-[#800020]/5 rounded-md shadow-xs transition-colors cursor-pointer"
              >
                <Compass className={`w-4 h-4 ${optimizing ? 'animate-spin' : ''}`} />
                <span>{optimizing ? 'Calculating...' : 'Optimize Order'}</span>
              </button>

              <button
                onClick={handleShare}
                className="p-2 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 rounded-md transition-colors cursor-pointer"
                title="Share route"
              >
                <Share2 className="w-5 h-5" />
              </button>

              <a
                href={getGoogleMapsRouteUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white hover:bg-[#660018] rounded-md shadow-sm transition-colors"
              >
                <Navigation className="w-4 h-4 text-[#D4AF37]" />
                <span>Open in Google Maps</span>
              </a>
            </>
          )}
        </div>
      </div>

      {/* Route Metrics Dashboard Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">Total Stops</span>
          <p className="font-heading font-extrabold text-2xl text-stone-900 dark:text-stone-100 mt-1">
            {totalStops}
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">Total Distance</span>
          <p className="font-heading font-extrabold text-2xl text-[#800020] dark:text-[#E5C158] mt-1">
            {totalDistanceKm > 0 ? `${totalDistanceKm.toFixed(1)} km` : '—'}
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">Est. Pandal Visits</span>
          <p className="font-heading font-extrabold text-2xl text-stone-900 dark:text-stone-100 mt-1">
            {totalVisitMins} mins
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-[#D4AF37]/30 shadow-xs bg-gradient-to-br from-white via-white to-[#D4AF37]/10 dark:from-[#1E1719] dark:to-[#800020]/20">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#800020] dark:text-[#D4AF37]">
            Est. Total Circuit Time
          </span>
          <p className="font-heading font-extrabold text-2xl text-[#800020] dark:text-[#E5C158] mt-1">
            {totalDurationMins > 0 ? `${totalHours}h ${remainingMins}m` : '—'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Ordered Stops List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-bold text-lg text-stone-900 dark:text-stone-100">
              Your Itinerary Stops
            </h2>
            {routePandals.length > 0 && (
              <span className="text-xs text-stone-500">
                Use arrows to adjust hopping order
              </span>
            )}
          </div>

          {routePandals.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white dark:bg-[#1E1719] border border-dashed border-stone-300 dark:border-stone-800 space-y-3">
              <Compass className="w-10 h-10 text-stone-400 mx-auto" />
              <h3 className="font-heading font-bold text-base text-stone-800 dark:text-stone-200">
                No pandals added to your route yet
              </h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Explore pandals in our directory or load one of our curated Kolkata trail presets below to get started!
              </p>
              <button
                onClick={onOpenExplore}
                className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded-md shadow cursor-pointer"
              >
                <PlusCircle className="w-4 h-4 text-[#D4AF37]" />
                <span>Explore Pandals</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {routePandals.map((pandal, idx) => (
                <div
                  key={pandal.id}
                  className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 flex items-center justify-between gap-4 shadow-xs hover:border-[#D4AF37]/50 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Stop Number Circle */}
                    <div className="w-8 h-8 rounded-full bg-[#800020] text-white text-xs font-bold flex items-center justify-center shrink-0 border border-[#D4AF37]/40 shadow-xs">
                      {idx + 1}
                    </div>

                    <div className="min-w-0">
                      <h4
                        onClick={() => onSelectPandal(pandal)}
                        className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100 truncate hover:text-[#800020] dark:hover:text-[#D4AF37] cursor-pointer"
                      >
                        {pandal.name}
                      </h4>
                      <div className="flex items-center gap-2 text-xs text-stone-500 mt-0.5">
                        <span>{pandal.neighbourhood || pandal.area_name}</span>
                        <span>·</span>
                        <span>~{pandal.estimated_visit_duration || 30} mins</span>
                        <span>·</span>
                        <span className="font-medium text-stone-700 dark:text-stone-300">Crowd: {pandal.crowd_level}</span>
                      </div>
                    </div>
                  </div>

                  {/* Controls: Up, Down, Remove */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => moveStop(idx, 'up')}
                      disabled={idx === 0}
                      aria-label="Move stop earlier"
                      className="p-1.5 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-600 dark:text-stone-300 disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => moveStop(idx, 'down')}
                      disabled={idx === routePandals.length - 1}
                      aria-label="Move stop later"
                      className="p-1.5 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-600 dark:text-stone-300 disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onRemoveFromRoute(pandal.id)}
                      aria-label="Remove stop"
                      className="p-1.5 rounded hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 cursor-pointer ml-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Col: Curated Route Presets */}
        <div className="space-y-4">
          <div>
            <h2 className="font-heading font-bold text-lg text-stone-900 dark:text-stone-100">
              Curated Puja Trails & Presets
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Battle-tested itineraries designed for heritage, low crowds, or iconic night hopping.
            </p>
          </div>

          <div className="space-y-3">
            {presets.map((pr) => (
              <div
                key={pr.id}
                className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 hover:border-[#D4AF37] transition-all space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#800020] dark:text-[#E5C158] px-2 py-0.5 rounded bg-[#800020]/10 dark:bg-[#800020]/30">
                    {pr.duration_category}
                  </span>
                  <span className="text-xs text-stone-400 font-medium">{pr.stops_count} Stops</span>
                </div>

                <h3 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100 group-hover:text-[#800020] dark:group-hover:text-[#D4AF37] transition-colors">
                  {pr.title}
                </h3>
                <p className="text-xs text-stone-600 dark:text-stone-400 line-clamp-2 leading-relaxed">
                  {pr.description}
                </p>

                <div className="pt-2 flex items-center justify-between border-t border-stone-100 dark:border-stone-800/80">
                  <span className="text-[11px] text-stone-500">~{pr.estimated_hours} Hours Est.</span>
                  <button
                    onClick={() => onLoadPreset(pr)}
                    className="text-xs font-bold text-[#800020] dark:text-[#D4AF37] hover:underline cursor-pointer"
                  >
                    Load This Route →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
