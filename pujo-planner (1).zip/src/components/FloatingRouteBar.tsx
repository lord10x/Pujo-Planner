import React from 'react';
import { Route, ArrowRight, X } from 'lucide-react';
import { Pandal } from '../types';

interface FloatingRouteBarProps {
  routePandals: Pandal[];
  onOpenRoute: () => void;
  onClearRoute?: () => void;
}

export const FloatingRouteBar: React.FC<FloatingRouteBarProps> = ({
  routePandals,
  onOpenRoute,
  onClearRoute,
}) => {
  if (routePandals.length === 0) return null;

  const totalStops = routePandals.length;
  const lastAdded = routePandals[routePandals.length - 1];

  return (
    <aside 
      aria-label="Active Puja Route Bar"
      className="fixed bottom-20 md:bottom-6 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-40 bg-gradient-to-r from-[#800020] via-[#940026] to-[#70001C] text-white p-3 sm:p-3.5 rounded-2xl shadow-2xl border border-[#D4AF37]/60 backdrop-blur-md flex items-center justify-between gap-3 animate-in slide-in-from-bottom-4 transition-all"
    >
      <div 
        onClick={onOpenRoute}
        className="flex items-center gap-2.5 min-w-0 cursor-pointer group flex-1"
        title="Click to view full route plan"
      >
        <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center text-[#D4AF37] shrink-0 border border-[#D4AF37]/40 group-hover:scale-105 transition-transform shadow-xs">
          <Route className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white group-hover:text-[#D4AF37] transition-colors">
              Active Puja Route
            </span>
            <span className="px-2 py-0.5 rounded-full bg-[#D4AF37] text-[#800020] text-[10px] font-extrabold shadow-xs">
              {totalStops} {totalStops === 1 ? 'Stop' : 'Stops'}
            </span>
          </div>
          <p className="text-[11px] text-stone-200 truncate mt-0.5">
            Added: <span className="font-semibold text-white">{lastAdded?.name}</span>
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        <button
          onClick={onOpenRoute}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-[#800020] hover:bg-[#FAF7F2] text-xs font-extrabold uppercase tracking-wider shadow-sm transition-all active:scale-95 cursor-pointer hover:shadow-md"
        >
          <span>Go to Route</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#800020]" />
        </button>

        {onClearRoute && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClearRoute();
            }}
            title="Clear all route stops"
            aria-label="Clear route"
            className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    </aside>
  );
};
