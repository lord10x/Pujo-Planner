import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, errorMessage: error.message };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error caught by ErrorBoundary:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[50vh] flex flex-col items-center justify-center p-6 text-center bg-[#FAF7F2] dark:bg-[#150F11]">
          <div className="w-12 h-12 rounded-full bg-[#800020]/10 text-[#800020] dark:text-[#E5C158] flex items-center justify-center mb-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="font-heading font-bold text-xl text-stone-900 dark:text-stone-100">
            Something went wrong. Please try again.
          </h2>
          <p className="text-xs text-stone-500 max-w-sm mt-1">
            An unexpected glitch occurred while rendering this view. You can reload the page or navigate back to the home directory.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded-md cursor-pointer hover:bg-[#660018]"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reload Pujo Planner</span>
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
