import React, { useState, useEffect } from 'react';
import { Pandal, Area } from '../types';
import { MapPanel } from './MapPanel';
import { PandalCard } from './PandalCard';
import { api } from '../services/api';
import { MapPin, Search, PlusCircle, Filter } from 'lucide-react';

interface MapViewContainerProps {
  areas: Area[];
  selectedAreaSlug?: string;
  userLocation: { lat: number; lng: number } | null;
  onRequestLocation: () => void;
  savedIds: Set<number>;
  onToggleSave: (pandal: Pandal) => void;
  onAddToRoute: (pandal: Pandal) => void;
  isInRoute: (pandalId: number) => boolean;
  onSelectPandal: (pandal: Pandal) => void;
  onOpenAddModal: () => void;
  onOpenRoute?: () => void;
  onOpenDirections?: (pandal: Pandal) => void;
  darkMode?: boolean;
}

export const MapViewContainer: React.FC<MapViewContainerProps> = ({
  areas,
  selectedAreaSlug = '',
  userLocation,
  onRequestLocation,
  savedIds,
  onToggleSave,
  onAddToRoute,
  isInRoute,
  onSelectPandal,
  onOpenAddModal,
  onOpenRoute,
  onOpenDirections,
  darkMode = false,
}) => {
  const [mapPandals, setMapPandals] = useState<Pandal[]>([]);
  const [selectedPandal, setSelectedPandal] = useState<Pandal | null>(null);
  const [areaFilter, setAreaFilter] = useState(selectedAreaSlug);
  const [crowdFilter, setCrowdFilter] = useState('');
  const [mobileTab, setMobileTab] = useState<'map' | 'list'>('map');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMapPoints = async () => {
      try {
        setLoading(true);
        const data = await api.getMapPandals({
          area_slug: areaFilter,
          crowd: crowdFilter,
          status: 'Active',
        });
        setMapPandals(data);
        if (data.length > 0 && !selectedPandal) {
          setSelectedPandal(data[0]);
        }
      } catch (e) {
        console.error('Failed to load map pandals:', e);
      } finally {
        setLoading(false);
      }
    };
    fetchMapPoints();
  }, [areaFilter, crowdFilter]);

  const routePandalIds = Array.from(savedIds);

  return (
    <div className="h-[calc(100vh-4rem)] sm:h-[calc(100vh-5rem)] flex flex-col bg-[#FAF7F2] dark:bg-[#120D0F]">
      {/* Top Filter Bar */}
      <div className="p-3 border-b border-stone-200 dark:border-stone-800 bg-white dark:bg-[#1A1215] flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2 overflow-x-auto text-xs">
          <select
            value={areaFilter}
            onChange={(e) => setAreaFilter(e.target.value)}
            className="p-2 rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900 font-semibold"
          >
            <option value="">All Kolkata Areas ({mapPandals.length})</option>
            {areas.map((a) => (
              <option key={a.id} value={a.slug}>
                {a.name}
              </option>
            ))}
          </select>

          <select
            value={crowdFilter}
            onChange={(e) => setCrowdFilter(e.target.value)}
            className="p-2 rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-900 font-semibold"
          >
            <option value="">Any Crowd</option>
            <option value="Low">Low Crowd Only</option>
            <option value="Moderate">Moderate Crowd</option>
            <option value="High">High Crowd</option>
            <option value="Very High">Very High (Mega Pandals)</option>
          </select>
        </div>

        {/* Mobile View Toggle & Add Button */}
        <div className="flex items-center gap-2">
          <div className="flex md:hidden bg-stone-100 dark:bg-stone-800 p-0.5 rounded-lg text-xs font-bold">
            <button
              onClick={() => setMobileTab('map')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                mobileTab === 'map' ? 'bg-[#800020] text-white' : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              Map
            </button>
            <button
              onClick={() => setMobileTab('list')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                mobileTab === 'list' ? 'bg-[#800020] text-white' : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              List ({mapPandals.length})
            </button>
          </div>

          <button
            onClick={onOpenAddModal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#800020] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#660018] transition-colors cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>+ Add Pandal</span>
          </button>
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Desktop Left: Scrollable Pandal List (or Mobile when list active) */}
        <div
          className={`w-full md:w-96 lg:w-[420px] h-full overflow-y-auto p-4 border-r border-stone-200 dark:border-stone-800 space-y-4 shrink-0 bg-white dark:bg-[#171113] ${
            mobileTab === 'list' ? 'block' : 'hidden md:block'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-stone-500 pb-1">
            <span>Showing {mapPandals.length} pandals with map coordinates</span>
          </div>

          <div className="space-y-4">
            {mapPandals.map((p) => {
              const isSelected = selectedPandal?.id === p.id;
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPandal(p)}
                  className={`cursor-pointer rounded-xl transition-all ${
                    isSelected ? 'ring-2 ring-[#800020] dark:ring-[#D4AF37]' : ''
                  }`}
                >
                  <PandalCard
                    pandal={p}
                    isSaved={savedIds.has(p.id)}
                    onToggleSave={onToggleSave}
                    onAddToRoute={onAddToRoute}
                    isInRoute={isInRoute(p.id)}
                    onSelect={(pandal) => {
                      setSelectedPandal(pandal);
                      onSelectPandal(pandal);
                    }}
                    onOpenRoute={onOpenRoute}
                    onOpenDirections={onOpenDirections}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Map Panel (or Mobile when map active) */}
        <div
          className={`flex-1 h-full relative ${
            mobileTab === 'map' ? 'block' : 'hidden md:block'
          }`}
        >
          <MapPanel
            pandals={mapPandals}
            selectedPandal={selectedPandal}
            onSelectPandal={(pandal) => {
              setSelectedPandal(pandal);
            }}
            userLocation={userLocation}
            onRequestLocation={onRequestLocation}
            onAddToRoute={onAddToRoute}
            routePandalIds={mapPandals.filter(p => isInRoute(p.id)).map(p => p.id)}
            darkMode={darkMode}
            onOpenRoute={onOpenRoute}
            onOpenDirections={onOpenDirections}
          />
        </div>
      </div>
    </div>
  );
};
