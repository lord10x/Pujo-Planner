import React, { useState } from 'react';
import { X, MapPin, PlusCircle, AlertCircle, CheckCircle2, Search } from 'lucide-react';
import { Area } from '../types';
import { api } from '../services/api';

interface AddPandalModalProps {
  isOpen: boolean;
  onClose: () => void;
  areas: Area[];
  onSuccess: () => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AddPandalModal: React.FC<AddPandalModalProps> = ({
  isOpen,
  onClose,
  areas,
  onSuccess,
  addToast,
}) => {
  const [pandalName, setPandalName] = useState('');
  const [areaId, setAreaId] = useState<number>(areas[0]?.id || 1);
  const [neighbourhood, setNeighbourhood] = useState('');
  const [address, setAddress] = useState('');
  const [lat, setLat] = useState<string>('22.5726');
  const [lng, setLng] = useState<string>('88.3639');
  const [theme, setTheme] = useState('');
  const [description, setDescription] = useState('');
  const [committee, setCommittee] = useState('');
  const [establishedYear, setEstablishedYear] = useState('');
  const [nearestMetro, setNearestMetro] = useState('');
  const [nearestRailway, setNearestRailway] = useState('');
  const [wheelchair, setWheelchair] = useState(false);
  const [parking, setParking] = useState(false);
  const [submitterName, setSubmitterName] = useState('');
  const [submitterEmail, setSubmitterEmail] = useState('');
  const [sourceReference, setSourceReference] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [dupWarning, setDupWarning] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleNameBlur = async () => {
    if (pandalName.trim().length > 3) {
      try {
        const check = await api.checkDuplicates(pandalName.trim());
        if (check.possible_duplicates && check.possible_duplicates.length > 0) {
          const top = check.possible_duplicates[0];
          setDupWarning(`Notice: A pandal named "${top.name}" already exists in ${top.address || 'Kolkata'}. If this is the same pandal, please do not submit a duplicate.`);
        } else {
          setDupWarning(null);
        }
      } catch {}
    }
  };

  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      addToast('Geolocation not supported.', 'error');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude.toFixed(5));
        setLng(pos.coords.longitude.toFixed(5));
        addToast('Coordinates captured from your device GPS!', 'success');
      },
      () => addToast('Could not access GPS location.', 'error')
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pandalName.trim()) {
      addToast('Pandal name is required.', 'error');
      return;
    }

    try {
      setSubmitting(true);
      await api.submitMissingPandal({
        pandal_name: pandalName.trim(),
        area_id: areaId,
        neighbourhood: neighbourhood.trim(),
        address: address.trim(),
        latitude: lat ? parseFloat(lat) : null,
        longitude: lng ? parseFloat(lng) : null,
        theme: theme.trim(),
        description: description.trim(),
        committee_name: committee.trim(),
        established_year: establishedYear ? parseInt(establishedYear) : null,
        nearest_metro: nearestMetro.trim(),
        nearest_railway: nearestRailway.trim(),
        wheelchair_access: wheelchair ? 1 : 0,
        parking_available: parking ? 1 : 0,
        submitter_name: submitterName.trim(),
        submitter_email: submitterEmail.trim(),
        source_reference: sourceReference.trim(),
      });

      addToast('Pandal submitted! It is now listed as Community Submitted.', 'success');
      onSuccess();
      onClose();
    } catch (err: any) {
      addToast(err.message || 'Failed to submit pandal', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-[#FAF7F2] dark:bg-[#1C1517] w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl border border-[#D4AF37]/30 flex flex-col">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-[#FAF7F2] dark:bg-[#1C1517] px-6 py-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
          <div>
            <h2 className="font-heading font-extrabold text-xl text-[#800020] dark:text-[#E5C158] flex items-center gap-2">
              <PlusCircle className="w-5 h-5" />
              Add Missing Kolkata Pandal
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Help build Kolkata’s definitive, comprehensive Durga Puja directory.
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {dupWarning && (
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{dupWarning}</span>
            </div>
          )}

          {/* Section: Basic info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Pandal Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Maddox Square, Bagbazar Sarbojanin..."
                value={pandalName}
                onChange={(e) => setPandalName(e.target.value)}
                onBlur={handleNameBlur}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Region / Area *
              </label>
              <select
                value={areaId}
                onChange={(e) => setAreaId(parseInt(e.target.value))}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              >
                {areas.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name} ({a.region})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Neighbourhood / Landmark
              </label>
              <input
                type="text"
                placeholder="e.g. Shyambazar, Gariahat, Bowbazar..."
                value={neighbourhood}
                onChange={(e) => setNeighbourhood(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
              Full Street Address
            </label>
            <input
              type="text"
              placeholder="e.g. 15, Ekdalia Road, Kolkata 700019"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
            />
          </div>

          {/* Map Location Coordinates Picker */}
          <div className="p-3.5 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#800020] dark:text-[#D4AF37]" />
                Geographic Coordinates (Lat & Lng)
              </span>
              <button
                type="button"
                onClick={handleUseCurrentLocation}
                className="text-[11px] text-[#800020] dark:text-[#D4AF37] font-semibold hover:underline cursor-pointer"
              >
                Use My Current GPS Location
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[11px] text-stone-500">Latitude</span>
                <input
                  type="text"
                  placeholder="22.5726"
                  value={lat}
                  onChange={(e) => setLat(e.target.value)}
                  className="w-full p-2 text-xs rounded border border-stone-300 dark:border-stone-700 font-mono"
                />
              </div>
              <div>
                <span className="text-[11px] text-stone-500">Longitude</span>
                <input
                  type="text"
                  placeholder="88.3639"
                  value={lng}
                  onChange={(e) => setLng(e.target.value)}
                  className="w-full p-2 text-xs rounded border border-stone-300 dark:border-stone-700 font-mono"
                />
              </div>
            </div>
            <p className="text-[11px] text-stone-400">
              Tip: You can right-click any location on Google Maps to copy exact latitude/longitude.
            </p>
          </div>

          {/* Theme & History */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                2026 Theme
              </label>
              <input
                type="text"
                placeholder="e.g. Sabeki Daaker Saaj, Terracotta Heritage..."
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Established Year
              </label>
              <input
                type="number"
                placeholder="e.g. 1943"
                value={establishedYear}
                onChange={(e) => setEstablishedYear(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
              About & Description
            </label>
            <textarea
              rows={3}
              placeholder="Tell devotees about the idol, the committee, artistic concept, or famous history..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
            />
          </div>

          {/* Transport & Access */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Nearest Metro
              </label>
              <input
                type="text"
                placeholder="e.g. Kalighat Metro, Shyambazar Metro..."
                value={nearestMetro}
                onChange={(e) => setNearestMetro(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Organizing Committee
              </label>
              <input
                type="text"
                placeholder="e.g. Youth Cultural Club..."
                value={committee}
                onChange={(e) => setCommittee(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>
          </div>

          {/* Submitter Details */}
          <div className="pt-2 border-t border-stone-200 dark:border-stone-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Your Name
              </label>
              <input
                type="text"
                placeholder="e.g. Suman Roy"
                value={submitterName}
                onChange={(e) => setSubmitterName(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                Source Reference (URL / News)
              </label>
              <input
                type="text"
                placeholder="e.g. Official Facebook page or news link"
                value={sourceReference}
                onChange={(e) => setSourceReference(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
              />
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 rounded-md cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 text-xs uppercase tracking-wider font-bold bg-[#800020] text-white hover:bg-[#660018] rounded-md shadow disabled:opacity-50 cursor-pointer"
            >
              {submitting ? 'Submitting...' : 'Submit Pandal'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
