import React from 'react';
import { ToastMessage } from '../hooks/useUserStore';
import { CheckCircle2, AlertCircle, Info, ArrowRight } from 'lucide-react';

interface ToastContainerProps {
  toasts: ToastMessage[];
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`p-3.5 rounded-xl shadow-xl border backdrop-blur-md flex items-center justify-between gap-3 text-xs font-medium pointer-events-auto transition-all animate-in slide-in-from-bottom-2 ${
            t.type === 'success'
              ? 'bg-stone-900/95 text-white border-[#D4AF37]/50 shadow-emerald-950/20'
              : t.type === 'error'
              ? 'bg-rose-950/95 text-white border-rose-700/50'
              : 'bg-stone-900/95 text-white border-stone-700/50'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {t.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
            {t.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
            {t.type === 'info' && <Info className="w-4 h-4 text-[#D4AF37] shrink-0" />}
            <span className="leading-snug text-stone-100">{t.message}</span>
          </div>

          {t.action && (
            <button
              onClick={t.action.onClick}
              className="shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#800020] hover:bg-[#A51D24] text-[#FAF7F2] font-bold text-[11px] shadow-sm transition-transform active:scale-95 cursor-pointer border border-[#D4AF37]/40"
            >
              <span>{t.action.label}</span>
              <ArrowRight className="w-3 h-3 text-[#D4AF37]" />
            </button>
          )}
        </div>
      ))}
    </div>
  );
};
