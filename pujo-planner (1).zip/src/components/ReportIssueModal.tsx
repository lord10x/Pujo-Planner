import React, { useState } from 'react';
import { X, Flag, AlertTriangle } from 'lucide-react';
import { Pandal } from '../types';
import { api } from '../services/api';

interface ReportIssueModalProps {
  pandal: Pandal | null;
  onClose: () => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ReportIssueModal: React.FC<ReportIssueModalProps> = ({
  pandal,
  onClose,
  addToast,
}) => {
  const [issueType, setIssueType] = useState('Wrong location');
  const [details, setDetails] = useState('');
  const [contact, setContact] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!pandal) return null;

  const issueOptions = [
    'Wrong location / coordinates',
    'Wrong pandal name or spelling',
    'Wrong timings or best visit time',
    'Wrong theme or artist attribution',
    'Wrong or low-quality image',
    'Pandal no longer active / discontinued',
    'Duplicate pandal entry',
    'Other correction',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.trim()) {
      addToast('Please provide details for the correction.', 'error');
      return;
    }

    try {
      setSubmitting(true);
      await api.reportIssue({
        pandal_id: pandal.id,
        issue_type: issueType,
        details: details.trim(),
        reporter_contact: contact.trim(),
      });
      addToast('Correction report submitted! Our editorial team will review it.', 'success');
      onClose();
    } catch (err: any) {
      addToast(err.message || 'Failed to submit report', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="bg-[#FAF7F2] dark:bg-[#1C1517] w-full max-w-md rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-800 flex flex-col">
        <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[#800020] dark:text-[#E5C158]">
            <Flag className="w-5 h-5" />
            <h3 className="font-heading font-bold text-base">Report Incorrect Information</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <p className="text-xs text-stone-600 dark:text-stone-400">
            Reporting for: <strong className="text-stone-900 dark:text-stone-100">{pandal.name}</strong>
          </p>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
              Issue Category
            </label>
            <select
              value={issueType}
              onChange={(e) => setIssueType(e.target.value)}
              className="w-full p-2 text-xs rounded border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
            >
              {issueOptions.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
              Explanation & Correct Information *
            </label>
            <textarea
              required
              rows={3}
              placeholder="Please explain the mistake and provide the correct details or reference link..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="w-full p-2 text-xs rounded border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
              Your Email / Contact (Optional)
            </label>
            <input
              type="text"
              placeholder="In case our editors have questions"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              className="w-full p-2 text-xs rounded border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 text-xs font-semibold text-stone-600 dark:text-stone-300 hover:bg-stone-200 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#800020] text-white rounded cursor-pointer disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Send to Editors'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
