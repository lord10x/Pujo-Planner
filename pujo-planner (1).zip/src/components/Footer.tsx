import React from 'react';
import { ShieldCheck, PlusCircle, Flag, Info, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
  onOpenAddModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenAddModal,
}) => {
  return (
    <footer className="bg-white dark:bg-[#120D0F] border-t border-[#D4AF37]/20 text-stone-600 dark:text-stone-400 text-xs">
      {/* Trust & Transparency Section */}
      <div className="bg-[#F8F4EC] dark:bg-[#181114] py-8 border-b border-stone-200 dark:border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-3">
            <Info className="w-4 h-4 text-[#800020] dark:text-[#E5C158]" />
            <h4 className="font-heading font-bold text-sm text-stone-900 dark:text-stone-100 uppercase tracking-wider">
              About Our Pandal Data & Transparency
            </h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-stone-600 dark:text-stone-400 leading-relaxed">
            <div>
              <strong className="text-stone-800 dark:text-stone-200 block mb-1">What Verified Means:</strong>
              Records labeled <span className="font-semibold text-emerald-700 dark:text-emerald-400">VERIFIED</span> have been cross-referenced with municipal records, West Bengal Tourism lists, official puja committee releases, or on-ground field validation.
            </div>
            <div>
              <strong className="text-stone-800 dark:text-stone-200 block mb-1">Community Submitted:</strong>
              Records submitted by citizens, devotees, and local clubs appear marked as <span className="font-semibold text-amber-700 dark:text-amber-400">COMMUNITY SUBMITTED</span> while editorial review is underway.
            </div>
            <div>
              <strong className="text-stone-800 dark:text-stone-200 block mb-1">Continuous Correction:</strong>
              If coordinates, timings, themes, or images are inaccurate, use the "Report issue" button on any pandal page to flag corrections directly to our editorial team.
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {/* Brand Col */}
          <div className="col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded bg-[#800020] flex items-center justify-center text-[#D4AF37] font-serif font-bold text-base">
                পূ
              </div>
              <span className="font-heading font-bold text-lg text-[#800020] dark:text-[#E5C158] tracking-wider">
                PUJO PLANNER
              </span>
            </div>
            <p className="text-stone-500 max-w-sm leading-relaxed">
              The comprehensive, scalable Kolkata Durga Puja pandal discovery, interactive map, crowd tracking, and route planning engine.
            </p>
            <button
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#800020] text-white hover:bg-[#660018] text-xs font-bold uppercase tracking-wider cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>+ Add Missing Pandal</span>
            </button>
          </div>

          {/* Nav Col */}
          <div>
            <h5 className="font-heading font-bold text-stone-900 dark:text-stone-200 mb-3 uppercase tracking-wider text-[11px]">
              Explore
            </h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('explore')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  All Pandals
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('map')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  Interactive Map
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('areas')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  Area Explorer
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('routes')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  Route Planner
                </button>
              </li>
            </ul>
          </div>

          {/* Puja Guide Col */}
          <div>
            <h5 className="font-heading font-bold text-stone-900 dark:text-stone-200 mb-3 uppercase tracking-wider text-[11px]">
              Festivals
            </h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('routes')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  North Kolkata Heritage
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('routes')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  South Kolkata Art Circuit
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('routes')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  Low Crowd Morning Trails
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('mypuja')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  My Puja Saved List
                </button>
              </li>
            </ul>
          </div>

          {/* Admin & Legal Col */}
          <div>
            <h5 className="font-heading font-bold text-stone-900 dark:text-stone-200 mb-3 uppercase tracking-wider text-[11px]">
              Editorial & Admin
            </h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('admin')} className="hover:text-[#800020] dark:hover:text-[#E5C158] cursor-pointer">
                  Admin Verification Desk
                </button>
              </li>
              <li>
                <a href="/api/admin/export?format=postgres_sql" target="_blank" className="hover:text-[#800020] dark:hover:text-[#E5C158]">
                  Database DDL (Supabase)
                </a>
              </li>
              <li>
                <span className="text-stone-400">Open Data License</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-8 pt-8 border-t border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500">
          <p>© {new Date().getFullYear()} Pujo Planner. Built with devotion for Kolkata Durga Puja devotees and culture lovers.</p>
          <div className="flex items-center gap-4">
            <span>No Artificial Limits</span>
            <span>·</span>
            <span>PostgreSQL Compatible</span>
            <span>·</span>
            <span>PWA Enabled</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
