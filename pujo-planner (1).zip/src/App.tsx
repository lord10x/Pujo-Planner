import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ExploreView } from './components/ExploreView';
import { MapViewContainer } from './components/MapViewContainer';
import { RoutePlanner } from './components/RoutePlanner';
import { AreaExplorer } from './components/AreaExplorer';
import { MyPujaView } from './components/MyPujaView';
import { AdminDashboard } from './components/AdminDashboard';
import { PandalDetailView } from './components/PandalDetailView';
import { AddPandalModal } from './components/AddPandalModal';
import { ReportIssueModal } from './components/ReportIssueModal';
import { ToastContainer } from './components/ToastContainer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { FloatingRouteBar } from './components/FloatingRouteBar';
import { Footer } from './components/Footer';
import { ErrorBoundary } from './components/ErrorBoundary';
import { useUserStore } from './hooks/useUserStore';
import { api } from './services/api';
import { Pandal, Area, RoutePlan, StatsData } from './types';
import { PlusCircle, Sparkles, MapPin, ShieldCheck, Flame, Compass, WifiOff, ArrowRight } from 'lucide-react';
import { PandalCard } from './components/PandalCard';

export function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedPandalSlug, setSelectedPandalSlug] = useState<string | null>(null);
  const [reportingPandal, setReportingPandal] = useState<Pandal | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Search & Area navigation state
  const [exploreSearch, setExploreSearch] = useState('');
  const [exploreAreaSlug, setExploreAreaSlug] = useState('');

  // Global Data
  const [stats, setStats] = useState<StatsData | null>(null);
  const [areas, setAreas] = useState<Area[]>([]);
  const [themes, setThemes] = useState<string[]>([]);
  const [presets, setPresets] = useState<RoutePlan[]>([]);
  const [featuredPandals, setFeaturedPandals] = useState<Pandal[]>([]);

  // Dark Mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('pujo_theme') === 'dark';
  });

  // Offline detection
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // PWA Install prompt
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);

  // User store
  const {
    savedIds,
    visitedIds,
    savedPandals,
    routePandals,
    userLocation,
    toasts,
    addToast,
    toggleSave,
    toggleVisited,
    addToRoute,
    removeFromRoute,
    clearRoute,
    isPandalInRoute,
    reorderRoute,
    requestLocation,
    refreshSaved,
  } = useUserStore();

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('pujo_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('pujo_theme', 'light');
    }
  }, [darkMode]);

  // Offline listener
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // PWA Service Worker & Install prompt listener
  useEffect(() => {
    if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      navigator.serviceWorker.register('/sw.js').catch(err => {
        console.warn('SW registration failed:', err);
      });
    }

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallPwa = async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    const { outcome } = await deferredInstallPrompt.userChoice;
    if (outcome === 'accepted') {
      addToast('Pujo Planner installed to your device!', 'success');
    }
    setDeferredInstallPrompt(null);
  };

  // Load initial app data
  const loadInitialData = async () => {
    try {
      const [statsData, areasData, themesData, routesData, featRes] = await Promise.all([
        api.getStats(),
        api.getAreas(),
        api.getThemes(),
        api.getRoutes(),
        api.getPandals({ limit: 8, sort: 'rating' }),
      ]);
      setStats(statsData);
      setAreas(areasData);
      setThemes(themesData);
      setPresets(routesData);
      setFeaturedPandals(featRes.data);
    } catch (e) {
      console.error('Failed to load initial data:', e);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  // Handlers
  const handleHeroSearchSubmit = (q: string) => {
    setExploreSearch(q);
    setExploreAreaSlug('');
    setCurrentTab('explore');
  };

  const handleSelectArea = (areaSlug: string) => {
    setExploreAreaSlug(areaSlug);
    setExploreSearch('');
    setCurrentTab('explore');
  };

  const handleOpenMapArea = (areaSlug: string) => {
    setExploreAreaSlug(areaSlug);
    setCurrentTab('map');
  };

  const handleLoadPreset = (route: RoutePlan) => {
    if (route.stops && route.stops.length > 0) {
      const pandalStops = route.stops.map((s) => ({
        id: s.pandal_id,
        name: s.pandal_name,
        slug: s.pandal_slug,
        area_id: 1,
        neighbourhood: s.neighbourhood,
        address: s.address,
        latitude: s.latitude ?? null,
        longitude: s.longitude ?? null,
        status: 'Active' as const,
        active_year: 2026,
        estimated_visit_duration: s.estimated_duration_mins || 35,
        crowd_level: s.crowd_level || 'Moderate',
        rating: s.rating || 4.8,
        rating_count: 300,
        nearest_metro: s.nearest_metro,
        parking_available: 0,
        wheelchair_access: 1,
        elder_friendly: 1,
        family_friendly: 1,
        verification_status: 'VERIFIED' as const,
        cover_image: s.cover_image,
      }));
      reorderRoute(pandalStops);
      setCurrentTab('routes');
      addToast(`Loaded preset "${route.title}" with ${route.stops.length} stops!`, 'success', {
        label: 'View Route →',
        onClick: () => setCurrentTab('routes'),
      });
    }
  };

  const handleAddToRoute = (pandal: Pandal) => {
    addToRoute(pandal, () => setCurrentTab('routes'));
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] dark:bg-[#120D0F] text-[#1C1917] dark:text-[#F3EFE6] transition-colors selection:bg-[#800020] selection:text-white">
      {/* Offline Alert Strip */}
      {isOffline && (
        <div className="bg-amber-600 text-white px-4 py-2 text-xs font-semibold flex items-center justify-center gap-2 sticky top-0 z-50 shadow-md">
          <WifiOff className="w-4 h-4" />
          <span>You are currently offline. Previously saved pandals remain available on your device.</span>
        </div>
      )}

      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenAddModal={() => setIsAddModalOpen(true)}
        savedCount={savedIds.size}
        routeCount={routePandals.length}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        deferredInstallPrompt={deferredInstallPrompt}
        onInstallPwa={handleInstallPwa}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16 md:pb-0">
        <ErrorBoundary>
          {currentTab === 'home' && (
            <div className="space-y-12 sm:space-y-16">
              {/* Hero Banner */}
              <HeroSection
                stats={stats}
                onSearchSubmit={handleHeroSearchSubmit}
                onNavigate={setCurrentTab}
              />

              {/* Featured / Iconic Pandals Showcase */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
                <div className="flex items-end justify-between border-b border-stone-200 dark:border-stone-800 pb-4">
                  <div>
                    <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
                      ICONIC HERITAGE & TOP PICKS
                    </span>
                    <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-0.5">
                      Celebrated Kolkata Pandals
                    </h2>
                  </div>
                  <button
                    onClick={() => { setExploreSearch(''); setExploreAreaSlug(''); setCurrentTab('explore'); }}
                    className="flex items-center gap-1 text-xs font-bold text-[#800020] dark:text-[#E5C158] hover:underline cursor-pointer"
                  >
                    <span>View All Directory</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {featuredPandals.slice(0, 8).map((pandal) => (
                    <PandalCard
                      key={pandal.id}
                      pandal={pandal}
                      isSaved={savedIds.has(pandal.id)}
                      onToggleSave={toggleSave}
                      onAddToRoute={handleAddToRoute}
                      isInRoute={isPandalInRoute(pandal)}
                      onSelect={(p) => setSelectedPandalSlug(p.slug)}
                      onOpenRoute={() => setCurrentTab('routes')}
                    />
                  ))}
                </div>
              </section>

              {/* Curated Trail Presets Preview */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
                <div className="border-b border-stone-200 dark:border-stone-800 pb-4">
                  <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
                    READY-MADE FESTIVAL CIRCUITS
                  </span>
                  <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-0.5">
                    Curated Puja Hopping Trails
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {presets.slice(0, 4).map((pr) => (
                    <div
                      key={pr.id}
                      className="p-5 rounded-2xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 hover:border-[#D4AF37] transition-all flex flex-col justify-between shadow-xs group"
                    >
                      <div className="space-y-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#800020] dark:text-[#E5C158] px-2 py-0.5 rounded bg-[#800020]/10 dark:bg-[#800020]/30 inline-block">
                          {pr.duration_category}
                        </span>
                        <h3 className="font-heading font-bold text-base text-stone-900 dark:text-stone-100 group-hover:text-[#800020] dark:group-hover:text-[#D4AF37] transition-colors">
                          {pr.title}
                        </h3>
                        <p className="text-xs text-stone-500 line-clamp-3 leading-relaxed">
                          {pr.description}
                        </p>
                      </div>

                      <div className="pt-4 mt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
                        <span className="text-xs font-semibold text-stone-400">{pr.stops_count} Stops</span>
                        <button
                          onClick={() => handleLoadPreset(pr)}
                          className="text-xs font-bold text-[#800020] dark:text-[#E5C158] hover:underline cursor-pointer"
                        >
                          Start Route →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Area Explorer Preview Grid */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
                <div className="border-b border-stone-200 dark:border-stone-800 pb-4 flex items-end justify-between">
                  <div>
                    <span className="text-xs uppercase tracking-widest font-bold text-[#800020] dark:text-[#E5C158]">
                      NEIGHBOURHOOD HUBS
                    </span>
                    <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-stone-900 dark:text-stone-100 mt-0.5">
                      Explore Kolkata By Area
                    </h2>
                  </div>
                  <button
                    onClick={() => setCurrentTab('areas')}
                    className="text-xs font-bold text-[#800020] dark:text-[#E5C158] hover:underline cursor-pointer"
                  >
                    All Areas →
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  {areas.map((a) => (
                    <button
                      key={a.id}
                      onClick={() => handleSelectArea(a.slug)}
                      className="p-4 rounded-xl bg-white dark:bg-[#1E1719] border border-stone-200 dark:border-stone-800 hover:border-[#D4AF37] hover:shadow-xs transition-all text-left group cursor-pointer"
                    >
                      <h4 className="font-heading font-bold text-xs sm:text-sm text-stone-900 dark:text-stone-100 group-hover:text-[#800020] dark:group-hover:text-[#D4AF37] line-clamp-1">
                        {a.name}
                      </h4>
                      <p className="text-[11px] text-stone-500 mt-1">{a.pandal_count} Pandals</p>
                    </button>
                  ))}
                </div>
              </section>

              {/* Prominent "+ ADD MISSING PANDAL" Callout Banner */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <div className="rounded-2xl p-8 bg-gradient-to-r from-[#800020] via-[#A51D24] to-[#6B001B] text-white border border-[#D4AF37]/50 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="space-y-2 text-center md:text-left">
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#D4AF37]">
                      COMMUNITY CITIZEN DIRECTORY
                    </span>
                    <h3 className="font-heading font-extrabold text-2xl sm:text-3xl text-white">
                      Know a local or historic pandal not listed here?
                    </h3>
                    <p className="text-xs sm:text-sm text-stone-200 max-w-xl">
                      Pujo Planner is built to contain all Kolkata pandals without arbitrary limits. Submit your neighbourhood puja, upload theme details, and put it on Kolkata's live festival map.
                    </p>
                  </div>

                  <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="px-6 py-3.5 rounded-xl bg-white text-[#800020] hover:bg-[#FAF7F2] text-xs uppercase tracking-wider font-extrabold shadow-lg hover:shadow-xl transition-all active:scale-95 shrink-0 cursor-pointer flex items-center gap-2"
                  >
                    <PlusCircle className="w-4 h-4 text-[#800020]" />
                    <span>+ Add Missing Pandal</span>
                  </button>
                </div>
              </section>
            </div>
          )}

          {currentTab === 'explore' && (
            <ExploreView
              initialSearch={exploreSearch}
              initialAreaSlug={exploreAreaSlug}
              areas={areas}
              themes={themes}
              userLocation={userLocation}
              onRequestLocation={requestLocation}
              savedIds={savedIds}
              onToggleSave={toggleSave}
              onAddToRoute={handleAddToRoute}
              isInRoute={(id) => isPandalInRoute(id)}
              onSelectPandal={(p) => setSelectedPandalSlug(p.slug)}
              onOpenAddModal={() => setIsAddModalOpen(true)}
              onSwitchToMap={() => setCurrentTab('map')}
              onOpenRoute={() => setCurrentTab('routes')}
            />
          )}

          {currentTab === 'map' && (
            <MapViewContainer
              areas={areas}
              selectedAreaSlug={exploreAreaSlug}
              userLocation={userLocation}
              onRequestLocation={requestLocation}
              savedIds={savedIds}
              onToggleSave={toggleSave}
              onAddToRoute={handleAddToRoute}
              isInRoute={(id) => isPandalInRoute(id)}
              onSelectPandal={(p) => setSelectedPandalSlug(p.slug)}
              onOpenAddModal={() => setIsAddModalOpen(true)}
              onOpenRoute={() => setCurrentTab('routes')}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'routes' && (
            <RoutePlanner
              routePandals={routePandals}
              onRemoveFromRoute={removeFromRoute}
              onReorderRoute={reorderRoute}
              presets={presets}
              onLoadPreset={handleLoadPreset}
              onSelectPandal={(p) => setSelectedPandalSlug(p.slug)}
              onOpenExplore={() => setCurrentTab('explore')}
              addToast={addToast}
            />
          )}

          {currentTab === 'areas' && (
            <AreaExplorer
              areas={areas}
              onSelectArea={handleSelectArea}
              onOpenMapArea={handleOpenMapArea}
            />
          )}

          {currentTab === 'mypuja' && (
            <MyPujaView
              savedPandals={savedPandals}
              visitedIds={visitedIds}
              onToggleSave={toggleSave}
              onToggleVisited={toggleVisited}
              onAddToRoute={handleAddToRoute}
              isInRoute={(id) => isPandalInRoute(id)}
              onSelectPandal={(p) => setSelectedPandalSlug(p.slug)}
              onOpenExplore={() => setCurrentTab('explore')}
              onOpenRoute={() => setCurrentTab('routes')}
              addToast={addToast}
            />
          )}

          {currentTab === 'admin' && (
            <AdminDashboard
              onPandalUpdated={() => {
                loadInitialData();
                refreshSaved();
              }}
              addToast={addToast}
            />
          )}
        </ErrorBoundary>
      </main>

      {/* Pandal Detail View Modal */}
      {selectedPandalSlug && (
        <PandalDetailView
          slug={selectedPandalSlug}
          onClose={() => setSelectedPandalSlug(null)}
          isSaved={savedPandals.some(p => p.slug === selectedPandalSlug) || featuredPandals.some(p => p.slug === selectedPandalSlug && savedIds.has(p.id))}
          onToggleSave={toggleSave}
          onAddToRoute={handleAddToRoute}
          isInRoute={isPandalInRoute(selectedPandalSlug)}
          onSelectPandal={(p) => setSelectedPandalSlug(p.slug)}
          onOpenReportIssue={(p) => setReportingPandal(p)}
          onOpenRoute={() => {
            setSelectedPandalSlug(null);
            setCurrentTab('routes');
          }}
          addToast={addToast}
        />
      )}

      {/* Add Missing Pandal Modal */}
      <AddPandalModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        areas={areas}
        onSuccess={() => {
          loadInitialData();
        }}
        addToast={addToast}
      />

      {/* Report Issue Modal */}
      <ReportIssueModal
        pandal={reportingPandal}
        onClose={() => setReportingPandal(null)}
        addToast={addToast}
      />

      {/* Persistent Floating Active Route Bar (Visible everywhere except on the Routes tab itself) */}
      {currentTab !== 'routes' && routePandals.length > 0 && (
        <FloatingRouteBar
          routePandals={routePandals}
          onOpenRoute={() => setCurrentTab('routes')}
          onClearRoute={clearRoute}
        />
      )}

      {/* Floating Toast Alerts */}
      <ToastContainer toasts={toasts} />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        savedCount={savedIds.size}
        routeCount={routePandals.length}
      />

      {/* Footer */}
      {currentTab !== 'map' && (
        <Footer
          onNavigate={setCurrentTab}
          onOpenAddModal={() => setIsAddModalOpen(true)}
        />
      )}
    </div>
  );
}
export default App;
